import React, { useState } from 'react';
import {
  Share2,
  Send,
  Zap,
  Activity,
  CheckCircle,
  Radio,
  Clock,
  Layers,
  ArrowRight,
  ShieldAlert
} from 'lucide-react';

import { api } from '../services/api';
import { CoBanner } from '../components/CoBanner';
import { IpcResponse } from '../types';

export const IpcLaboratory: React.FC = () => {
  const [message, setMessage] = useState<string>('SYN_LOG_AUDIT_PROBE_CHUNK_42');
  const [exchange, setExchange] = useState<IpcResponse | null>(null);
  const [sending, setSending] = useState<boolean>(false);

  // Signal / Notification state
  const [signalResult, setSignalResult] = useState<any>(null);
  const [signaling, setSignaling] = useState<boolean>(false);

  const handleSendMessage = async () => {
    if (!message.trim()) return;
    setSending(true);
    try {
      const res = await api.sendIpc(message);
      setExchange(res);
    } catch (err: any) {
      alert(`IPC failed: ${err.message}`);
    } finally {
      setSending(false);
    }
  };

  const handleTriggerSignal = async () => {
    setSignaling(true);
    try {
      const res = await api.triggerIpcSignal();
      setSignalResult(res);
    } catch (err: any) {
      alert(`Signal demo failed: ${err.message}`);
    } finally {
      setSignaling(false);
    }
  };

  return (
    <div className="space-y-6">
      <CoBanner
        outcome="CO-3"
        title="Inter-Process Communication (IPC)"
        concept="Kernel Pipes, Duplex Anonymous Streams, Process Synchronization, and Signal Delivery"
        implementationFile="backend/app/services/ipc_manager.py"
        endpoint="POST /api/ipc/send | POST /api/ipc/signal"
        verificationTip="Click 'Transmit via Kernel Pipe' to send a live message from parent process to a dedicated child process, measuring round-trip latency and SHA-256 ACK."
      />

      {/* IPC DEMO SANDBOX */}
      <div className="soc-card p-6 border-l-4 border-l-cyan-500 bg-slate-900/80 space-y-5">
        <div>
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <Share2 className="w-4 h-4 text-cyan-400" />
            <span>Duplex Kernel Pipe IPC Sandbox (multiprocessing.Pipe)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Real byte transmission across isolated OS process boundaries via file descriptors.
          </p>
        </div>

        {/* Input & Transmit Bar */}
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <input
              type="text"
              value={message}
              onChange={e => setMessage(e.target.value)}
              placeholder="Enter message to transmit over kernel pipe..."
              className="w-full px-4 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs font-mono text-cyan-300 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <button
            onClick={handleSendMessage}
            disabled={sending}
            className="w-full sm:w-auto px-5 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs flex items-center justify-center gap-2 shadow-lg shadow-cyan-950/40 transition-colors"
          >
            <Send className="w-3.5 h-3.5" />
            <span>{sending ? 'Transmitting...' : 'Transmit via Kernel Pipe'}</span>
          </button>
        </div>

        {/* EXCHANGE LIFECYCLE RESULT */}
        {exchange && (
          <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 space-y-3 font-mono text-xs">
            <div className="flex flex-wrap items-center justify-between border-b border-slate-800 pb-2.5 gap-2">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-400" />
                <span className="text-white font-bold">IPC ROUND-TRIP ACKNOWLEDGEMENT VERIFIED</span>
              </div>
              <div className="flex items-center gap-2 text-cyan-400">
                <Clock className="w-3.5 h-3.5" />
                <span>Round-Trip Latency: <strong className="text-white font-bold">{exchange.latency_ms} ms</strong></span>
              </div>
            </div>

            {/* Visual Process Transmission Pipeline */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
              <div className="p-3 rounded bg-slate-900 border border-slate-800 space-y-1">
                <span className="text-[10px] uppercase font-bold text-slate-400 block">SENDER (PARENT PROCESS)</span>
                <div className="text-slate-200">
                  <span className="text-slate-500">PID: </span>
                  <span className="text-cyan-300 font-bold">{exchange.sender_pid}</span>
                </div>
                <div className="text-slate-300 truncate">
                  <span className="text-slate-500">Payload: </span>"{exchange.message_sent}"
                </div>
                <div className="text-[10px] text-slate-500">{exchange.timestamp}</div>
              </div>

              <div className="p-3 rounded bg-slate-900 border border-emerald-900/40 space-y-1">
                <span className="text-[10px] uppercase font-bold text-emerald-400 block">RECEIVER (CHILD PROCESS)</span>
                <div className="text-slate-200">
                  <span className="text-slate-500">PID: </span>
                  <span className="text-emerald-300 font-bold">{exchange.receiver_pid}</span>
                </div>
                <div className="text-slate-300 text-[11px] truncate">
                  <span className="text-slate-500">Response: </span>{exchange.response_received}
                </div>
                <div className="text-[10px] text-emerald-400 font-semibold">Status: ACK_RECEIVED</div>
              </div>
            </div>

            <div className="p-2.5 rounded bg-slate-900/60 border border-slate-800/80 text-[11px] text-slate-400">
              <strong className="text-slate-300">Kernel Mechanism: </strong>
              {exchange.mechanism} — {exchange.details}
            </div>
          </div>
        )}
      </div>

      {/* SIGNAL NOTIFICATION DEMO */}
      <div className="soc-card p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Radio className="w-4 h-4 text-amber-400" />
              <span>Asynchronous Signal & Event Notification</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Demonstrates asynchronous kernel interrupt notifications (POSIX SIGUSR1 or OS synchronization event).
            </p>
          </div>

          <button
            onClick={handleTriggerSignal}
            disabled={signaling}
            className="px-3.5 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-medium text-xs flex items-center gap-1.5 transition-colors"
          >
            <Zap className="w-3.5 h-3.5 fill-current" />
            <span>{signaling ? 'Dispatching...' : 'Dispatch Signal / Event'}</span>
          </button>
        </div>

        {signalResult && (
          <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs space-y-2">
            <div className="flex items-center justify-between text-amber-400">
              <span className="font-bold">SIGNAL RECEIVED: {signalResult.signal_name}</span>
              <span className="text-slate-400 text-[11px]">Platform: {signalResult.platform}</span>
            </div>
            <p className="text-slate-300 font-sans text-xs">{signalResult.details}</p>
          </div>
        )}
      </div>

      {/* EDUCATIONAL IPC COMPARISON MATRIX */}
      <div className="soc-card p-5 space-y-4">
        <h2 className="text-sm font-semibold text-white flex items-center gap-2">
          <Layers className="w-4 h-4 text-cyan-400" />
          <span>Operating System IPC Mechanism Comparison</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
          <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 space-y-2">
            <span className="text-cyan-400 font-bold block">1. Anonymous Pipes (pipe2)</span>
            <p className="text-slate-400 text-[11px] font-sans">
              Unidirectional or duplex byte streams managed in kernel memory buffers. Best for parent-child processes connected via file descriptors.
            </p>
            <span className="text-[10px] text-slate-500 block">Implemented in ThreadWatch</span>
          </div>

          <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 space-y-2">
            <span className="text-amber-400 font-bold block">2. Shared Memory (shmget/mmap)</span>
            <p className="text-slate-400 text-[11px] font-sans">
              Maps identical physical page frames into multiple process address spaces. Highest throughput with zero copy, but requires mutex/semaphore synchronization.
            </p>
            <span className="text-[10px] text-slate-500 block">Used for large-scale data transfers</span>
          </div>

          <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 space-y-2">
            <span className="text-violet-400 font-bold block">3. Signals & Message Queues</span>
            <p className="text-slate-400 text-[11px] font-sans">
              Signals provide asynchronous software interrupts (e.g. SIGHUP, SIGTERM, SIGUSR1), while message queues offer structured message delivery.
            </p>
            <span className="text-[10px] text-slate-500 block">Used for process lifecycle notifications</span>
          </div>
        </div>
      </div>
    </div>
  );
};
