import pytest
import os
import time
from pathlib import Path

from app.api.routes import (
    get_health,
    get_system_info,
    run_command,
    list_processes,
    start_demo_process,
    get_demo_process_status,
    stop_demo_process,
    send_ipc_message,
    trigger_ipc_signal,
    get_memory_metrics,
    allocate_memory,
    release_memory,
    list_files,
    run_file_io_benchmark,
    run_race_demo,
    run_deadlock_sim,
    run_benchmark
)
from app.models.schemas import (
    SafeCommandRequest,
    IpcSendRequest,
    MemoryDemoRequest,
    FileBenchmarkRequest,
    RaceDemoRequest,
    DeadlockSimRequest,
    BenchmarkRequest
)
from app.services.log_parser import parse_log_line, evaluate_security_rules
from app.services.worker_manager import manager
from app.core.config import DATASETS_DIR

def test_health_check():
    res = get_health()
    assert res["status"] == "healthy"
    assert res["service"] == "ThreadWatch Backend"

def test_system_info():
    info = get_system_info()
    assert "platform" in info
    assert "python_version" in info
    assert info["cpu_logical_cores"] >= 1
    assert info["total_ram_gb"] > 0

def test_allowlisted_commands():
    # Allowed command
    res = run_command(SafeCommandRequest(command_name="whoami"))
    assert res["success"] is True
    assert len(res["stdout"]) > 0

    # Blocked arbitrary command
    res_blocked = run_command(SafeCommandRequest(command_name="rm -rf /"))
    assert res_blocked["success"] is False
    assert "not in the security allowlist" in res_blocked["stderr"]

def test_log_parser_syslog_and_fallback():
    # Standard syslog format
    syslog_line = "Oct 16 08:00:00 soc-node-01 sshd[1024]: [ERROR] Failed password for invalid user admin from 198.51.100.42 port 49152 ssh2"
    entry = parse_log_line(syslog_line)
    assert entry.severity == "ERROR"
    assert entry.host == "soc-node-01"
    assert entry.process_name == "sshd"
    assert entry.process_id == 1024
    assert entry.ip_address == "198.51.100.42"
    assert entry.is_fallback is False

    # Malformed fallback line
    malformed = "Unexpected kernel panic error at 0xdeadbeef"
    entry2 = parse_log_line(malformed)
    assert entry2.severity == "CRITICAL"  # Recognized keyword 'panic'
    assert entry2.is_fallback is True

def test_security_rules_evaluation():
    lines = [
        "Oct 16 08:00:01 soc-node-01 sshd[1024]: [ERROR] Failed password for invalid user admin from 198.51.100.42 port 49152 ssh2",
        "Oct 16 08:00:02 soc-node-01 sshd[1025]: [ERROR] Failed password for invalid user admin from 198.51.100.42 port 49153 ssh2",
        "Oct 16 08:00:03 soc-node-01 sshd[1026]: [ERROR] Failed password for invalid user admin from 198.51.100.42 port 49154 ssh2"
    ]
    entries = [parse_log_line(l) for l in lines]
    findings = evaluate_security_rules(entries, "test_analysis")
    assert len(findings) >= 1
    assert any(f["rule_name"] == "BRUTE_FORCE_SSH" for f in findings)
    assert findings[0]["ip_address"] == "198.51.100.42"

def test_race_condition_experiment():
    result = run_race_demo(RaceDemoRequest(thread_count=4, iterations_per_thread=20000))
    assert result["expected_value"] == 80000
    assert result["safe_value"] == 80000
    assert result["unsafe_lost_updates"] >= 0
    assert result["safe_time_ms"] > 0

def test_deadlock_simulation():
    # Test deadlock prevention
    prevented = run_deadlock_sim(DeadlockSimRequest(prevent_deadlock=True))
    assert prevented["status"] == "DEADLOCK_PREVENTED"
    assert prevented["deadlock_occurred"] is False

    # Test deadlock simulation
    simulated = run_deadlock_sim(DeadlockSimRequest(prevent_deadlock=False))
    assert simulated["status"] == "DEADLOCK_SIMULATED"
    assert simulated["deadlock_occurred"] is True

def test_process_lifecycle_demo():
    # Start demo process
    res_start = start_demo_process()
    assert res_start["is_running"] is True
    pid = res_start["pid"]

    # Check status
    res_status = get_demo_process_status()
    assert res_status["pid"] == pid

    # Stop demo process
    res_stop = stop_demo_process()
    assert res_stop["status"] in ["stopped", "already_stopped"]

def test_ipc_pipe_communication():
    res = send_ipc_message(IpcSendRequest(message="TEST_KERNEL_MESSAGE_PING"))
    assert res["success"] is True
    assert "ACK_RECEIVED" in res["response_received"] or "CHILD_PROCESS_ACK" in res["response_received"]
    assert res["latency_ms"] >= 0.0

def test_memory_bounded_allocation():
    # Allocate 10 MB in child process
    res = allocate_memory(MemoryDemoRequest(action="allocate", size_mb=10))
    assert res["status"] == "allocated"
    assert res["requested_mb"] == 10
    assert res["pid"] is not None

    # Release
    res_rel = release_memory()
    assert res_rel["status"] == "released"
    assert res_rel["freed_mb"] == 10

def test_file_io_benchmark():
    res = run_file_io_benchmark(FileBenchmarkRequest(filename="sample_system.log"))
    assert res["file_size_bytes"] > 0
    assert "unbuffered_64b_ms" in res["timings_ms"]
    assert "buffered_64kb_ms" in res["timings_ms"]
    assert "readline_ms" in res["timings_ms"]
    assert "mmap_ms" in res["timings_ms"]
    assert res["fastest_strategy"] in ["Buffered (64KB)", "Memory-Mapped (mmap)", "Line-by-Line (readline)", "Unbuffered (64B)"]

def test_worker_manager_single_vs_multithread():
    test_file = DATASETS_DIR / "sample_system.log"
    assert test_file.exists()

    # Single-threaded
    s_id = manager.start_analysis(test_file, mode="single", worker_count=1, chunk_size=200)
    session_s = manager.get_session(s_id)
    for _ in range(50):
        if session_s.status in ["completed", "failed"]:
            break
        time.sleep(0.1)
    assert session_s.status == "completed"
    assert session_s.total_lines > 0
    assert session_s.parsed_lines == session_s.total_lines

    # Multi-threaded
    m_id = manager.start_analysis(test_file, mode="multi", worker_count=4, chunk_size=200)
    session_m = manager.get_session(m_id)
    for _ in range(50):
        if session_m.status in ["completed", "failed"]:
            break
        time.sleep(0.1)
    assert session_m.status == "completed"
    assert session_m.parsed_lines == session_s.parsed_lines
    # Severities must match between single and multi-threaded mode
    assert dict(session_m.severity_counts) == dict(session_s.severity_counts)
