import React, { useState, useEffect } from 'react';
import {
  HardDrive,
  Database,
  Cpu,
  Layers,
  Play,
  Square,
  RefreshCw,
  Activity,
  CheckCircle,
  AlertTriangle
} from 'lucide-react';

import { api } from '../services/api';
import { CoBanner } from '../components/CoBanner';
import { StatCard } from '../components/StatCard';
import { MemoryMetrics, MemoryDemoResponse } from '../types';

export const MemoryInspector: React.FC = () => {
  const [metrics, setMetrics] = useState<MemoryMetrics | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  // Controlled Memory Allocation Demo State
  const [allocationSize, setAllocationSize] = useState<number>(25);
  const [demoResult, setDemoResult] = useState<MemoryDemoResponse | null>(null);
  const [actionLoading, setActionLoading] = useState<boolean>(false);

  const loadMetrics = () => {
    api.getMemoryMetrics()
      .then(res => setMetrics(res))
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  const checkDemoStatus = () => {
    api.getMemoryDemoStatus()
      .then(res => {
        if (res.is_active) {
          setDemoResult({
            status: 'allocated',
            pid: res.pid,
            requested_mb: res.allocated_mb,
            message: `Active allocation in child process PID ${res.pid}`
          });
        }
      })
      .catch(console.error);
  };

  useEffect(() => {
    loadMetrics();
    checkDemoStatus();
    const interval = setInterval(loadMetrics, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleAllocate = async () => {
    setActionLoading(true);
    try {
      const res = await api.allocateMemory(allocationSize);
      setDemoResult(res);
      loadMetrics();
    } catch (err: any) {
      alert(`Allocation failed: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const handleRelease = async () => {
    setActionLoading(true);
    try {
      const res = await api.releaseMemory();
      setDemoResult(res);
      loadMetrics();
    } catch (err: any) {
      alert(`Release error: ${err.message}`);
    } finally {
      setActionLoading(false);
    }
  };

  const ramPercent = metrics ? metrics.percent : 0;
  const swapPercent = metrics ? metrics.swap_percent : 0;

  return (
    <div className="space-y-6">
      <CoBanner
        outcome="CO-4"
        title="Memory Management"
        concept="Virtual Memory, Multi-Level Page Tables, Demand Paging, Resident Set Size (RSS), and Isolated Allocations"
        implementationFile="backend/app/services/memory_monitor.py"
        endpoint="GET /api/memory/metrics | POST /api/memory/demo/allocate"
        verificationTip="Select an allocation size (e.g. 25 MB) and click 'Commit & Dirty Pages' to verify physical page frame allocation in an isolated child process."
      />

      {/* SYSTEM MEMORY STAT CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Physical RAM Total"
          value={metrics ? `${(metrics.total_mb / 1024).toFixed(1)} GB` : '-'}
          subtitle={`Available: ${metrics ? (metrics.available_mb / 1024).toFixed(1) : '-'} GB`}
          icon={HardDrive}
          color="cyan"
        />
        <StatCard
          title="Physical RAM Used"
          value={metrics ? `${(metrics.used_mb / 1024).toFixed(1)} GB` : '-'}
          subtitle={`RAM Utilization: ${metrics ? metrics.percent : 0}%`}
          icon={Activity}
          color="amber"
          badge={`${metrics ? metrics.percent : 0}%`}
        />
        <StatCard
          title="Process RSS Memory"
          value={metrics ? `${metrics.process_rss_mb.toFixed(1)} MB` : '-'}
          subtitle="Resident Set in Physical RAM"
          icon={Cpu}
          color="emerald"
          badge="Resident"
        />
        <StatCard
          title="Process VMS Memory"
          value={metrics ? `${metrics.process_vms_mb.toFixed(1)} MB` : '-'}
          subtitle="Total Virtual Address Space"
          icon={Layers}
          color="violet"
          badge="Virtual"
        />
      </div>

      {/* MEMORY GAUGES & PROGRESS */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Physical RAM Usage */}
        <div className="soc-card p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white">Physical RAM Utilization</h3>
            <span className="font-mono text-xs font-bold text-cyan-300">{ramPercent}%</span>
          </div>

          <div className="h-3 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                ramPercent > 85 ? 'bg-red-500' : ramPercent > 70 ? 'bg-amber-400' : 'bg-cyan-500'
              }`}
              style={{ width: `${ramPercent}%` }}
            />
          </div>

          <div className="flex justify-between text-xs font-mono text-slate-400">
            <span>Used: {metrics ? (metrics.used_mb / 1024).toFixed(2) : 0} GB</span>
            <span>Total: {metrics ? (metrics.total_mb / 1024).toFixed(2) : 0} GB</span>
          </div>
        </div>

        {/* Swap Space Usage */}
        <div className="soc-card p-5 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white">Swap / Paging File Utilization</h3>
            <span className="font-mono text-xs font-bold text-violet-300">{swapPercent}%</span>
          </div>

          <div className="h-3 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
            <div
              className="h-full bg-violet-500 rounded-full transition-all duration-500"
              style={{ width: `${swapPercent}%` }}
            />
          </div>

          <div className="flex justify-between text-xs font-mono text-slate-400">
            <span>Used: {metrics ? (metrics.swap_used_mb / 1024).toFixed(2) : 0} GB</span>
            <span>Total: {metrics ? (metrics.swap_total_mb / 1024).toFixed(2) : 0} GB</span>
          </div>
        </div>
      </div>

      {/* CONTROLLED BOUNDED MEMORY ALLOCATION DEMO */}
      <div className="soc-card p-6 border-l-4 border-l-emerald-500 bg-slate-900/80 space-y-4">
        <div>
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <Database className="w-4 h-4 text-emerald-400" />
            <span>Demand Paging & Bounded Allocation Experiment</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Spawns an isolated child process, allocates requested buffer, and touches 4KB page frames to force OS page faults and measure RSS expansion.
          </p>
        </div>

        {/* Size Selection & Actions */}
        <div className="flex flex-wrap items-center gap-3">
          <span className="text-xs text-slate-300 font-medium">Select Allocation Size:</span>
          {[10, 25, 50, 100].map(sz => (
            <button
              key={sz}
              type="button"
              onClick={() => setAllocationSize(sz)}
              className={`px-3 py-1.5 rounded-lg border text-xs font-mono font-medium transition-colors ${
                allocationSize === sz
                  ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300 font-bold'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              {sz} MB
            </button>
          ))}

          <div className="flex items-center gap-2 ml-auto">
            {demoResult?.status !== 'allocated' ? (
              <button
                onClick={handleAllocate}
                disabled={actionLoading}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs flex items-center gap-1.5 shadow-sm transition-colors"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>{actionLoading ? 'Allocating...' : `Commit & Dirty ${allocationSize} MB`}</span>
              </button>
            ) : (
              <button
                onClick={handleRelease}
                disabled={actionLoading}
                className="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-500 text-white font-medium text-xs flex items-center gap-1.5 shadow-sm transition-colors"
              >
                <Square className="w-3.5 h-3.5 fill-current" />
                <span>{actionLoading ? 'Releasing...' : 'Release Memory & Reclaim Frames'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Live Allocation Result */}
        {demoResult && (
          <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs space-y-2">
            <div className="flex flex-wrap items-center justify-between border-b border-slate-800 pb-2 text-emerald-400 font-bold">
              <span>STATUS: {demoResult.status.toUpperCase()}</span>
              {demoResult.pid && <span>CHILD PID: {demoResult.pid}</span>}
              {demoResult.requested_mb && <span>COMMITTED: {demoResult.requested_mb} MB</span>}
            </div>

            {demoResult.delta_mb !== undefined && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[11px] text-slate-300 pt-1">
                <div>RSS Before: <strong className="text-white">{demoResult.process_rss_before_mb} MB</strong></div>
                <div>RSS After: <strong className="text-emerald-400">{demoResult.process_rss_after_mb} MB</strong></div>
                <div>Measured Physical Delta: <strong className="text-cyan-400">+{demoResult.delta_mb} MB</strong></div>
              </div>
            )}

            <p className="text-slate-400 font-sans text-xs pt-1">{demoResult.message}</p>
          </div>
        )}
      </div>

      {/* EDUCATIONAL PROCESS ADDRESS SPACE DIAGRAM */}
      <div className="soc-card p-5 space-y-4">
        <h2 className="text-sm font-semibold text-white flex items-center gap-2">
          <Layers className="w-4 h-4 text-cyan-400" />
          <span>Linux Process Virtual Address Space Layout (x86_64)</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs font-mono">
          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-center">
            <span className="text-[10px] text-cyan-400 font-bold block mb-1">0x7FFFFFFFFFFF</span>
            <div className="text-slate-200 font-bold">User Stack</div>
            <span className="text-[10px] text-slate-500 block mt-1">Grows downward (call frames, local vars)</span>
          </div>

          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-center">
            <span className="text-[10px] text-violet-400 font-bold block mb-1">Memory Mapping</span>
            <div className="text-slate-200 font-bold">mmap Segment</div>
            <span className="text-[10px] text-slate-500 block mt-1">Shared libraries (libc.so) & file mappings</span>
          </div>

          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-center">
            <span className="text-[10px] text-emerald-400 font-bold block mb-1">brk() / sbrk()</span>
            <div className="text-slate-200 font-bold">Heap Segment</div>
            <span className="text-[10px] text-slate-500 block mt-1">Grows upward (malloc, dynamic objects)</span>
          </div>

          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-center">
            <span className="text-[10px] text-amber-400 font-bold block mb-1">Initialized/BSS</span>
            <div className="text-slate-200 font-bold">Data & BSS</div>
            <span className="text-[10px] text-slate-500 block mt-1">Global and static variables</span>
          </div>

          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 text-center">
            <span className="text-[10px] text-cyan-400 font-bold block mb-1">0x400000</span>
            <div className="text-slate-200 font-bold">Text Segment</div>
            <span className="text-[10px] text-slate-500 block mt-1">Read-only machine instructions (ELF)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
