import time
import uuid
from pathlib import Path
from typing import Dict, Any
from datetime import datetime

from ..core.config import DATASETS_DIR, UPLOADS_DIR
from .log_parser import parse_log_line
from .worker_manager import AnalysisSession
from ..storage import db

class PerformanceBenchmarkService:
    def run_benchmark(self, dataset_name: str, worker_count: int = 4, chunk_size: int = 500) -> Dict[str, Any]:
        target = None
        for root in [DATASETS_DIR, UPLOADS_DIR]:
            candidate = root / dataset_name
            if candidate.exists() and candidate.is_file():
                target = candidate
                break

        if not target:
            target = DATASETS_DIR / "sample_benchmark.log"
            if not target.exists():
                raise FileNotFoundError(f"Benchmark dataset '{dataset_name}' not found")

        # 1. Single-Thread Execution (Worker count = 1)
        single_id = f"bench_single_{uuid.uuid4().hex[:6]}"
        single_session = AnalysisSession(
            analysis_id=single_id,
            filepath=target,
            mode="single",
            worker_count=1,
            chunk_size=chunk_size
        )
        t0 = time.perf_counter()
        single_session.run()
        single_duration = max(0.001, time.perf_counter() - t0)
        single_throughput = round(single_session.total_lines / single_duration, 1)

        # 2. Multi-Thread Execution (Worker count = N)
        multi_id = f"bench_multi_{uuid.uuid4().hex[:6]}"
        multi_session = AnalysisSession(
            analysis_id=multi_id,
            filepath=target,
            mode="multi",
            worker_count=worker_count,
            chunk_size=chunk_size
        )
        t0 = time.perf_counter()
        multi_session.run()
        multi_duration = max(0.001, time.perf_counter() - t0)
        multi_throughput = round(multi_session.total_lines / multi_duration, 1)

        # 3. Compute Metrics
        speedup = round(single_duration / multi_duration, 2)
        efficiency = round(speedup / worker_count, 2)

        # Per-worker breakdown
        worker_distribution = [
            {
                "worker_id": w.worker_id,
                "entries_processed": w.entries_processed,
                "percentage": round((w.entries_processed / multi_session.total_lines * 100.0), 1) if multi_session.total_lines > 0 else 0.0
            }
            for w in multi_session.workers
        ]

        benchmark_id = f"bm_{uuid.uuid4().hex[:8]}"
        record = {
            "id": benchmark_id,
            "dataset_name": target.name,
            "total_lines": single_session.total_lines,
            "single_thread_time": round(single_duration, 4),
            "multi_thread_time": round(multi_duration, 4),
            "single_throughput_lps": single_throughput,
            "multi_throughput_lps": multi_throughput,
            "speedup": speedup,
            "efficiency": efficiency,
            "worker_count": worker_count,
            "chunk_size": chunk_size,
            "worker_distribution": worker_distribution,
            "severities_found": dict(multi_session.severity_counts),
            "created_at": datetime.now().isoformat(),
            "explanation": (
                f"Multi-threading achieved a {speedup}x speedup ({multi_throughput:,.1f} lines/sec vs {single_throughput:,.1f} lines/sec). "
                f"In Python, file I/O, regex tokenization in C extensions, and queue transfers release the GIL, "
                f"enabling true concurrent worker throughput across {worker_count} active threads."
            )
        }

        # Store in SQLite
        db.save_benchmark({
            "id": record["id"],
            "dataset_name": record["dataset_name"],
            "total_lines": record["total_lines"],
            "single_thread_time": record["single_thread_time"],
            "multi_thread_time": record["multi_thread_time"],
            "speedup": record["speedup"],
            "efficiency": record["efficiency"],
            "worker_count": record["worker_count"],
            "chunk_size": record["chunk_size"],
            "created_at": record["created_at"]
        })

        return record

benchmark_service = PerformanceBenchmarkService()
