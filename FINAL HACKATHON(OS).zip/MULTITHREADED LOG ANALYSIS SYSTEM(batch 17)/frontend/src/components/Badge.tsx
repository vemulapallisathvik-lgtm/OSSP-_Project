import React from 'react';

interface BadgeProps {
  label: string;
  variant?: 'CRITICAL' | 'ERROR' | 'WARNING' | 'NOTICE' | 'INFO' | 'DEBUG' | 'SECURITY' | 'IDLE' | 'RUNNING' | 'WAITING' | 'COMPLETED' | 'DEFAULT';
  className?: string;
}

export const Badge: React.FC<BadgeProps> = ({ label, variant, className = '' }) => {
  const norm = (variant || label).toUpperCase();

  const styles: Record<string, string> = {
    CRITICAL: 'bg-red-500/15 text-red-400 border-red-500/30',
    ERROR: 'bg-rose-500/15 text-rose-400 border-rose-500/30',
    SECURITY: 'bg-purple-500/15 text-purple-300 border-purple-500/30',
    WARNING: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
    WARN: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
    NOTICE: 'bg-cyan-500/15 text-cyan-300 border-cyan-500/30',
    INFO: 'bg-blue-500/15 text-blue-300 border-blue-500/30',
    DEBUG: 'bg-slate-700/30 text-slate-400 border-slate-700',
    RUNNING: 'bg-cyan-500/15 text-cyan-400 border-cyan-500/40 animate-pulse',
    WAITING: 'bg-amber-500/15 text-amber-400 border-amber-500/30',
    IDLE: 'bg-slate-800 text-slate-400 border-slate-700',
    COMPLETED: 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30',
    DEFAULT: 'bg-slate-800 text-slate-300 border-slate-700'
  };

  const currentStyle = styles[norm] || styles.DEFAULT;

  return (
    <span
      className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded text-[11px] font-mono font-medium border ${currentStyle} ${className}`}
    >
      {norm === 'RUNNING' && <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-ping" />}
      {label}
    </span>
  );
};
