# ThreadWatch — Multithreaded Log Analysis & System Monitoring Platform
### Operating Systems Hackathon Project | Cyber SOC Operations Platform

ThreadWatch is a full-stack, multithreaded cybersecurity log analysis and system monitoring platform built to demonstrate real operating system concepts through working implementations. It combines a dark SOC dashboard with a concurrent Python log processing pipeline, live worker thread telemetry, and dedicated interactive laboratories covering all six Course Outcomes (**CO-1 through CO-6**).

---

## 1. Key Features

- **Multithreaded Log Analysis Engine**:
  - Concurrent parsing of large `.log`, `.txt`, and `.csv` files.
  - Bounded task queue (`queue.Queue`) with producer-consumer coordination.
  - Configurable worker pools (1 to 16 threads) and chunk sizes (100 to 2,000 lines).
  - Thread-safe aggregation protected by `threading.Lock`.
  - Live progress streaming over Server-Sent Events (SSE) and WebSockets.
- **SOC Security Anomaly Detection**:
  - Deterministic rule-based detection for SSH/PAM brute-force attacks.
  - Identification of repeated access denied bursts (403 / permission denied).
  - Privilege escalation detection (`sudo`, unauthorized `su`, `CAP_SYS_ADMIN`).
  - Kernel panic, OOM-killer, and segmentation fault log tracking.
  - Persistent review status in SQLite database.
- **Live Worker Thread Monitor**:
  - Visual worker grid showing per-worker state (`IDLE`, `RUNNING`, `WAITING`, `COMPLETED`), assigned chunk index, entries processed, errors found, and elapsed execution time.
  - Live task queue telemetry (backlog size, completed chunks, pending tasks, throughput LPS).
- **Comprehensive Course Outcome Implementations (CO-1 to CO-6)**:
  - **CO-1 (OS as a Service Layer)**: Layered architecture visualizer, User space vs Kernel space privilege rings, and safe allowlisted command sandbox (`whoami`, `hostname`, `cpu_count`, etc.).
  - **CO-2 (Processes and Process Control)**: Live OS process table via `psutil`, PCB inspector, and safe lifecycle demo for an application-owned child process (start/stop/status).
  - **CO-3 (Inter-Process Communication)**: Live kernel pipe messaging via `multiprocessing.Pipe` across isolated process boundaries with cryptographic verification and round-trip latency measurement.
  - **CO-4 (Memory Management)**: Real-time physical RAM and swap monitoring, process RSS/VMS tracking, and controlled bounded allocation in an isolated child process demonstrating demand paging and page frame expansion.
  - **CO-5 (File Systems & File I/O)**: Restricted file browser with inode tracking, and empirical I/O benchmark comparing unbuffered 64B reads, 64KB block buffered reads, line streams, and memory-mapped files (`mmap`).
  - **CO-6 (Concurrency & Synchronization)**: Interactive race condition experiment comparing unsynchronized updates vs. `threading.Lock` mutex protection, and Coffman deadlock simulation with global resource hierarchy prevention.
- **Performance Benchmarking Lab**:
  - Empirical comparison of single-threaded vs. multithreaded execution on identical datasets.
  - Calculation of real Speedup ($S = T_1 / T_N$) and Parallel Efficiency ($E = S / N$).
  - Detailed architectural analysis of the Python GIL and I/O concurrency.
- **Audit Reports & Exports**:
  - Export analysis results to CSV and structured JSON.
  - Print-to-PDF executive summary layout.

---

## 2. Technology Stack

- **Frontend**:
  - React 19 + TypeScript
  - Vite 8
  - Tailwind CSS v4
  - Lucide React Icons
  - Recharts (Donut, Bar, and Line charts)
  - React Router v7
- **Backend**:
  - Python 3.10+ (tested on Python 3.14)
  - FastAPI + Starlette
  - Uvicorn (ASGI web server)
  - Pydantic v2 (Request/Response schemas)
  - Python Standard Library Concurrency (`threading`, `queue`, `multiprocessing`)
  - `psutil` (Host and process resource telemetry)
  - `sqlite3` (Persistent analysis history, findings, and benchmarks)
  - `mmap` (Memory-mapped file I/O)

---

## 3. Directory Structure

```text
threadwatch/
├── backend/
│   ├── app/
│   │   ├── main.py                    # FastAPI entrypoint & lifespan handlers
│   │   ├── api/
│   │   │   └── routes.py              # REST, SSE, and WebSocket endpoints
│   │   ├── core/
│   │   │   └── config.py              # Application configuration & security limits
│   │   ├── models/
│   │   │   └── schemas.py             # Pydantic data schemas
│   │   ├── services/
│   │   │   ├── log_parser.py          # Syslog/ISO parser & rule-based security engine
│   │   │   ├── worker_manager.py      # Multithreaded producer-consumer engine
│   │   │   ├── process_monitor.py     # psutil explorer & child process lifecycle (CO-2)
│   │   │   ├── ipc_manager.py         # Kernel pipe & signal manager (CO-3)
│   │   │   ├── memory_monitor.py      # Memory telemetry & bounded allocation (CO-4)
│   │   │   ├── file_io_benchmark.py   # Multi-strategy file I/O & VFS explorer (CO-5)
│   │   │   ├── concurrency_lab.py     # Race condition & deadlock simulator (CO-6)
│   │   │   ├── benchmark.py           # Single-thread vs multithread benchmark
│   │   │   └── system_info.py         # OS architecture & safe command runner (CO-1)
│   │   └── storage/
│   │       └── db.py                  # SQLite database manager
│   ├── tests/
│   │   └── test_backend.py            # Comprehensive pytest test suite
│   └── requirements.txt               # Backend dependencies
├── frontend/
│   ├── src/
│   │   ├── layouts/
│   │   │   └── DashboardLayout.tsx    # SOC sidebar, topbar, and live status indicator
│   │   ├── components/
│   │   │   ├── StatCard.tsx           # Reusable metric card
│   │   │   ├── Badge.tsx              # Severity & worker state badge
│   │   │   ├── EmptyState.tsx         # Empty state view
│   │   │   └── CoBanner.tsx           # Course Outcome verification banner
│   │   ├── pages/
│   │   │   ├── Overview.tsx           # SOC metrics, severity donut, throughput chart
│   │   │   ├── AnalyzeLogs.tsx        # File upload & live log analysis engine
│   │   │   ├── ThreadMonitor.tsx      # Live worker thread grid & queue pipeline
│   │   │   ├── SecurityCenter.tsx     # Incident management & review toggles
│   │   │   ├── ProcessExplorer.tsx    # OS process table & child lifecycle demo (CO-2)
│   │   │   ├── IpcLaboratory.tsx      # Pipe communication & signal testing (CO-3)
│   │   │   ├── MemoryInspector.tsx    # RAM gauges & bounded allocation demo (CO-4)
│   │   │   ├── FileSystemLab.tsx      # File browser & 4-way I/O benchmark (CO-5)
│   │   │   ├── ConcurrencyLab.tsx     # Race condition & deadlock simulation (CO-6)
│   │   │   ├── PerformanceLab.tsx     # Single-thread vs multithread speedup runner
│   │   │   ├── Reports.tsx            # Audit report exports (CSV/JSON/Print)
│   │   │   └── SystemInformation.tsx  # Layered OS architecture & command runner (CO-1)
│   │   ├── services/
│   │   │   └── api.ts                 # Typed fetch client
│   │   └── types/
│   │       └── index.ts               # TypeScript interface definitions
│   ├── package.json
│   ├── vite.config.ts
│   └── tsconfig.json
├── datasets/
│   ├── sample_system.log              # 1,200 lines (systemd, kernel panics, OOM)
│   ├── sample_auth.log                # 1,200 lines (SSH brute force, sudo attempts)
│   ├── sample_application.log         # 1,200 lines (HTTP status codes, DB latency)
│   └── sample_benchmark.log           # 5,000 lines (Multithread performance testing)
├── scripts/
│   └── generate_large_logs.py         # Synthetic log generator script
├── reports/                           # Exported CSV and JSON audit reports
├── uploads/                           # Temporary user-uploaded log files
├── OS_CONCEPT_MAPPING.md              # Academic & Hackathon Course Outcome Matrix
└── README.md
```

---

## 4. Setup & Installation Instructions

### Prerequisites
- **Python**: Version 3.10 or higher.
- **Node.js**: Version 18 or higher (tested with Node v24).
- **npm**: Version 9 or higher.

### Step 1: Install Backend Dependencies
In Windows PowerShell or Linux terminal:
```bash
cd threadwatch/backend
python -m pip install -r requirements.txt
```

### Step 2: Install Frontend Dependencies
```bash
cd ../frontend
npm install
```

---

## 5. Launching the Application

### Launch Backend Server
In a terminal window:
```powershell
# Windows PowerShell
cd threadwatch/backend
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```
```bash
# Linux / macOS
cd threadwatch/backend
python3 -m uvicorn app.main:app --host 127.0.0.1 --port 8000
```
The backend API is now live at `http://127.0.0.1:8000`. API documentation is available at `http://127.0.0.1:8000/docs`.

### Launch Frontend Server
In a second terminal window:
```bash
cd threadwatch/frontend
npm run dev -- --host 127.0.0.1 --port 5173
```
Open your web browser and navigate to:
**`http://127.0.0.1:5173/`**

---

## 6. How to Test Course Outcomes & Features

### CO-1: OS as a Service Layer (`/system`)
1. Click **System Information** in the sidebar.
2. Review the Layered OS Architecture Diagram (User Applications ➔ Libraries ➔ SCI ➔ Kernel ➔ Hardware).
3. In the **Allowlisted OS Command Sandbox**, select `whoami` or `hostname` and click **Run Command**.
4. Observe the command executed, exit code 0, execution duration in milliseconds, and real process output.

### CO-2: Processes and Process Control (`/processes`)
1. Click **Process Explorer** in the sidebar.
2. Inspect the live operating system process list queried via `psutil`. Use the search box to filter by name.
3. In the **Dedicated Child Process Lifecycle Sandbox**, click **Start Child Process**.
4. Observe the new child PID, active state, and uptime counter.
5. Click **Terminate Child** to verify safe application-bounded process termination.

### CO-3: Inter-Process Communication (`/ipc`)
1. Click **IPC Laboratory** in the sidebar.
2. Type an audit probe message into the input field (e.g. `SYN_LOG_AUDIT_PROBE_CHUNK_42`).
3. Click **Transmit via Kernel Pipe**.
4. Observe the message transmitted across the kernel boundary from the Parent Process PID to the Child Process PID, measuring round-trip latency in ms and displaying the child process's cryptographic SHA-256 ACK verification.

### CO-4: Memory Management (`/memory`)
1. Click **Memory Inspector** in the sidebar.
2. View real-time physical RAM and swap gauges, as well as application process RSS and VMS.
3. In the **Demand Paging & Bounded Allocation Experiment**, choose `25 MB` and click **Commit & Dirty Pages**.
4. An isolated child process is spawned, allocating a buffer and dirtying 4KB pages to force physical page table frame allocation. Observe the measured RSS expansion (+25 MB).
5. Click **Release Memory & Reclaim Frames** to verify operating system memory reclamation.

### CO-5: File Systems and File I/O (`/filesystem`)
1. Click **File System Lab** in the sidebar.
2. Browse the restricted log and report directory listing with inode numbers.
3. Select `sample_system.log` and click **Run I/O Benchmark**.
4. High-resolution monotonic timers measure and compare:
   - Unbuffered small reads (64 bytes)
   - Block buffered reads (64 KB)
   - Line-by-line stream reads
   - Memory-mapped file I/O (`mmap`)
5. View the latency comparison chart and measured throughput in MB/s.

### CO-6: Concurrency and Synchronization (`/concurrency` & `/threads`)
1. Click **Concurrency Lab** in the sidebar.
2. Select 4 threads and 50,000 iterations and click **Run Race Experiment**.
3. Compare the side-by-side results:
   - **Unsynchronized**: Multiple threads read stale counter values, resulting in thousands of lost updates.
   - **Synchronized (`threading.Lock`)**: 100% data integrity with zero lost updates.
4. Test the **Deadlock Simulator**: run with Circular Wait allowed to observe timeout-protected deadlock detection, then enable **Enforce Strict Lock Hierarchy** to observe deadlock prevention.
5. Click **Thread Monitor** to inspect real worker threads, chunk assignments, and task queue backlog during log processing.

### Performance Benchmark Lab (`/performance`)
1. Click **Performance Lab** in the sidebar.
2. Select `sample_benchmark.log` (5,000 lines), 4 worker threads, and chunk size 500.
3. Click **Run Benchmark**.
4. The system executes identical parsing rules in single-threaded mode (1 worker) and multithreaded mode (4 workers), calculating wall-clock duration, speedup ($S$), parallel efficiency ($E$), and lines per second.

---

## 7. Generating Custom Datasets

A synthetic generator script is provided in `scripts/generate_large_logs.py`:
```bash
# Generate 10,000 synthetic log lines
python scripts/generate_large_logs.py 10000 datasets/large_test.log general

# Generate 5,000 auth-focused log lines (for brute-force testing)
python scripts/generate_large_logs.py 5000 datasets/auth_test.log auth
```

---

## 8. Running Automated Tests

A comprehensive pytest test suite verifies all backend components:
```bash
cd threadwatch/backend
python -m pytest tests -v
```
All 12 unit and integration tests exercise:
- Health check and system info endpoints
- Allowlisted command sandbox security
- Syslog and fallback log parsing
- Rule-based security detection
- Race condition experiment and mutex integrity
- Deadlock simulation and prevention
- Controlled child process lifecycle
- IPC pipe transmission and round-trip ACK
- Bounded memory allocation in child process
- 4-way file I/O benchmark
- Single-thread vs multithread consistency

---

## 9. Security & Sandboxing Architecture

- **No Shell Execution**: Diagnostic commands are executed using fixed argument vectors (`shell=False`) with strict timeouts.
- **Path Traversal Protection**: File operations strictly validate that canonical paths reside within `datasets/`, `uploads/`, or `reports/`.
- **Bounded Resource Allocations**: Demo memory allocations are capped at 100 MB and run in dedicated child processes that are reclaimed automatically upon timeout or server shutdown.
- **Local Execution**: ThreadWatch runs entirely offline without requiring external API keys, cloud subscriptions, or remote services.
