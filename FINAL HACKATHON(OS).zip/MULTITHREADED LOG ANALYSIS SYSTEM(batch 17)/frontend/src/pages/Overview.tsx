import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FileText,
  AlertTriangle,
  AlertOctagon,
  Flame,
  Cpu,
  HardDrive,
  Activity,
  Play,
  ArrowRight,
  ShieldCheck,
  RefreshCw
} from 'lucide-react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip, BarChart, Bar, XAxis, YAxis } from 'recharts';

import { api } from '../services/api';
import { StatCard } from '../components/StatCard';
import { Badge } from '../components/Badge';
import { EmptyState } from '../components/EmptyState';

const SEV_COLORS: Record<string, string> = {
  CRITICAL: '#ef4444',
  ERROR: '#f87171',
  SECURITY: '#a855f7',
  WARNING: '#f59e0b',
  NOTICE: '#06b6d4',
  INFO: '#3b82f6',
  DEBUG: '#64748b'
};

export const Overview: React.FC = () => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [launchingSample, setLaunchingSample] = useState(false);
  const navigate = useNavigate();

  const loadData = () => {
    setLoading(true);
    api.getOverview()
      .then(res => setData(res))
      .catch(err => console.error(err))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 10000);
    return () => clearInterval(interval);
  }, []);

  const handleRunSample = async () => {
    setLaunchingSample(true);
    try {
      const res = await api.startAnalysis('sample_system.log', 'multi', 4, 250);
      navigate(`/analyze?session=${res.analysis_id}`);
    } catch (e: any) {
      alert(`Failed to launch analysis: ${e.message}`);
    } finally {
      setLaunchingSample(false);
    }
  };

  const summary = data?.summary || {
    total_log_entries: 0,
    errors_detected: 0,
    warnings_detected: 0,
    critical_events: 0,
    active_worker_threads: 0,
    system_cpu_percent: 0,
    process_rss_mb: 0,
    process_vms_mb: 0,
    system_ram_used_mb: 0,
    system_ram_total_mb: 0
  };

  const recentAnalyses = data?.recent_analyses || [];
  const recentFindings = data?.recent_findings || [];

  // Aggregated severity distribution for chart
  const severityMap: Record<string, number> = {};
  recentAnalyses.forEach((a: any) => {
    if (a.severities) {
      Object.entries(a.severities).forEach(([sev, count]) => {
        severityMap[sev] = (severityMap[sev] || 0) + (count as number);
      });
    }
  });

  const pieData = Object.entries(severityMap).map(([name, value]) => ({ name, value }));

  // Throughput chart data from recent completed runs
  const throughputData = recentAnalyses
    .filter((a: any) => a.status === 'completed')
    .map((a: any) => ({
      name: a.filename.replace('.log', ''),
      lps: a.throughput_lps || 0,
      workers: a.worker_count
    }))
    .reverse();

  return (
    <div className="space-y-6">
      {/* Top Banner / Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            SOC Log Intelligence Overview
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time multithreaded log analytics, OS metrics, and cyber event detection
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={loadData}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs transition-colors"
            title="Refresh overview metrics"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>

          <button
            onClick={handleRunSample}
            disabled={launchingSample}
            className="flex items-center gap-2 px-3.5 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs shadow-lg shadow-cyan-950/40 transition-colors"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{launchingSample ? 'Launching Workers...' : 'Analyze Sample System Log'}</span>
          </button>
        </div>
      </div>

      {/* SUMMARY STAT CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Log Entries"
          value={summary.total_log_entries.toLocaleString()}
          subtitle="Processed by background threads"
          icon={FileText}
          color="cyan"
          badge="Live"
        />
        <StatCard
          title="Errors Detected"
          value={summary.errors_detected.toLocaleString()}
          subtitle="Application & Service errors"
          icon={AlertTriangle}
          color="amber"
        />
        <StatCard
          title="Critical Incidents"
          value={summary.critical_events.toLocaleString()}
          subtitle="Panics, OOM & Kernel events"
          icon={Flame}
          color="rose"
        />
        <StatCard
          title="Active Worker Threads"
          value={summary.active_worker_threads}
          subtitle="Concurrent worker pool threads"
          icon={Cpu}
          color="emerald"
          badge="Pool"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="App Resident Memory"
          value={`${summary.process_rss_mb.toFixed(1)} MB`}
          subtitle={`VMS: ${summary.process_vms_mb.toFixed(1)} MB`}
          icon={HardDrive}
          color="violet"
          badge="RSS"
        />
        <StatCard
          title="System Memory Used"
          value={`${(summary.system_ram_used_mb / 1024).toFixed(1)} GB`}
          subtitle={`Total: ${(summary.system_ram_total_mb / 1024).toFixed(1)} GB`}
          icon={Activity}
          color="slate"
        />
        <StatCard
          title="Host CPU Load"
          value={`${summary.system_cpu_percent}%`}
          subtitle="Operating system CPU utilization"
          icon={Activity}
          color="cyan"
        />
        <StatCard
          title="Warnings Detected"
          value={summary.warnings_detected.toLocaleString()}
          subtitle="Latency, retry, threshold alerts"
          icon={AlertOctagon}
          color="amber"
        />
      </div>

      {/* CHARTS ROW */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Severity Distribution Donut */}
        <div className="soc-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-white">Log Severity Distribution</h2>
            <span className="text-[11px] font-mono text-slate-400">Aggregated Events</span>
          </div>

          {pieData.length > 0 ? (
            <div className="h-64 flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    innerRadius={60}
                    outerRadius={95}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {pieData.map((entry) => (
                      <Cell key={entry.name} fill={SEV_COLORS[entry.name] || '#64748b'} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '8px', color: '#fff' }}
                  />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex flex-col gap-1.5 ml-4 text-xs font-mono">
                {pieData.map(entry => (
                  <div key={entry.name} className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: SEV_COLORS[entry.name] || '#64748b' }} />
                    <span className="text-slate-300">{entry.name}:</span>
                    <span className="text-white font-bold">{entry.value.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="h-64 flex flex-col items-center justify-center text-slate-500 text-xs">
              <FileText className="w-8 h-8 mb-2 opacity-50" />
              <span>No log analysis runs executed yet</span>
            </div>
          )}
        </div>

        {/* Throughput Bar Chart */}
        <div className="soc-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-white">Throughput Performance (Lines/Sec)</h2>
            <span className="text-[11px] font-mono text-cyan-400">High-Resolution Timer</span>
          </div>

          {throughputData.length > 0 ? (
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={throughputData}>
                  <XAxis dataKey="name" stroke="#64748b" fontSize={11} />
                  <YAxis stroke="#64748b" fontSize={11} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '8px', color: '#fff' }}
                  />
                  <Bar dataKey="lps" fill="#06b6d4" radius={[4, 4, 0, 0]} name="Throughput (LPS)" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          ) : (
            <div className="h-64 flex flex-col items-center justify-center text-slate-500 text-xs">
              <Activity className="w-8 h-8 mb-2 opacity-50" />
              <span>Throughput chart will populate after first analysis</span>
            </div>
          )}
        </div>
      </div>

      {/* TABLES ROW: RECENT ANALYSES & SECURITY FINDINGS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Analysis History */}
        <div className="soc-card p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-white">Recent Analysis Runs</h2>
            <button
              onClick={() => navigate('/analyze')}
              className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-medium"
            >
              <span>Analyze New File</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {recentAnalyses.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead className="text-slate-400 border-b border-slate-800">
                  <tr>
                    <th className="pb-2">Dataset</th>
                    <th className="pb-2">Mode</th>
                    <th className="pb-2">Workers</th>
                    <th className="pb-2">Lines</th>
                    <th className="pb-2">Throughput</th>
                    <th className="pb-2">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {recentAnalyses.map((a: any) => (
                    <tr
                      key={a.id}
                      onClick={() => navigate(`/analyze?session=${a.id}`)}
                      className="hover:bg-slate-800/40 cursor-pointer transition-colors"
                    >
                      <td className="py-2.5 font-sans font-medium text-white">{a.filename}</td>
                      <td className="py-2.5">
                        <span className="uppercase text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                          {a.mode}
                        </span>
                      </td>
                      <td className="py-2.5 text-cyan-300">{a.worker_count}T</td>
                      <td className="py-2.5 text-slate-300">{a.total_lines?.toLocaleString() || '-'}</td>
                      <td className="py-2.5 text-emerald-400">
                        {a.throughput_lps ? `${a.throughput_lps.toLocaleString()} LPS` : '-'}
                      </td>
                      <td className="py-2.5">
                        <Badge label={a.status} variant={a.status === 'completed' ? 'COMPLETED' : 'WARNING'} />
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <EmptyState
              title="No Log Analyses Executed Yet"
              description="Upload a .log file or test with one of the pre-bundled datasets."
              actionText="Run Quick Sample Analysis"
              onAction={handleRunSample}
            />
          )}
        </div>

        {/* Recent Security Incidents Feed */}
        <div className="soc-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-sm font-semibold text-white">Security Alerts</h2>
            <button
              onClick={() => navigate('/security')}
              className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-medium"
            >
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {recentFindings.length > 0 ? (
            <div className="space-y-3">
              {recentFindings.map((f: any) => (
                <div key={f.id} className="p-3 rounded-lg bg-slate-900/80 border border-slate-800/80 space-y-1">
                  <div className="flex items-center justify-between">
                    <Badge label={f.severity} variant={f.severity} />
                    {f.ip_address && (
                      <span className="text-[10px] font-mono text-slate-400">{f.ip_address}</span>
                    )}
                  </div>
                  <h4 className="text-xs font-semibold text-slate-200 mt-1">{f.title}</h4>
                  <p className="text-[11px] text-slate-400 line-clamp-2">{f.description}</p>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 text-center text-slate-500 text-xs">
              <ShieldCheck className="w-8 h-8 mx-auto mb-2 text-emerald-500/50" />
              <span>No critical security anomalies flagged</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
