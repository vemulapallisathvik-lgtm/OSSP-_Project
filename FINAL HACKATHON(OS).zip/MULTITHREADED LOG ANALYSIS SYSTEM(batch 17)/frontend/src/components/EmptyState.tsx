import React from 'react';
import { LucideIcon, FileText } from 'lucide-react';

interface EmptyStateProps {
  title: string;
  description: string;
  icon?: LucideIcon;
  actionText?: string;
  onAction?: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  title,
  description,
  icon: Icon = FileText,
  actionText,
  onAction
}) => {
  return (
    <div className="soc-card p-12 text-center flex flex-col items-center justify-center border-dashed border-slate-700/60 my-6">
      <div className="p-4 rounded-full bg-slate-800/80 text-cyan-400 mb-4 border border-slate-700">
        <Icon className="w-8 h-8" />
      </div>
      <h3 className="text-lg font-semibold text-white mb-1">{title}</h3>
      <p className="text-sm text-slate-400 max-w-md mb-6">{description}</p>
      {actionText && onAction && (
        <button
          onClick={onAction}
          className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-sm transition-colors shadow-lg shadow-cyan-900/30 flex items-center gap-2"
        >
          {actionText}
        </button>
      )}
    </div>
  );
};
