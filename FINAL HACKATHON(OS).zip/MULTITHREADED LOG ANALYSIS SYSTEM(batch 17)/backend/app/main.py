import sys
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from .api.routes import router
from .services.process_monitor import process_service
from .services.ipc_manager import ipc_service
from .services.memory_monitor import memory_service
from .storage.db import init_db

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger("threadwatch")

@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Initializing ThreadWatch backend systems...")
    init_db()
    yield
    logger.info("Gracefully cleaning up ThreadWatch worker resources...")
    process_service.stop_demo_process()
    memory_service.release_memory()
    ipc_service.shutdown()

app = FastAPI(
    title="ThreadWatch — Multithreaded Log Analysis & System Monitoring Platform",
    description="Operating Systems Hackathon Platform demonstrating Concurrency, IPC, Memory Management, File I/O, Process Control, and OS Services.",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)

@app.get("/")
def root():
    return {
        "project": "ThreadWatch",
        "description": "Multithreaded Log Analysis & System Monitoring Platform",
        "docs_url": "/docs",
        "health_url": "/api/health"
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host="127.0.0.1", port=8000, reload=True)
