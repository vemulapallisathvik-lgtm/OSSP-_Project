#!/usr/bin/env python3
"""
ThreadWatch Synthetic Log Generator
Generates realistic multi-tier system, auth, and application logs with deterministic seed.
"""

import sys
import random
import datetime
from pathlib import Path

PROCESSES = [
    ("systemd", [1]),
    ("sshd", [1024, 1025, 1042, 1089, 2048, 2055]),
    ("kernel", [0]),
    ("dockerd", [892, 893]),
    ("nginx", [1400, 1401, 1402, 1403]),
    ("postgres", [2100, 2101, 2102, 2105]),
    ("redis-server", [1850]),
    ("auth_service", [3100, 3101]),
    ("payment_worker", [4200, 4201, 4202]),
    ("cron", [650])
]

HOSTS = ["soc-node-01", "soc-node-02", "soc-gateway", "db-cluster-pri", "k8s-worker-alpha"]

ATTACKER_IPS = [
    "198.51.100.42",
    "203.0.113.195",
    "45.33.32.156",
    "185.220.101.5",
    "192.168.1.105"
]

INTERNAL_IPS = [
    "10.0.0.15",
    "10.0.0.22",
    "10.0.1.50",
    "172.16.0.4"
]

LOG_TEMPLATES = {
    "INFO": [
        "Session opened for user {user} by (uid=0)",
        "Service {service} successfully started in {ms}ms",
        "Connection accepted from {ip}:{port} on socket 4",
        "HTTP/1.1 GET /api/v1/health status=200 duration={ms}ms",
        "HTTP/1.1 POST /api/v1/telemetry status=201 bytes=1024",
        "Scheduled cron task /etc/cron.hourly/logrotate completed successfully",
        "BGP neighbor {ip} established state=ESTABLISHED",
        "SSL handshake completed with cipher=ECDHE-RSA-AES256-GCM-SHA384",
        "Worker thread worker-{worker_id} checkpoint saved to disk",
        "Memory compaction cycle finished free_pages={free_pages}"
    ],
    "NOTICE": [
        "Configuration reloaded on SIGHUP without interruption",
        "TLS certificate expires in 28 days for domain soc.internal",
        "Process reniced to priority 5 due to background batch job",
        "User {user} password updated successfully via pam_unix"
    ],
    "WARNING": [
        "High CPU utilization detected on core {core}: {pct}%",
        "Database pool utilization reached {pct}% ({active}/{total} connections)",
        "HTTP/1.1 GET /api/v1/reports status=429 rate_limit_exceeded ip={ip}",
        "Slow query detected: SELECT * FROM audit_logs WHERE ts > NOW() duration={ms}ms",
        "Disk inode utilization exceeded threshold on /var/log: {pct}%",
        "Transient network timeout connecting to redis cache replica {ip}",
        "Worker thread worker-{worker_id} delayed by GIL lock contention ({ms}ms)",
        "TCP retransmission count exceeded threshold on eth0"
    ],
    "ERROR": [
        "Failed password for invalid user {user} from {ip} port {port} ssh2",
        "PAM 2 more authentication failures; logname= uid=0 euid=0 tty=ssh ruser= rhost={ip}",
        "HTTP/1.1 POST /api/v1/checkout status=500 InternalServerError err='Connection refused'",
        "PostgreSQL connection failed: could not connect to server at {ip}: Connection timed out",
        "Disk I/O error on device /dev/nvme0n1p2: buffer I/O error block {block}",
        "Segmentation fault (core dumped) in thread worker-{worker_id} at IP 0x7fff5c2a",
        "Permission denied (publickey) for user {user} from {ip} port {port}"
    ],
    "CRITICAL": [
        "Out of memory: Killed process {pid} (payment_worker) total-vm:{vms}kB, anon-rss:{rss}kB",
        "Kernel panic - not syncing: Fatal exception in interrupt at RIP: 0xffffffff810",
        "Critical service failure: postgresql.service entered failed state with result 'exit-code'",
        "Filesystem mounted read-only due to journal transaction failure on /dev/sda1",
        "Hardware watchdog timer expired: system reset armed"
    ],
    "SECURITY": [
        "ALERT: Repeated failed logins ({count} attempts in 60s) detected from IP {ip}",
        "SECURITY: Unauthorized sudo attempt by user {user} on {host}: command='/usr/bin/cat /etc/shadow'",
        "INTRUSION_DETECTION: SSH brute force signature matched for host {ip} targeting port {port}",
        "SECURITY_AUDIT: Sensitive file access denied on /etc/shadow for uid={uid}",
        "PRIVILEGE_ESCALATION: Process {pid} attempted capability CAP_SYS_ADMIN without authorization"
    ]
}

USERS = ["root", "admin", "deploy", "guest", "operator", "secops", "oracle", "testuser"]

def generate_log_line(ts: datetime.datetime, severity: str = None) -> str:
    if severity is None:
        # Realistic distribution: mostly INFO, moderate WARNING/ERROR, few CRITICAL/SECURITY
        weights = [0.65, 0.08, 0.15, 0.08, 0.02, 0.02]
        severities = ["INFO", "NOTICE", "WARNING", "ERROR", "CRITICAL", "SECURITY"]
        severity = random.choices(severities, weights=weights)[0]

    proc_name, pids = random.choice(PROCESSES)
    pid = random.choice(pids)
    host = random.choice(HOSTS)

    template = random.choice(LOG_TEMPLATES[severity])
    user = random.choice(USERS)
    ip = random.choice(ATTACKER_IPS if severity in ["ERROR", "SECURITY"] else INTERNAL_IPS)
    port = random.randint(30000, 65535)

    msg = template.format(
        user=user,
        service=proc_name,
        ip=ip,
        port=port,
        ms=random.randint(5, 4500),
        pct=random.randint(75, 99),
        core=random.randint(0, 15),
        active=random.randint(85, 100),
        total=100,
        worker_id=random.randint(1, 8),
        free_pages=random.randint(1024, 65536),
        block=random.randint(100000, 999999),
        pid=pid if pid > 0 else random.randint(1000, 9999),
        vms=random.randint(204800, 1048576),
        rss=random.randint(102400, 524288),
        count=random.randint(5, 50),
        host=host,
        uid=random.randint(1000, 1005)
    )

    # Standard syslog format: Mon DD HH:MM:SS host process[pid]: [SEVERITY] message
    ts_str = ts.strftime("%b %d %H:%M:%S")
    return f"{ts_str} {host} {proc_name}[{pid}]: [{severity}] {msg}"

def generate_dataset(output_path: Path, count: int, seed: int = 42, focus: str = "general"):
    random.seed(seed)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    base_time = datetime.datetime(2026, 10, 16, 8, 0, 0)

    lines = []
    current_time = base_time

    for i in range(count):
        current_time += datetime.timedelta(milliseconds=random.randint(50, 1200))
        
        if focus == "auth":
            # Higher weighting on auth and security events
            sev_weights = [0.35, 0.05, 0.15, 0.30, 0.03, 0.12]
            sev = random.choices(["INFO", "NOTICE", "WARNING", "ERROR", "CRITICAL", "SECURITY"], weights=sev_weights)[0]
        elif focus == "system":
            # Higher weighting on kernel, systemd, memory, hardware
            sev_weights = [0.55, 0.10, 0.18, 0.10, 0.05, 0.02]
            sev = random.choices(["INFO", "NOTICE", "WARNING", "ERROR", "CRITICAL", "SECURITY"], weights=sev_weights)[0]
        elif focus == "application":
            # Focus on API, web services, database latency
            sev_weights = [0.60, 0.05, 0.20, 0.12, 0.02, 0.01]
            sev = random.choices(["INFO", "NOTICE", "WARNING", "ERROR", "CRITICAL", "SECURITY"], weights=sev_weights)[0]
        else:
            sev = None

        line = generate_log_line(current_time, sev)
        lines.append(line)

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print(f"Generated {count} lines at {output_path} ({output_path.stat().st_size} bytes)")

if __name__ == "__main__":
    count = int(sys.argv[1]) if len(sys.argv) > 1 else 1000
    out_file = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("sample_generated.log")
    focus_type = sys.argv[3] if len(sys.argv) > 3 else "general"
    generate_dataset(out_file, count, focus=focus_type)
