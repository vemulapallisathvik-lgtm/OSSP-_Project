import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';

import { DashboardLayout } from './layouts/DashboardLayout';
import { Overview } from './pages/Overview';
import { AnalyzeLogs } from './pages/AnalyzeLogs';
import { ThreadMonitor } from './pages/ThreadMonitor';
import { SecurityCenter } from './pages/SecurityCenter';
import { ProcessExplorer } from './pages/ProcessExplorer';
import { IpcLaboratory } from './pages/IpcLaboratory';
import { MemoryInspector } from './pages/MemoryInspector';
import { FileSystemLab } from './pages/FileSystemLab';
import { ConcurrencyLab } from './pages/ConcurrencyLab';
import { PerformanceLab } from './pages/PerformanceLab';
import { Reports } from './pages/Reports';
import { SystemInformation } from './pages/SystemInformation';

export function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<DashboardLayout />}>
          <Route index element={<Overview />} />
          <Route path="analyze" element={<AnalyzeLogs />} />
          <Route path="threads" element={<ThreadMonitor />} />
          <Route path="security" element={<SecurityCenter />} />
          <Route path="processes" element={<ProcessExplorer />} />
          <Route path="ipc" element={<IpcLaboratory />} />
          <Route path="memory" element={<MemoryInspector />} />
          <Route path="filesystem" element={<FileSystemLab />} />
          <Route path="concurrency" element={<ConcurrencyLab />} />
          <Route path="performance" element={<PerformanceLab />} />
          <Route path="reports" element={<Reports />} />
          <Route path="system" element={<SystemInformation />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
