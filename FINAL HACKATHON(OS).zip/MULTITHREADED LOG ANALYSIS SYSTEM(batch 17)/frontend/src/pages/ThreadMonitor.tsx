import React, { useState, useEffect, useRef } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import {
  Cpu,
  Layers,
  Activity,
  Play,
  Square,
  AlertTriangle,
  Clock,
  CheckCircle,
  Database,
  ArrowRight,
  GitCommit
} from 'lucide-react';

import { api } from '../services/api';
import { Badge } from '../components/Badge';
import { StatCard } from '../components/StatCard';
import { AnalysisProgressUpdate, WorkerTelemetry } from '../types';

export const ThreadMonitor: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const [activeSessionId, setActiveSessionId] = useState<string | null>(searchParams.get('session'));
  const [recentAnalyses, setRecentAnalyses] = useState<any[]>([]);
  const [progress, setProgress] = useState<AnalysisProgressUpdate | null>(null);
  const [isLive, setIsLive] = useState<boolean>(false);

  const eventSourceRef = useRef<EventSource | null>(null);

  useEffect(() => {
    // Load recent analyses list to allow selecting active or past sessions
    api.getRecentAnalyses().then(list => {
      setRecentAnalyses(list);
      if (!activeSessionId && list.length > 0) {
        setActiveSessionId(list[0].id);
      }
    });
  }, []);

  useEffect(() => {
    if (activeSessionId) {
      connectStream(activeSessionId);
    }
    return () => {
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
    };
  }, [activeSessionId]);

  const connectStream = (analysisId: string) => {
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
    }

    setIsLive(true);
    const es = new EventSource(`/api/analyze/stream/${analysisId}`);
    eventSourceRef.current = es;

    es.onmessage = (event) => {
      try {
        const data: AnalysisProgressUpdate = JSON.parse(event.data);
        setProgress(data);
        if (['completed', 'failed', 'cancelled'].includes(data.status)) {
          setIsLive(false);
          es.close();
        }
      } catch (err) {
        console.error(err);
      }
    };

    es.onerror = () => {
      setIsLive(false);
      es.close();
      // Poll static results from DB
      api.getAnalysisResults(analysisId).then(rec => {
        setProgress({
          analysis_id: rec.id,
          status: rec.status as any,
          percent: 100,
          workers: Array.from({ length: rec.worker_count }, (_, i) => ({
            worker_id: `Worker-${i + 1}`,
            state: 'COMPLETED',
            assigned_chunk_idx: -1,
            entries_processed: Math.floor(rec.parsed_lines / rec.worker_count),
            errors_found: 0,
            start_time: null,
            elapsed_seconds: rec.duration_seconds,
            last_activity: 'Finished processing assigned tasks'
          })),
          queue_stats: {
            queue_size: 0,
            total_chunks: Math.ceil(rec.total_lines / rec.chunk_size),
            completed_chunks: Math.ceil(rec.total_lines / rec.chunk_size),
            pending_chunks: 0,
            failed_chunks: 0,
            total_processed: rec.parsed_lines,
            throughput_lps: rec.throughput_lps
          },
          severity_counts: rec.severities || {},
          recent_events: [],
          elapsed_seconds: rec.duration_seconds,
          total_lines: rec.total_lines,
          parsed_lines: rec.parsed_lines,
          malformed_lines: rec.malformed_lines
        });
      }).catch(console.error);
    };
  };

  const handleLaunchQuick = async () => {
    try {
      const res = await api.startAnalysis('sample_system.log', 'multi', 4, 250);
      setActiveSessionId(res.analysis_id);
    } catch (e: any) {
      alert(`Error starting analysis: ${e.message}`);
    }
  };

  const qStats = progress?.queue_stats || {
    queue_size: 0,
    total_chunks: 0,
    completed_chunks: 0,
    pending_chunks: 0,
    failed_chunks: 0,
    total_processed: 0,
    throughput_lps: 0
  };

  const workers: WorkerTelemetry[] = progress?.workers || [];

  return (
    <div className="space-y-6">
      {/* Top Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            Worker Thread & Task Queue Monitor
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time operating system worker threads, chunk allocation, and producer-consumer synchronization
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Session Switcher */}
          {recentAnalyses.length > 0 && (
            <select
              value={activeSessionId || ''}
              onChange={e => setActiveSessionId(e.target.value)}
              className="bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs font-mono text-cyan-300 focus:outline-none focus:border-cyan-500"
            >
              {recentAnalyses.map(a => (
                <option key={a.id} value={a.id}>
                  {a.filename} ({a.worker_count}T - {a.id})
                </option>
              ))}
            </select>
          )}

          <button
            onClick={handleLaunchQuick}
            className="px-3.5 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs shadow-lg shadow-cyan-950/40 flex items-center gap-2 transition-colors"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>Launch 4-Worker Test</span>
          </button>
        </div>
      </div>

      {/* QUEUE TELEMETRY CARDS */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="soc-card p-3.5 border-cyan-500/20">
          <p className="text-[10px] uppercase font-mono text-slate-400">Queue Backlog</p>
          <div className="text-xl font-bold text-cyan-300 font-mono mt-1">{qStats.queue_size} Chunks</div>
          <p className="text-[10px] text-slate-500 mt-0.5">Bounded Queue Cap: 50</p>
        </div>

        <div className="soc-card p-3.5 border-emerald-500/20">
          <p className="text-[10px] uppercase font-mono text-slate-400">Completed Chunks</p>
          <div className="text-xl font-bold text-emerald-400 font-mono mt-1">{qStats.completed_chunks}</div>
          <p className="text-[10px] text-slate-500 mt-0.5">Of {qStats.total_chunks} Total</p>
        </div>

        <div className="soc-card p-3.5 border-amber-500/20">
          <p className="text-[10px] uppercase font-mono text-slate-400">Pending Chunks</p>
          <div className="text-xl font-bold text-amber-300 font-mono mt-1">{qStats.pending_chunks}</div>
          <p className="text-[10px] text-slate-500 mt-0.5">In producer pipeline</p>
        </div>

        <div className="soc-card p-3.5 border-violet-500/20">
          <p className="text-[10px] uppercase font-mono text-slate-400">Throughput Rate</p>
          <div className="text-xl font-bold text-violet-300 font-mono mt-1">{qStats.throughput_lps}</div>
          <p className="text-[10px] text-slate-500 mt-0.5">Lines / Second</p>
        </div>

        <div className="soc-card p-3.5 border-slate-700/60">
          <p className="text-[10px] uppercase font-mono text-slate-400">Processed Entries</p>
          <div className="text-xl font-bold text-white font-mono mt-1">{qStats.total_processed.toLocaleString()}</div>
          <p className="text-[10px] text-slate-500 mt-0.5">Aggregated with Lock</p>
        </div>

        <div className="soc-card p-3.5 border-cyan-500/20">
          <p className="text-[10px] uppercase font-mono text-slate-400">Active Workers</p>
          <div className="text-xl font-bold text-cyan-400 font-mono mt-1">
            {workers.filter(w => w.state === 'RUNNING').length} / {workers.length}
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5">{isLive ? 'Live Processing' : 'Session Ready'}</p>
        </div>
      </div>

      {/* PRODUCER-CONSUMER QUEUE PIPELINE VISUALIZATION */}
      <div className="soc-card p-5 bg-gradient-to-r from-slate-900/90 via-[#0a1020] to-slate-900/90">
        <h2 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-4 flex items-center gap-2">
          <GitCommit className="w-4 h-4 text-cyan-400" />
          <span>Operating System Producer-Consumer Architecture</span>
        </h2>

        <div className="flex flex-col md:flex-row items-center justify-between gap-3 text-xs font-mono">
          {/* Producer */}
          <div className="flex-1 w-full p-3.5 rounded-lg bg-slate-900 border border-cyan-500/30 text-center">
            <span className="text-[10px] text-cyan-400 uppercase font-bold block mb-1">PRODUCER THREAD</span>
            <div className="text-slate-200 font-bold">Disk File Stream Reader</div>
            <div className="text-[11px] text-slate-400 mt-1">Splits lines into chunks (N lines)</div>
          </div>

          <div className="text-slate-600 font-bold">➔</div>

          {/* Bounded Queue */}
          <div className="flex-1 w-full p-3.5 rounded-lg bg-slate-900 border border-amber-500/30 text-center">
            <span className="text-[10px] text-amber-400 uppercase font-bold block mb-1">BOUNDED QUEUE</span>
            <div className="text-slate-200 font-bold">queue.Queue(maxsize=50)</div>
            <div className="text-[11px] text-amber-300 mt-1">Current Backlog: {qStats.queue_size} items</div>
          </div>

          <div className="text-slate-600 font-bold">➔</div>

          {/* Worker Pool */}
          <div className="flex-1 w-full p-3.5 rounded-lg bg-slate-900 border border-emerald-500/30 text-center">
            <span className="text-[10px] text-emerald-400 uppercase font-bold block mb-1">THREAD WORKER POOL</span>
            <div className="text-slate-200 font-bold">{workers.length} Worker Threads</div>
            <div className="text-[11px] text-slate-400 mt-1">Parallel Regex Parsing & Security</div>
          </div>

          <div className="text-slate-600 font-bold">➔</div>

          {/* Mutex Aggregator */}
          <div className="flex-1 w-full p-3.5 rounded-lg bg-slate-900 border border-violet-500/30 text-center">
            <span className="text-[10px] text-violet-400 uppercase font-bold block mb-1">SYNCHRONIZED SINK</span>
            <div className="text-slate-200 font-bold">threading.Lock Protected</div>
            <div className="text-[11px] text-violet-300 mt-1">Zero Race-Condition Aggregation</div>
          </div>
        </div>
      </div>

      {/* WORKER THREADS GRID */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-semibold text-white flex items-center gap-2">
            <Cpu className="w-4 h-4 text-cyan-400" />
            <span>Active Worker Pool ({workers.length} Threads)</span>
          </h2>
          <span className="text-xs font-mono text-slate-400">
            {isLive ? 'Broadcasting live worker telemetry' : 'Session snapshot'}
          </span>
        </div>

        {workers.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {workers.map((w) => {
              const isRunning = w.state === 'RUNNING';
              return (
                <div
                  key={w.worker_id}
                  className={`soc-card p-4 transition-all ${
                    isRunning ? 'border-cyan-500/50 shadow-md shadow-cyan-950/40 bg-slate-900/90' : 'border-slate-800'
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <div className={`w-2.5 h-2.5 rounded-full ${isRunning ? 'bg-cyan-400 animate-ping' : 'bg-slate-600'}`} />
                      <span className="font-mono text-sm font-bold text-white">{w.worker_id}</span>
                    </div>
                    <Badge label={w.state} variant={w.state} />
                  </div>

                  <div className="space-y-2 text-xs font-mono">
                    <div className="flex justify-between text-slate-400">
                      <span>Assigned Chunk:</span>
                      <span className="text-cyan-300 font-bold">
                        {w.assigned_chunk_idx >= 0 ? `#${w.assigned_chunk_idx}` : 'IDLE'}
                      </span>
                    </div>

                    <div className="flex justify-between text-slate-400">
                      <span>Entries Processed:</span>
                      <span className="text-white font-bold">{w.entries_processed.toLocaleString()}</span>
                    </div>

                    <div className="flex justify-between text-slate-400">
                      <span>Errors Detected:</span>
                      <span className={w.errors_found > 0 ? 'text-amber-400 font-bold' : 'text-slate-500'}>
                        {w.errors_found}
                      </span>
                    </div>

                    <div className="flex justify-between text-slate-400">
                      <span>Elapsed Execution:</span>
                      <span className="text-slate-300">{w.elapsed_seconds}s</span>
                    </div>

                    {/* Progress indicator */}
                    <div className="pt-2 border-t border-slate-800">
                      <p className="text-[10px] text-slate-400 truncate mb-1">
                        <strong className="text-slate-300 font-medium">Activity:</strong> {w.last_activity}
                      </p>
                      <div className="h-1.5 w-full bg-slate-950 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full transition-all duration-300 ${
                            isRunning ? 'bg-cyan-400 w-full animate-pulse' : 'bg-emerald-400 w-full'
                          }`}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="soc-card p-12 text-center text-slate-400 text-xs">
            <Cpu className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm font-semibold text-white mb-1">No Worker Threads Currently Active</p>
            <p className="text-slate-500 mb-4">Start an analysis or select a past session from the top menu.</p>
            <button
              onClick={handleLaunchQuick}
              className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs inline-flex items-center gap-2"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>Launch Worker Thread Pool</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
