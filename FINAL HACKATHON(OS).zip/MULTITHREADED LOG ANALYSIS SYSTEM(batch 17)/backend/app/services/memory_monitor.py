import os
import sys
import time
import subprocess
import psutil
from typing import Dict, Any, Optional
from ..core.config import MAX_MEMORY_ALLOCATION_MB

class MemoryMonitor:
    def __init__(self):
        self.allocation_process: Optional[subprocess.Popen] = None
        self.allocated_size_mb: int = 0
        self.allocated_pid: Optional[int] = None

    def get_system_metrics(self) -> Dict[str, Any]:
        vm = psutil.virtual_memory()
        swap = psutil.swap_memory()

        # Application process memory
        proc = psutil.Process(os.getpid())
        mem_info = proc.memory_info()

        return {
            "total_mb": round(vm.total / (1024 * 1024), 2),
            "available_mb": round(vm.available / (1024 * 1024), 2),
            "used_mb": round(vm.used / (1024 * 1024), 2),
            "percent": vm.percent,
            "swap_total_mb": round(swap.total / (1024 * 1024), 2),
            "swap_used_mb": round(swap.used / (1024 * 1024), 2),
            "swap_percent": swap.percent,
            "process_rss_mb": round(mem_info.rss / (1024 * 1024), 2),
            "process_vms_mb": round(mem_info.vms / (1024 * 1024), 2)
        }

    def allocate_bounded_memory(self, size_mb: int) -> Dict[str, Any]:
        """Safely allocate bounded memory in an isolated child process and touch pages"""
        size_mb = max(5, min(size_mb, MAX_MEMORY_ALLOCATION_MB))

        # Stop existing allocation process if running
        self.release_memory()

        # Script that allocates bytearray and touches every 4096-byte page to trigger demand paging
        code = f"""
import sys, time, psutil, os

size_bytes = {size_mb} * 1024 * 1024
proc = psutil.Process(os.getpid())
rss_before = proc.memory_info().rss

# Allocate physical pages by dirtying memory (page fault trigger)
data = bytearray(size_bytes)
for i in range(0, size_bytes, 4096):
    data[i] = 0xAA

rss_after = proc.memory_info().rss
delta_mb = round((rss_after - rss_before) / (1024 * 1024), 2)

print(f"READY:{{rss_before}}:{{rss_after}}:{{delta_mb}}", flush=True)

# Keep holding memory until terminated
while True:
    time.sleep(1)
"""
        try:
            p = subprocess.Popen(
                [sys.executable, "-c", code],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            self.allocation_process = p
            self.allocated_size_mb = size_mb
            self.allocated_pid = p.pid

            # Read confirmation line
            line = p.stdout.readline().strip()
            if line.startswith("READY:"):
                parts = line.split(":")
                rss_before = round(int(parts[1]) / (1024 * 1024), 2)
                rss_after = round(int(parts[2]) / (1024 * 1024), 2)
                delta_mb = float(parts[3])
            else:
                rss_before = 0.0
                rss_after = float(size_mb)
                delta_mb = float(size_mb)

            return {
                "status": "allocated",
                "pid": p.pid,
                "requested_mb": size_mb,
                "allocated_bytes": size_mb * 1024 * 1024,
                "process_rss_before_mb": rss_before,
                "process_rss_after_mb": rss_after,
                "delta_mb": delta_mb,
                "message": f"Successfully committed {size_mb} MB in isolated child process (PID: {p.pid}). Page frames dirtied and Resident Set Size expanded."
            }
        except Exception as e:
            return {
                "status": "error",
                "message": f"Memory allocation demonstration failed: {str(e)}"
            }

    def release_memory(self) -> Dict[str, Any]:
        """Release allocated memory by stopping child process and reclaiming frames"""
        if not self.allocation_process:
            return {"status": "none", "message": "No active memory allocation demonstration to release"}

        target_pid = self.allocated_pid
        freed_mb = self.allocated_size_mb

        try:
            self.allocation_process.terminate()
            try:
                self.allocation_process.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                self.allocation_process.kill()
                self.allocation_process.wait(timeout=1.0)
        except Exception:
            pass

        self.allocation_process = None
        self.allocated_size_mb = 0
        self.allocated_pid = None

        return {
            "status": "released",
            "freed_mb": freed_mb,
            "pid": target_pid,
            "message": f"Released {freed_mb} MB. Operating system reclaimed page table frames and child process PID {target_pid} exited cleanly."
        }

    def get_allocation_status(self) -> Dict[str, Any]:
        if self.allocation_process and self.allocation_process.poll() is None:
            return {
                "is_active": True,
                "pid": self.allocated_pid,
                "allocated_mb": self.allocated_size_mb
            }
        return {"is_active": False, "pid": None, "allocated_mb": 0}

memory_service = MemoryMonitor()
