import React, { useState } from 'react';
import {
  GitMerge,
  Play,
  Lock,
  Unlock,
  AlertTriangle,
  CheckCircle,
  ShieldCheck,
  Clock,
  Layers,
  Cpu
} from 'lucide-react';

import { api } from '../services/api';
import { CoBanner } from '../components/CoBanner';
import { RaceDemoResult, DeadlockSimResult } from '../types';

export const ConcurrencyLab: React.FC = () => {
  // Race Condition State
  const [threadCount, setThreadCount] = useState<number>(4);
  const [iterations, setIterations] = useState<number>(50000);
  const [raceResult, setRaceResult] = useState<RaceDemoResult | null>(null);
  const [raceRunning, setRaceRunning] = useState<boolean>(false);

  // Deadlock Simulation State
  const [preventDeadlock, setPreventDeadlock] = useState<boolean>(false);
  const [deadlockResult, setDeadlockResult] = useState<DeadlockSimResult | null>(null);
  const [simRunning, setSimRunning] = useState<boolean>(false);

  const handleRunRaceDemo = async () => {
    setRaceRunning(true);
    try {
      const res = await api.runRaceDemo(threadCount, iterations);
      setRaceResult(res);
    } catch (err: any) {
      alert(`Race demo failed: ${err.message}`);
    } finally {
      setRaceRunning(false);
    }
  };

  const handleRunDeadlockSim = async () => {
    setSimRunning(true);
    try {
      const res = await api.runDeadlockSim(preventDeadlock);
      setDeadlockResult(res);
    } catch (err: any) {
      alert(`Deadlock simulation failed: ${err.message}`);
    } finally {
      setSimRunning(false);
    }
  };

  return (
    <div className="space-y-6">
      <CoBanner
        outcome="CO-6"
        title="Concurrency and Synchronization"
        concept="Critical Sections, Race Conditions, Mutex Locks (threading.Lock), Coffman Deadlock Conditions, and Global Lock Hierarchy"
        implementationFile="backend/app/services/concurrency_lab.py"
        endpoint="POST /api/concurrency/race-demo | POST /api/concurrency/deadlock-sim"
        verificationTip="Run the Race Condition Experiment with 4 threads and 50,000 iterations to verify non-atomic update loss vs. mutex integrity. Run the Deadlock Simulator to test Circular Wait vs. Resource Hierarchy."
      />

      {/* SECTION 1: RACE CONDITION EXPERIMENT */}
      <div className="soc-card p-6 border-l-4 border-l-cyan-500 bg-slate-900/80 space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Cpu className="w-4 h-4 text-cyan-400" />
              <span>Controlled Shared-Counter Race Condition Experiment</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Runs multiple concurrent threads modifying a shared memory counter with vs. without mutex synchronization.
            </p>
          </div>

          <button
            onClick={handleRunRaceDemo}
            disabled={raceRunning}
            className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs flex items-center gap-2 shadow-lg shadow-cyan-950/40 transition-colors"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{raceRunning ? 'Executing Threads...' : 'Run Race Experiment'}</span>
          </button>
        </div>

        {/* Configuration sliders */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-1">
          <div>
            <div className="flex justify-between text-xs mb-1 font-mono">
              <span className="text-slate-400">Thread Count:</span>
              <span className="text-cyan-300 font-bold">{threadCount} Threads</span>
            </div>
            <input
              type="range"
              min="2"
              max="16"
              step="2"
              value={threadCount}
              onChange={e => setThreadCount(parseInt(e.target.value))}
              className="w-full accent-cyan-400 bg-slate-800"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
              <span>2</span>
              <span>4</span>
              <span>8</span>
              <span>12</span>
              <span>16</span>
            </div>
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1 font-mono">
              <span className="text-slate-400">Iterations Per Thread:</span>
              <span className="text-cyan-300 font-bold">{iterations.toLocaleString()}</span>
            </div>
            <select
              value={iterations}
              onChange={e => setIterations(parseInt(e.target.value))}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              <option value="10000">10,000 iterations / thread</option>
              <option value="25000">25,000 iterations / thread</option>
              <option value="50000">50,000 iterations / thread (Recommended)</option>
              <option value="100000">100,000 iterations / thread</option>
            </select>
          </div>
        </div>

        {/* RACE RESULT COMPARISON */}
        {raceResult && (
          <div className="space-y-4 pt-2 font-mono">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Unsynchronized (Unsafe) Result */}
              <div className="p-4 rounded-lg bg-slate-950 border border-red-900/40 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-red-400 uppercase font-bold flex items-center gap-1.5">
                    <Unlock className="w-3.5 h-3.5" />
                    <span>UNSYNCHRONIZED (NO LOCK)</span>
                  </span>
                  <span className="text-[10px] text-slate-500">{raceResult.unsafe_time_ms} ms</span>
                </div>

                <div className="text-2xl font-bold text-red-400">
                  {raceResult.unsafe_value.toLocaleString()}
                </div>

                <div className="text-xs text-slate-400 space-y-1 pt-1 border-t border-slate-900">
                  <div className="flex justify-between">
                    <span>Expected Total:</span>
                    <span className="text-white font-bold">{raceResult.expected_value.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-red-400">
                    <span>Lost Updates:</span>
                    <span className="font-bold">
                      -{raceResult.unsafe_lost_updates.toLocaleString()} ({((raceResult.unsafe_lost_updates / raceResult.expected_value) * 100).toFixed(1)}% loss)
                    </span>
                  </div>
                </div>
              </div>

              {/* Synchronized (threading.Lock) Result */}
              <div className="p-4 rounded-lg bg-slate-950 border border-emerald-900/40 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-emerald-400 uppercase font-bold flex items-center gap-1.5">
                    <Lock className="w-3.5 h-3.5" />
                    <span>SYNCHRONIZED (MUTEX LOCK)</span>
                  </span>
                  <span className="text-[10px] text-slate-500">{raceResult.safe_time_ms} ms</span>
                </div>

                <div className="text-2xl font-bold text-emerald-400">
                  {raceResult.safe_value.toLocaleString()}
                </div>

                <div className="text-xs text-slate-400 space-y-1 pt-1 border-t border-slate-900">
                  <div className="flex justify-between">
                    <span>Expected Total:</span>
                    <span className="text-white font-bold">{raceResult.expected_value.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between text-emerald-400">
                    <span>Integrity:</span>
                    <span className="font-bold">100.0% (0 Lost Updates)</span>
                  </div>
                </div>
              </div>
            </div>

            <p className="p-3 rounded bg-slate-950 border border-slate-800 text-xs text-slate-300 font-sans leading-relaxed">
              {raceResult.explanation}
            </p>
          </div>
        )}
      </div>

      {/* SECTION 2: DEADLOCK SIMULATION & PREVENTION */}
      <div className="soc-card p-6 border-l-4 border-l-amber-500 bg-slate-900/80 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>Coffman Deadlock Simulation & Hierarchy Prevention</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Demonstrates circular wait between two threads acquiring Lock A and Lock B vs. Global Resource Ordering hierarchy.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <label className="flex items-center gap-2 text-xs font-mono text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={preventDeadlock}
                onChange={e => setPreventDeadlock(e.target.checked)}
                className="rounded bg-slate-800 border-slate-700 text-cyan-500"
              />
              <span className={preventDeadlock ? 'text-emerald-400 font-bold' : 'text-slate-400'}>
                Enforce Strict Lock Hierarchy (A ➔ B)
              </span>
            </label>

            <button
              onClick={handleRunDeadlockSim}
              disabled={simRunning}
              className={`px-4 py-2 rounded-lg font-medium text-xs flex items-center gap-1.5 transition-colors ${
                preventDeadlock
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                  : 'bg-amber-600 hover:bg-amber-500 text-white'
              }`}
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{simRunning ? 'Simulating...' : preventDeadlock ? 'Test Deadlock Prevention' : 'Trigger Deadlock Simulation'}</span>
            </button>
          </div>
        </div>

        {/* DEADLOCK RESULT & TIMELINE */}
        {deadlockResult && (
          <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <div className="flex items-center gap-2">
                {deadlockResult.deadlock_occurred ? (
                  <AlertTriangle className="w-4 h-4 text-red-400" />
                ) : (
                  <CheckCircle className="w-4 h-4 text-emerald-400" />
                )}
                <span className={`font-bold ${deadlockResult.deadlock_occurred ? 'text-red-400' : 'text-emerald-400'}`}>
                  {deadlockResult.status} ({deadlockResult.strategy})
                </span>
              </div>
            </div>

            <p className="text-slate-300 font-sans text-xs">{deadlockResult.message}</p>

            {/* Step by step timeline */}
            <div>
              <span className="text-[10px] text-slate-400 font-bold uppercase block mb-1.5">EXECUTION TIMELINE:</span>
              <div className="space-y-1">
                {deadlockResult.timeline.map((step, idx) => (
                  <div
                    key={idx}
                    className={`p-2 rounded text-[11px] ${
                      step.includes('[TIMEOUT]')
                        ? 'bg-red-950/40 text-red-300 border border-red-900/40'
                        : step.includes('Thread-1')
                        ? 'bg-slate-900 text-cyan-300'
                        : 'bg-slate-900 text-emerald-300'
                    }`}
                  >
                    {step}
                  </div>
                ))}
              </div>
            </div>

            <p className="text-[11px] text-slate-500 italic pt-1">{deadlockResult.details}</p>
          </div>
        )}
      </div>

      {/* COFFMAN CONDITIONS EDUCATIONAL PANEL */}
      <div className="soc-card p-5 space-y-4">
        <h2 className="text-sm font-semibold text-white flex items-center gap-2">
          <Layers className="w-4 h-4 text-cyan-400" />
          <span>The Four Coffman Conditions for Deadlock</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-xs font-mono">
          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-amber-400 font-bold block mb-1">1. Mutual Exclusion</span>
            <p className="text-slate-400 text-[11px] font-sans">
              Only one thread can hold a resource at a given time (e.g. mutex lock).
            </p>
          </div>

          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-amber-400 font-bold block mb-1">2. Hold and Wait</span>
            <p className="text-slate-400 text-[11px] font-sans">
              Threads holding at least one resource request additional resources held by others.
            </p>
          </div>

          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-amber-400 font-bold block mb-1">3. No Preemption</span>
            <p className="text-slate-400 text-[11px] font-sans">
              Resources cannot be forcibly confiscated; they can only be released voluntarily.
            </p>
          </div>

          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-red-400 font-bold block mb-1">4. Circular Wait</span>
            <p className="text-slate-400 text-[11px] font-sans">
              A closed chain of threads exists where each holds a resource required by the next.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
