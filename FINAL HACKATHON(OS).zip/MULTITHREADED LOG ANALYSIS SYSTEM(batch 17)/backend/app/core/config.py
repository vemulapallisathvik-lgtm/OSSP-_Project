import os
import sys
import platform
from pathlib import Path

# Paths
APP_DIR = Path(__file__).resolve().parent.parent
BACKEND_DIR = APP_DIR.parent
PROJECT_ROOT = BACKEND_DIR.parent

DATASETS_DIR = PROJECT_ROOT / "datasets"
UPLOADS_DIR = PROJECT_ROOT / "uploads"
REPORTS_DIR = PROJECT_ROOT / "reports"
DATA_DIR = BACKEND_DIR / "data"

for path in [DATASETS_DIR, UPLOADS_DIR, REPORTS_DIR, DATA_DIR]:
    path.mkdir(parents=True, exist_ok=True)

DB_PATH = DATA_DIR / "threadwatch.db"

# Platform info
IS_WINDOWS = platform.system().lower() == "windows"
IS_LINUX = platform.system().lower() == "linux"
IS_DARWIN = platform.system().lower() == "darwin"
PLATFORM_NAME = platform.system()
PLATFORM_RELEASE = platform.release()

# Security & Processing Constraints
MAX_FILE_SIZE_BYTES = 100 * 1024 * 1024  # 100 MB
MAX_WORKER_THREADS = 16
DEFAULT_WORKER_THREADS = 4
DEFAULT_CHUNK_SIZE = 500
MAX_CHUNK_SIZE = 5000
MAX_MEMORY_ALLOCATION_MB = 100  # Max memory bounded allocation in demo

# Allowed read-only safe commands for CO-1 OS service layer demonstration
ALLOWED_COMMANDS = {
    "whoami": ["whoami"],
    "hostname": ["hostname"],
    "python_version": [sys.executable, "--version"],
    "date": ["date", "/t"] if IS_WINDOWS else ["date"],
    "system_platform": ["python", "-c", "import platform; print(platform.platform())"],
    "cpu_count": ["python", "-c", "import os; print(f'Cores: {os.cpu_count()}')"]
}

if IS_LINUX or IS_DARWIN:
    ALLOWED_COMMANDS["uname"] = ["uname", "-a"]
    ALLOWED_COMMANDS["uptime"] = ["uptime"]
    ALLOWED_COMMANDS["df"] = ["df", "-h"]
    ALLOWED_COMMANDS["free"] = ["free", "-h"] if IS_LINUX else ["vm_stat"]
else:
    # Windows equivalents for system monitoring commands
    ALLOWED_COMMANDS["uname"] = ["cmd", "/c", "ver"]
    ALLOWED_COMMANDS["systeminfo_summary"] = ["python", "-c", "import platform, sys; print(f'{platform.system()} {platform.release()} ({platform.machine()}) Python {sys.version.split()[0]}')"]
    ALLOWED_COMMANDS["disk_usage"] = ["python", "-c", "import shutil; total, used, free = shutil.disk_usage('.'); print(f'Total: {total//(1024**3)}GB, Used: {used//(1024**3)}GB, Free: {free//(1024**3)}GB')"]
