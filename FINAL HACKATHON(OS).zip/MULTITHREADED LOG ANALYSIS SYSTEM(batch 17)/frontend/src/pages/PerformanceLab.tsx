import React, { useState, useEffect } from 'react';
import {
  Zap,
  Play,
  Clock,
  Activity,
  Cpu,
  Layers,
  BarChart2,
  CheckCircle,
  HelpCircle,
  RefreshCw
} from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from 'recharts';

import { api } from '../services/api';
import { StatCard } from '../components/StatCard';
import { BenchmarkRecord } from '../types';

export const PerformanceLab: React.FC = () => {
  const [datasetName, setDatasetName] = useState<string>('sample_benchmark.log');
  const [workerCount, setWorkerCount] = useState<number>(4);
  const [chunkSize, setChunkSize] = useState<number>(500);
  const [benchmarking, setBenchmarking] = useState<boolean>(false);
  const [result, setResult] = useState<BenchmarkRecord | null>(null);
  const [history, setHistory] = useState<BenchmarkRecord[]>([]);

  const loadHistory = () => {
    api.getBenchmarkHistory().then(res => setHistory(res)).catch(console.error);
  };

  useEffect(() => {
    loadHistory();
  }, []);

  const handleRunBenchmark = async () => {
    setBenchmarking(true);
    try {
      const res = await api.runBenchmark(datasetName, workerCount, chunkSize);
      setResult(res);
      loadHistory();
    } catch (err: any) {
      alert(`Benchmark failed: ${err.message}`);
    } finally {
      setBenchmarking(false);
    }
  };

  const timeComparisonData = result ? [
    { name: 'Single-Threaded (1T)', duration_s: result.single_thread_time, fill: '#f59e0b' },
    { name: `Multi-Threaded (${result.worker_count}T)`, duration_s: result.multi_thread_time, fill: '#06b6d4' }
  ] : [];

  const throughputData = result ? [
    { name: 'Single-Threaded', lps: result.single_throughput_lps || 0, fill: '#f59e0b' },
    { name: `Multi-Threaded (${result.worker_count}T)`, lps: result.multi_throughput_lps || 0, fill: '#10b981' }
  ] : [];

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            Multithreaded Performance Benchmark Lab
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Empirical speedup and parallel efficiency measurements using monotonic wall-clock timers
          </p>
        </div>

        <button
          onClick={loadHistory}
          className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs self-start sm:self-auto"
          title="Refresh benchmark history"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
      </div>

      {/* BENCHMARK RUNNER CONTROLS */}
      <div className="soc-card p-6 border-l-4 border-l-cyan-500 bg-slate-900/80 space-y-4">
        <h2 className="text-sm font-bold text-white flex items-center gap-2">
          <Zap className="w-4 h-4 text-cyan-400" />
          <span>Configure & Run Parallel Benchmark</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
          <div>
            <label className="text-slate-400 block mb-1">Target Dataset:</label>
            <select
              value={datasetName}
              onChange={e => setDatasetName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              <option value="sample_benchmark.log">sample_benchmark.log (5,000 lines)</option>
              <option value="sample_system.log">sample_system.log (1,200 lines)</option>
              <option value="sample_auth.log">sample_auth.log (1,200 lines)</option>
              <option value="sample_application.log">sample_application.log (1,200 lines)</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Worker Threads (N):</label>
            <select
              value={workerCount}
              onChange={e => setWorkerCount(parseInt(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              <option value="2">2 Worker Threads</option>
              <option value="4">4 Worker Threads (Standard)</option>
              <option value="8">8 Worker Threads (High Concurrency)</option>
              <option value="12">12 Worker Threads</option>
              <option value="16">16 Worker Threads</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Chunk Size:</label>
            <select
              value={chunkSize}
              onChange={e => setChunkSize(parseInt(e.target.value))}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              <option value="100">100 lines / chunk</option>
              <option value="250">250 lines / chunk</option>
              <option value="500">500 lines / chunk (Recommended)</option>
              <option value="1000">1,000 lines / chunk</option>
            </select>
          </div>
        </div>

        <div className="pt-2">
          <button
            onClick={handleRunBenchmark}
            disabled={benchmarking}
            className="w-full py-2.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs flex items-center justify-center gap-2 shadow-lg shadow-cyan-950/40 transition-colors"
          >
            <Play className="w-4 h-4 fill-current" />
            <span>{benchmarking ? 'Running Parallel Benchmark Test...' : 'Run Single-Thread vs Multi-Thread Benchmark'}</span>
          </button>
        </div>
      </div>

      {/* BENCHMARK RESULTS CARDS */}
      {result && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <StatCard
              title="Measured Speedup"
              value={`${result.speedup}x`}
              subtitle="T(single) / T(multi)"
              icon={Zap}
              color="cyan"
              badge={`S = ${result.speedup}`}
            />
            <StatCard
              title="Parallel Efficiency"
              value={`${(result.efficiency * 100).toFixed(1)}%`}
              subtitle="Speedup / N Workers"
              icon={Activity}
              color="emerald"
              badge={`E = ${result.efficiency}`}
            />
            <StatCard
              title="Multi-Thread Time"
              value={`${result.multi_thread_time}s`}
              subtitle={`Single-thread: ${result.single_thread_time}s`}
              icon={Clock}
              color="violet"
            />
            <StatCard
              title="Peak Throughput"
              value={`${(result.multi_throughput_lps || 0).toLocaleString()} LPS`}
              subtitle={`Single-thread: ${(result.single_throughput_lps || 0).toLocaleString()} LPS`}
              icon={Cpu}
              color="amber"
            />
          </div>

          {/* Side by side comparison charts */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="soc-card p-5">
              <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-3 font-mono">
                Wall-Clock Execution Time (Lower is Faster)
              </h3>
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={timeComparisonData}>
                    <XAxis dataKey="name" stroke="#64748b" fontSize={11} />
                    <YAxis stroke="#64748b" fontSize={11} unit="s" />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '8px', color: '#fff' }}
                    />
                    <Bar dataKey="duration_s" radius={[4, 4, 0, 0]} name="Duration (s)">
                      {timeComparisonData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.fill} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="soc-card p-5">
              <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-3 font-mono">
                Log Parsing Throughput (Lines / Sec)
              </h3>
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={throughputData}>
                    <XAxis dataKey="name" stroke="#64748b" fontSize={11} />
                    <YAxis stroke="#64748b" fontSize={11} />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '8px', color: '#fff' }}
                    />
                    <Bar dataKey="lps" radius={[4, 4, 0, 0]} name="Throughput (LPS)">
                      {throughputData.map((entry, index) => (
                        <Cell key={`cell-tp-${index}`} fill={entry.fill} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 text-xs text-slate-300 leading-relaxed font-sans">
            <strong className="text-cyan-400 font-semibold font-mono block mb-1">OS Concurrency & GIL Analysis:</strong>
            {result.explanation}
          </div>
        </div>
      )}

      {/* BENCHMARK HISTORY TABLE */}
      <div className="soc-card p-5 space-y-3">
        <h2 className="text-sm font-semibold text-white">Historical Benchmark Runs (SQLite)</h2>
        {history.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="pb-2">Dataset</th>
                  <th className="pb-2">Lines</th>
                  <th className="pb-2">Workers</th>
                  <th className="pb-2">Single-T Time</th>
                  <th className="pb-2">Multi-T Time</th>
                  <th className="pb-2">Speedup</th>
                  <th className="pb-2">Efficiency</th>
                  <th className="pb-2">Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {history.map(b => (
                  <tr key={b.id} className="hover:bg-slate-800/30">
                    <td className="py-2.5 text-white font-sans font-medium">{b.dataset_name}</td>
                    <td className="py-2.5 text-slate-400">{b.total_lines?.toLocaleString()}</td>
                    <td className="py-2.5 text-cyan-300">{b.worker_count}T</td>
                    <td className="py-2.5 text-slate-400">{b.single_thread_time}s</td>
                    <td className="py-2.5 text-white font-bold">{b.multi_thread_time}s</td>
                    <td className="py-2.5 text-cyan-400 font-bold">{b.speedup}x</td>
                    <td className="py-2.5 text-emerald-400 font-bold">{(b.efficiency * 100).toFixed(0)}%</td>
                    <td className="py-2.5 text-slate-500">{b.created_at.split('T')[0]}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-slate-500 text-xs py-4 text-center">No benchmark history stored yet</div>
        )}
      </div>
    </div>
  );
};
