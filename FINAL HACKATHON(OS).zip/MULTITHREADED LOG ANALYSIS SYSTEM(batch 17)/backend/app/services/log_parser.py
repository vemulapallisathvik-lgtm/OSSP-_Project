import re
from typing import Optional, Dict, Any, List, Tuple
from collections import defaultdict
from ..models.schemas import LogEntry

# Regex patterns for syslog and timestamps
SYSLOG_PATTERN = re.compile(
    r'^(?P<timestamp>[A-Z][a-z]{2}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})\s+'
    r'(?P<host>[^\s]+)\s+'
    r'(?P<proc>[a-zA-Z0-9_\-\.]+)(?:\[(?P<pid>\d+)\])?:\s+'
    r'(?:\[(?P<severity>DEBUG|INFO|NOTICE|WARNING|WARN|ERROR|CRITICAL|CRIT|FATAL|SECURITY|ALERT)\]\s+)?'
    r'(?P<message>.*)$'
)

ISO_PATTERN = re.compile(
    r'^(?P<timestamp>\d{4}-\d{2}-\d{2}[T\s]\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?)\s+'
    r'(?:\[(?P<severity>DEBUG|INFO|NOTICE|WARNING|WARN|ERROR|CRITICAL|CRIT|FATAL|SECURITY|ALERT)\]\s+)?'
    r'(?:(?P<proc>[a-zA-Z0-9_\-\.]+)(?:\[(?P<pid>\d+)\])?:\s+)?'
    r'(?P<message>.*)$'
)

IP_PATTERN = re.compile(r'\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b')
PID_PATTERN = re.compile(r'\b(?:pid|PID|process|Process)[:=\s]+(\d+)\b')

SEVERITY_KEYWORDS = {
    "CRITICAL": ["critical", "fatal", "panic", "emergency", "oom-killer", "out of memory"],
    "SECURITY": ["security", "intrusion", "brute force", "unauthorized sudo", "privilege_escalation", "alert"],
    "ERROR": ["error", "failed", "failure", "exception", "segmentation fault", "segfault", "refused"],
    "WARNING": ["warning", "warn", "timeout", "high cpu", "exhausted", "delayed", "contention"],
    "NOTICE": ["notice", "reloaded", "reniced"],
    "INFO": ["info", "started", "accepted", "completed", "success", "session opened"],
    "DEBUG": ["debug", "trace"]
}

def normalize_severity(sev_str: Optional[str], message: str) -> str:
    if sev_str:
        s = sev_str.upper()
        if s in ["WARN"]:
            return "WARNING"
        if s in ["CRIT", "FATAL", "EMERG"]:
            return "CRITICAL"
        if s in ["ALERT"]:
            return "SECURITY"
        if s in ["DEBUG", "INFO", "NOTICE", "WARNING", "ERROR", "CRITICAL", "SECURITY"]:
            return s

    msg_lower = message.lower()
    for sev, keywords in SEVERITY_KEYWORDS.items():
        for kw in keywords:
            if kw in msg_lower:
                return sev

    return "INFO"

def parse_log_line(line: str) -> LogEntry:
    raw = line.rstrip("\r\n")
    if not raw.strip():
        return LogEntry(
            message="[EMPTY LINE]",
            raw_line=raw,
            is_fallback=True
        )

    # 1. Try standard syslog format
    m = SYSLOG_PATTERN.match(raw)
    if m:
        data = m.groupdict()
        msg = data["message"]
        sev = normalize_severity(data.get("severity"), msg)
        ip_match = IP_PATTERN.search(msg)
        return LogEntry(
            timestamp=data.get("timestamp"),
            severity=sev,
            host=data.get("host"),
            process_name=data.get("proc"),
            process_id=int(data["pid"]) if data.get("pid") else None,
            message=msg,
            ip_address=ip_match.group(0) if ip_match else None,
            raw_line=raw,
            is_fallback=False
        )

    # 2. Try ISO timestamp format
    m_iso = ISO_PATTERN.match(raw)
    if m_iso:
        data = m_iso.groupdict()
        msg = data["message"]
        sev = normalize_severity(data.get("severity"), msg)
        ip_match = IP_PATTERN.search(msg)
        return LogEntry(
            timestamp=data.get("timestamp"),
            severity=sev,
            process_name=data.get("proc"),
            process_id=int(data["pid"]) if data.get("pid") else None,
            message=msg,
            ip_address=ip_match.group(0) if ip_match else None,
            raw_line=raw,
            is_fallback=False
        )

    # 3. Fallback parser: never drop lines, parse tokens gracefully
    ip_match = IP_PATTERN.search(raw)
    pid_match = PID_PATTERN.search(raw)
    sev = normalize_severity(None, raw)
    
    return LogEntry(
        timestamp=None,
        severity=sev,
        message=raw,
        ip_address=ip_match.group(0) if ip_match else None,
        process_id=int(pid_match.group(1)) if pid_match else None,
        raw_line=raw,
        is_fallback=True
    )

def evaluate_security_rules(entries: List[LogEntry], analysis_id: str) -> List[Dict[str, Any]]:
    """
    Deterministic rule-based security detection engine:
    - Failed authentication bursts
    - Suspicious external IPs
    - Privilege escalation
    - Out-of-memory / Kernel panic events
    - Permission denied / unauthorized access bursts
    """
    findings: List[Dict[str, Any]] = []

    ip_failed_logins = defaultdict(list)
    ip_access_denied = defaultdict(list)
    service_failures = []
    priv_escalations = []
    critical_crashes = []

    for entry in entries:
        msg = entry.message.lower()

        # Check Failed Logins
        if ("failed password" in msg or "authentication failure" in msg or "login failed" in msg) and entry.ip_address:
            ip_failed_logins[entry.ip_address].append(entry)

        # Check Access Denied / 403 / Permission Denied
        if "permission denied" in msg or "access denied" in msg or "status=403" in msg:
            if entry.ip_address:
                ip_access_denied[entry.ip_address].append(entry)

        # Check Privilege Escalation
        if "unauthorized sudo" in msg or "privilege_escalation" in msg or "cap_sys_admin" in msg or "/etc/shadow" in msg:
            priv_escalations.append(entry)

        # Check Service Failures
        if "failed state" in msg or "critical service failure" in msg or "service exited" in msg:
            service_failures.append(entry)

        # Check Critical OS / Kernel crashes
        if "out of memory" in msg or "kernel panic" in msg or "segmentation fault" in msg or "core dumped" in msg:
            critical_crashes.append(entry)

    # Rule 1: Brute Force Login Detection
    for ip, events in ip_failed_logins.items():
        if len(events) >= 3:
            findings.append({
                "analysis_id": analysis_id,
                "rule_name": "BRUTE_FORCE_SSH",
                "severity": "CRITICAL" if len(events) >= 10 else "ERROR",
                "title": f"Repeated Authentication Failures ({len(events)} attempts)",
                "description": f"Detected {len(events)} failed login attempts targeting SSH/PAM from remote IP {ip}.",
                "evidence": f"First failure: {events[0].message[:120]}...",
                "ip_address": ip,
                "process_id": events[0].process_id
            })

    # Rule 2: Frequent Access Denied Events
    for ip, events in ip_access_denied.items():
        if len(events) >= 3:
            findings.append({
                "analysis_id": analysis_id,
                "rule_name": "REPEATED_ACCESS_DENIED",
                "severity": "WARNING",
                "title": f"Repeated Permission Denied Anomaly ({len(events)} events)",
                "description": f"Host or process at IP {ip} triggered {len(events)} permission/access denied errors.",
                "evidence": f"Sample: {events[0].message[:120]}",
                "ip_address": ip,
                "process_id": events[0].process_id
            })

    # Rule 3: Privilege Escalation Warnings
    for ev in priv_escalations[:10]:
        findings.append({
            "analysis_id": analysis_id,
            "rule_name": "PRIVILEGE_ESCALATION_ATTEMPT",
            "severity": "CRITICAL",
            "title": "Suspicious Privilege Escalation Event",
            "description": f"Process or user attempted restricted capabilities or unauthorized sudo command: {ev.message[:140]}",
            "evidence": ev.raw_line[:180],
            "ip_address": ev.ip_address,
            "process_id": ev.process_id
        })

    # Rule 4: Critical Service & Kernel Crashes
    for ev in critical_crashes[:10]:
        findings.append({
            "analysis_id": analysis_id,
            "rule_name": "CRITICAL_SYSTEM_CRASH",
            "severity": "CRITICAL",
            "title": "Kernel Panic / OOM-Killer / Segfault Event",
            "description": f"Operating system detected fatal crash or memory exhaustion: {ev.message[:140]}",
            "evidence": ev.raw_line[:180],
            "ip_address": ev.ip_address,
            "process_id": ev.process_id
        })

    return findings
