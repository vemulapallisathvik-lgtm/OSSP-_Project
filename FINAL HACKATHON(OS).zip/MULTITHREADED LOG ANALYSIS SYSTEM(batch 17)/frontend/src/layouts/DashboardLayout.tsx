import React, { useState, useEffect } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import {
  Shield,
  LayoutDashboard,
  FileSearch,
  Cpu,
  ShieldAlert,
  Activity,
  Share2,
  HardDrive,
  FolderGit2,
  GitMerge,
  Zap,
  FileText,
  Layers,
  CheckCircle2,
  AlertCircle,
  Menu,
  X,
  Clock,
  Terminal
} from 'lucide-react';
import { api } from '../services/api';

const NAV_ITEMS = [
  { name: 'Overview', path: '/', icon: LayoutDashboard },
  { name: 'Analyze Logs', path: '/analyze', icon: FileSearch },
  { name: 'Thread Monitor', path: '/threads', icon: Cpu, badge: 'Core' },
  { name: 'Security Center', path: '/security', icon: ShieldAlert },
  { name: 'Process Explorer', path: '/processes', icon: Activity, co: 'CO-2' },
  { name: 'IPC Laboratory', path: '/ipc', icon: Share2, co: 'CO-3' },
  { name: 'Memory Inspector', path: '/memory', icon: HardDrive, co: 'CO-4' },
  { name: 'File System Lab', path: '/filesystem', icon: FolderGit2, co: 'CO-5' },
  { name: 'Concurrency Lab', path: '/concurrency', icon: GitMerge, co: 'CO-6' },
  { name: 'Performance Lab', path: '/performance', icon: Zap },
  { name: 'Reports', path: '/reports', icon: FileText },
  { name: 'System Information', path: '/system', icon: Layers, co: 'CO-1' },
];

export const DashboardLayout: React.FC = () => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [backendOnline, setBackendOnline] = useState<boolean | null>(null);
  const [currentTime, setCurrentTime] = useState<string>('');
  const location = useLocation();

  // Periodic health check
  useEffect(() => {
    const checkHealth = () => {
      api.getHealth()
        .then(() => setBackendOnline(true))
        .catch(() => setBackendOnline(false));
    };

    checkHealth();
    const interval = setInterval(checkHealth, 8000);
    return () => clearInterval(interval);
  }, []);

  // Real-time clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(now.toLocaleTimeString('en-US', { hour12: false }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const currentPage = NAV_ITEMS.find(item => item.path === location.pathname) || NAV_ITEMS[0];

  return (
    <div className="flex h-screen bg-[#060913] text-slate-100 overflow-hidden font-sans">
      {/* SIDEBAR */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 flex flex-col w-64 bg-[#0a0f1d] border-r border-slate-800/80 transition-all duration-300 md:static ${
          sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0 md:w-20'
        }`}
      >
        {/* Brand header */}
        <div className="flex items-center justify-between h-16 px-4 border-b border-slate-800/80 bg-[#0a0f1d]">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-9 h-9 rounded-lg bg-cyan-500/10 border border-cyan-500/30 text-cyan-400">
              <Shield className="w-5 h-5" />
            </div>
            {sidebarOpen && (
              <div>
                <h1 className="text-sm font-bold tracking-wider text-white">THREADWATCH</h1>
                <p className="text-[10px] text-cyan-400 font-mono tracking-tight">Multithreaded Log SOC</p>
              </div>
            )}
          </div>
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-1 rounded text-slate-400 hover:text-white md:hidden"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation list */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;

            return (
              <NavLink
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-cyan-500/15 text-cyan-400 border border-cyan-500/30 shadow-sm shadow-cyan-950/50'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-cyan-400' : 'text-slate-400'}`} />
                {sidebarOpen && (
                  <span className="flex-1 truncate">{item.name}</span>
                )}
                {sidebarOpen && item.co && (
                  <span className="px-1.5 py-0.5 text-[9px] font-mono font-bold rounded bg-slate-800 text-cyan-300 border border-slate-700">
                    {item.co}
                  </span>
                )}
                {sidebarOpen && item.badge && (
                  <span className="px-1.5 py-0.5 text-[9px] font-mono font-bold rounded bg-cyan-900/60 text-cyan-300 border border-cyan-700/50">
                    {item.badge}
                  </span>
                )}
              </NavLink>
            );
          })}
        </nav>

        {/* Sidebar footer: OS Hackathon Badge */}
        {sidebarOpen && (
          <div className="p-3 m-3 rounded-lg bg-slate-900/90 border border-slate-800 text-xs">
            <div className="flex items-center gap-2 mb-1">
              <Terminal className="w-3.5 h-3.5 text-cyan-400" />
              <span className="font-semibold text-white text-[11px]">OS Hackathon Platform</span>
            </div>
            <p className="text-[10px] text-slate-400 leading-relaxed">
              Real multithreaded log analysis mapped to CO-1 through CO-6.
            </p>
          </div>
        )}
      </aside>

      {/* MAIN CONTAINER */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* TOP BAR */}
        <header className="h-16 px-6 bg-[#0a0f1d] border-b border-slate-800/80 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white md:inline-flex"
            >
              <Menu className="w-4 h-4" />
            </button>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400">Platform</span>
                <span className="text-xs text-slate-600">/</span>
                <span className="text-sm font-semibold text-white">{currentPage.name}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {/* Live Clock */}
            <div className="hidden sm:flex items-center gap-2 px-3 py-1 rounded-md bg-slate-900 border border-slate-800 text-xs font-mono text-slate-300">
              <Clock className="w-3.5 h-3.5 text-cyan-400" />
              <span>{currentTime}</span>
            </div>

            {/* Backend Connection Indicator */}
            <div className="flex items-center gap-2 px-3 py-1 rounded-md bg-slate-900 border border-slate-800 text-xs font-mono">
              {backendOnline === true ? (
                <>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-emerald-400 font-medium">BACKEND ONLINE</span>
                </>
              ) : backendOnline === false ? (
                <>
                  <span className="w-2 h-2 rounded-full bg-red-400" />
                  <span className="text-red-400 font-medium">DISCONNECTED</span>
                </>
              ) : (
                <>
                  <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                  <span className="text-amber-400 font-medium">CONNECTING</span>
                </>
              )}
            </div>
          </div>
        </header>

        {/* PAGE CONTENT */}
        <main className="flex-1 overflow-y-auto p-6 md:p-8 bg-[#060913]">
          <div className="max-w-7xl mx-auto">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
};
