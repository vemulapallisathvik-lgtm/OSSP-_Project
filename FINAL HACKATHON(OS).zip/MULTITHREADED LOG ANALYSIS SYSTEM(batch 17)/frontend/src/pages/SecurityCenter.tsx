import React, { useState, useEffect } from 'react';
import {
  ShieldAlert,
  Flame,
  AlertTriangle,
  Search,
  Filter,
  CheckCircle,
  Download,
  Terminal,
  RefreshCw,
  Eye,
  Check
} from 'lucide-react';

import { api } from '../services/api';
import { Badge } from '../components/Badge';
import { StatCard } from '../components/StatCard';
import { SecurityFinding } from '../types';

export const SecurityCenter: React.FC = () => {
  const [findings, setFindings] = useState<SecurityFinding[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [sevFilter, setSevFilter] = useState('ALL');
  const [unreviewedOnly, setUnreviewedOnly] = useState(false);

  const loadFindings = () => {
    setLoading(true);
    api.getSecurityFindings(unreviewedOnly)
      .then(res => setFindings(res))
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadFindings();
  }, [unreviewedOnly]);

  const handleToggleReview = async (id: number) => {
    try {
      await api.toggleReviewFinding(id);
      // Toggle locally
      setFindings(prev => prev.map(f => f.id === id ? { ...f, is_reviewed: f.is_reviewed === 1 ? 0 : 1 } : f));
    } catch (err: any) {
      alert(`Review error: ${err.message}`);
    }
  };

  const handleExportJson = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(filteredFindings, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `threadwatch_security_findings_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const filteredFindings = findings.filter(f => {
    const matchesSev = sevFilter === 'ALL' || f.severity === sevFilter;
    const matchesSearch = searchTerm === '' ||
      f.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      f.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (f.ip_address && f.ip_address.includes(searchTerm)) ||
      (f.evidence && f.evidence.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesSev && matchesSearch;
  });

  const criticalCount = findings.filter(f => f.severity === 'CRITICAL').length;
  const sshCount = findings.filter(f => f.rule_name === 'BRUTE_FORCE_SSH').length;
  const privCount = findings.filter(f => f.rule_name === 'PRIVILEGE_ESCALATION_ATTEMPT').length;
  const unreviewedCount = findings.filter(f => f.is_reviewed === 0).length;

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            Cybersecurity Incident Center
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Rule-based detection of brute-force SSH attacks, privilege escalations, and fatal OS panics
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={loadFindings}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs transition-colors"
            title="Refresh findings"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>

          <button
            onClick={handleExportJson}
            disabled={filteredFindings.length === 0}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Export Findings JSON</span>
          </button>
        </div>
      </div>

      {/* Honest Disclosure Banner */}
      <div className="p-3.5 rounded-lg bg-slate-900/90 border border-slate-800 text-xs text-slate-400 flex items-start gap-2.5">
        <ShieldAlert className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
        <div>
          <strong className="text-slate-300 font-medium">SOC Detection Integrity:</strong> All findings displayed here are deterministic, rule-based security events extracted from analyzed log datasets. Detections identify brute-force login clusters, abnormal IP frequencies, and unauthorized system access patterns.
        </div>
      </div>

      {/* STAT METRICS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Critical Anomalies"
          value={criticalCount}
          subtitle="Kernel crashes & extreme bursts"
          icon={Flame}
          color="rose"
        />
        <StatCard
          title="Brute Force Attacks"
          value={sshCount}
          subtitle="Targeting SSH / PAM authentication"
          icon={ShieldAlert}
          color="amber"
        />
        <StatCard
          title="Privilege Violations"
          value={privCount}
          subtitle="Unauthorized sudo & CAP_SYS_ADMIN"
          icon={AlertTriangle}
          color="violet"
        />
        <StatCard
          title="Unreviewed Incidents"
          value={unreviewedCount}
          subtitle="Pending analyst investigation"
          icon={CheckCircle}
          color="cyan"
        />
      </div>

      {/* FILTER & SEARCH BAR */}
      <div className="soc-card p-4 flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="flex-1 w-full sm:w-auto flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-500" />
            <input
              type="text"
              placeholder="Search by title, description, IP, or evidence..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-slate-900 border border-slate-800 rounded-lg text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-500"
            />
          </div>

          <select
            value={sevFilter}
            onChange={e => setSevFilter(e.target.value)}
            className="bg-slate-900 border border-slate-800 rounded-lg py-1.5 px-3 text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-500"
          >
            <option value="ALL">ALL SEVERITIES</option>
            <option value="CRITICAL">CRITICAL ONLY</option>
            <option value="ERROR">ERROR ONLY</option>
            <option value="WARNING">WARNING ONLY</option>
            <option value="SECURITY">SECURITY ONLY</option>
          </select>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono text-slate-300">
          <label className="flex items-center gap-1.5 cursor-pointer">
            <input
              type="checkbox"
              checked={unreviewedOnly}
              onChange={e => setUnreviewedOnly(e.target.checked)}
              className="rounded bg-slate-800 border-slate-700 text-cyan-500 focus:ring-0"
            />
            <span>Unreviewed Only</span>
          </label>
        </div>
      </div>

      {/* FINDINGS LIST */}
      <div className="space-y-3">
        {filteredFindings.length > 0 ? (
          filteredFindings.map((f) => {
            const isReviewed = f.is_reviewed === 1;
            return (
              <div
                key={f.id}
                className={`soc-card p-5 transition-all ${
                  isReviewed ? 'opacity-70 bg-slate-950/40' : 'bg-slate-900/60'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="space-y-1.5 flex-1">
                    <div className="flex items-center gap-2.5">
                      <Badge label={f.severity} variant={f.severity} />
                      <span className="font-mono text-xs font-bold text-cyan-300">{f.rule_name}</span>
                      {f.ip_address && (
                        <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                          IP: {f.ip_address}
                        </span>
                      )}
                      {f.process_id && (
                        <span className="text-[11px] font-mono text-slate-400">PID: {f.process_id}</span>
                      )}
                    </div>

                    <h3 className="text-sm font-bold text-white pt-0.5">{f.title}</h3>
                    <p className="text-xs text-slate-300 leading-relaxed">{f.description}</p>

                    {f.evidence && (
                      <div className="mt-2 p-2.5 rounded bg-slate-950 border border-slate-800 font-mono text-[11px] text-slate-400 overflow-x-auto">
                        <span className="text-slate-500 font-semibold block mb-0.5">EVIDENCE TRACE:</span>
                        <code>{f.evidence}</code>
                      </div>
                    )}
                  </div>

                  {/* Review Button */}
                  <div className="flex sm:flex-col items-center gap-2 shrink-0">
                    <button
                      onClick={() => handleToggleReview(f.id)}
                      className={`px-3 py-1.5 rounded-lg border text-xs font-mono flex items-center gap-1.5 transition-colors ${
                        isReviewed
                          ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-400'
                          : 'bg-slate-800 hover:bg-slate-700 border-slate-700 text-slate-300'
                      }`}
                    >
                      {isReviewed ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span>Reviewed</span>
                        </>
                      ) : (
                        <>
                          <Eye className="w-3.5 h-3.5 text-slate-400" />
                          <span>Mark Reviewed</span>
                        </>
                      )}
                    </button>
                    <span className="text-[10px] font-mono text-slate-500">{f.created_at.split('T')[0]}</span>
                  </div>
                </div>
              </div>
            );
          })
        ) : (
          <div className="soc-card p-12 text-center text-slate-500 text-xs">
            <ShieldAlert className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p className="text-sm font-semibold text-white mb-1">No Matching Security Incidents</p>
            <p className="text-slate-400">Run an analysis on `sample_auth.log` or `sample_system.log` to generate security findings.</p>
          </div>
        )}
      </div>
    </div>
  );
};
