import os
import time
import mmap
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime

from ..core.config import DATASETS_DIR, UPLOADS_DIR, REPORTS_DIR, IS_WINDOWS

ALLOWED_ROOTS = [DATASETS_DIR.resolve(), UPLOADS_DIR.resolve(), REPORTS_DIR.resolve()]

def is_safe_path(target_path: Path) -> bool:
    resolved = target_path.resolve()
    for root in ALLOWED_ROOTS:
        try:
            resolved.relative_to(root)
            return True
        except ValueError:
            continue
    return False

def list_allowed_files() -> List[Dict[str, Any]]:
    files = []
    for root in ALLOWED_ROOTS:
        if not root.exists():
            continue
        for entry in root.glob("*"):
            if entry.is_file():
                stat = entry.stat()
                category = "dataset" if root == DATASETS_DIR.resolve() else ("upload" if root == UPLOADS_DIR.resolve() else "report")
                
                # Inode where supported
                inode = getattr(stat, 'st_ino', None)
                
                files.append({
                    "name": entry.name,
                    "category": category,
                    "size_bytes": stat.st_size,
                    "size_formatted": f"{stat.st_size / 1024:.1f} KB" if stat.st_size < 1024 * 1024 else f"{stat.st_size / (1024 * 1024):.2f} MB",
                    "extension": entry.suffix.lower(),
                    "modified_at": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S"),
                    "inode": inode if inode and not IS_WINDOWS else (stat.st_ino if hasattr(stat, 'st_ino') else "N/A"),
                    "relative_path": str(entry.relative_to(root.parent))
                })
    return sorted(files, key=lambda x: x["name"])

def benchmark_file_io(filename: str) -> Dict[str, Any]:
    """
    Real file I/O benchmark comparing 4 reading strategies:
    1. Small buffer unbuffered (64 bytes)
    2. Buffered block read (64 KB)
    3. Line-by-line buffered
    4. Memory-mapped file I/O (mmap)
    """
    target = None
    for root in ALLOWED_ROOTS:
        candidate = root / filename
        if candidate.exists() and is_safe_path(candidate):
            target = candidate
            break

    if not target or not target.is_file():
        raise FileNotFoundError(f"File '{filename}' not found in allowed directories")

    file_size = target.stat().st_size
    if file_size == 0:
        raise ValueError("Cannot benchmark an empty file")

    results = {}

    # Strategy 1: Unbuffered / Small buffer (64 bytes)
    t0 = time.perf_counter()
    bytes_read_1 = 0
    with open(target, "rb", buffering=0) as f:
        while True:
            chunk = f.read(64)
            if not chunk:
                break
            bytes_read_1 += len(chunk)
    results["unbuffered_64b_ms"] = round((time.perf_counter() - t0) * 1000.0, 3)

    # Strategy 2: Large Block Buffered (64 KB)
    t0 = time.perf_counter()
    bytes_read_2 = 0
    with open(target, "rb", buffering=65536) as f:
        while True:
            chunk = f.read(65536)
            if not chunk:
                break
            bytes_read_2 += len(chunk)
    results["buffered_64kb_ms"] = round((time.perf_counter() - t0) * 1000.0, 3)

    # Strategy 3: Standard Line-by-Line readline()
    t0 = time.perf_counter()
    line_count = 0
    with open(target, "r", encoding="utf-8", errors="replace") as f:
        for _ in f:
            line_count += 1
    results["readline_ms"] = round((time.perf_counter() - t0) * 1000.0, 3)

    # Strategy 4: Memory-Mapped File I/O (mmap)
    t0 = time.perf_counter()
    bytes_read_4 = 0
    with open(target, "r+b") as f:
        with mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ) as mm:
            # Touch contents in 4KB page increments
            for i in range(0, len(mm), 4096):
                _ = mm[i]
            bytes_read_4 = len(mm)
    results["mmap_ms"] = round((time.perf_counter() - t0) * 1000.0, 3)

    # Throughput calculation for block buffered
    dur_sec = results["buffered_64kb_ms"] / 1000.0
    mb_total = file_size / (1024 * 1024)
    throughput_mbps = round(mb_total / dur_sec, 2) if dur_sec > 0 else 0.0

    # Determine fastest
    timings = {
        "Unbuffered (64B)": results["unbuffered_64b_ms"],
        "Buffered (64KB)": results["buffered_64kb_ms"],
        "Line-by-Line (readline)": results["readline_ms"],
        "Memory-Mapped (mmap)": results["mmap_ms"]
    }
    fastest_strategy = min(timings, key=timings.get)

    return {
        "filename": filename,
        "file_size_bytes": file_size,
        "file_size_formatted": f"{file_size / 1024:.1f} KB",
        "timings_ms": results,
        "fastest_strategy": fastest_strategy,
        "throughput_mbps": throughput_mbps,
        "explanation": (
            f"Buffered block reads and mmap minimize user-to-kernel context switches. "
            f"Unbuffered small reads issue excessive read() system calls, resulting in high overhead."
        )
    }
