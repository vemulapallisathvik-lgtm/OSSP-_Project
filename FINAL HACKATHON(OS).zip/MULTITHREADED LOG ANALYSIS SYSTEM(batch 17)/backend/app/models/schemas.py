from pydantic import BaseModel, Field
from typing import List, Dict, Optional, Any

class LogEntry(BaseModel):
    timestamp: Optional[str] = None
    severity: str = "INFO"
    host: Optional[str] = None
    process_name: Optional[str] = None
    process_id: Optional[int] = None
    message: str
    ip_address: Optional[str] = None
    raw_line: str
    thread_id: Optional[str] = None
    is_fallback: bool = False

class WorkerTelemetry(BaseModel):
    worker_id: str
    state: str  # IDLE, RUNNING, WAITING, COMPLETED, ERROR
    assigned_chunk_idx: int = -1
    entries_processed: int = 0
    errors_found: int = 0
    start_time: Optional[float] = None
    elapsed_seconds: float = 0.0
    last_activity: str = "Ready"

class QueueTelemetry(BaseModel):
    queue_size: int = 0
    total_chunks: int = 0
    completed_chunks: int = 0
    pending_chunks: int = 0
    failed_chunks: int = 0
    total_processed: int = 0
    throughput_lps: float = 0.0

class AnalysisProgressUpdate(BaseModel):
    analysis_id: str
    status: str  # queued, running, completed, cancelled, failed
    percent: float = 0.0
    workers: List[WorkerTelemetry] = []
    queue_stats: QueueTelemetry
    severity_counts: Dict[str, int] = {}
    recent_events: List[Dict[str, Any]] = []
    elapsed_seconds: float = 0.0
    total_lines: int = 0
    parsed_lines: int = 0
    malformed_lines: int = 0

class StartAnalysisRequest(BaseModel):
    filename: str
    mode: str = "multi"  # "single" or "multi"
    worker_count: int = Field(default=4, ge=1, le=16)
    chunk_size: int = Field(default=500, ge=50, le=5000)

class BenchmarkRequest(BaseModel):
    dataset_name: str = "sample_benchmark.log"
    worker_count: int = Field(default=4, ge=2, le=16)
    chunk_size: int = Field(default=500, ge=50, le=5000)

class RaceDemoRequest(BaseModel):
    thread_count: int = Field(default=4, ge=2, le=16)
    iterations_per_thread: int = Field(default=50000, ge=1000, le=200000)

class RaceDemoResult(BaseModel):
    thread_count: int
    iterations_per_thread: int
    expected_value: int
    unsafe_value: int
    safe_value: int
    unsafe_lost_updates: int
    unsafe_time_ms: float
    safe_time_ms: float
    explanation: str

class DeadlockSimRequest(BaseModel):
    prevent_deadlock: bool = False

class DeadlockSimResult(BaseModel):
    status: str
    strategy: str
    acquired_locks: List[str]
    message: str
    details: str

class ProcessInfo(BaseModel):
    pid: int
    ppid: int
    name: str
    status: str
    cpu_percent: float
    memory_rss_mb: float
    memory_vms_mb: float
    memory_percent: float
    create_time: str
    num_threads: int
    username: Optional[str] = None
    cmdline: Optional[str] = None

class IpcSendRequest(BaseModel):
    message: str = "SYN_LOG_AUDIT_PROBE"

class IpcSendResponse(BaseModel):
    success: bool
    sender_pid: int
    receiver_pid: int
    message_sent: str
    response_received: str
    latency_ms: float
    timestamp: str
    mechanism: str
    details: str

class MemoryMetricsResponse(BaseModel):
    total_mb: float
    available_mb: float
    used_mb: float
    percent: float
    swap_total_mb: float
    swap_used_mb: float
    swap_percent: float
    process_rss_mb: float
    process_vms_mb: float

class MemoryDemoRequest(BaseModel):
    action: str = "allocate"  # "allocate" or "release"
    size_mb: int = Field(default=25, ge=5, le=100)

class FileBenchmarkRequest(BaseModel):
    filename: str = "sample_system.log"

class SafeCommandRequest(BaseModel):
    command_name: str
