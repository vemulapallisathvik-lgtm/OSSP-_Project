import React, { useState, useEffect } from 'react';
import {
  Activity,
  Play,
  Square,
  Search,
  RefreshCw,
  Cpu,
  Info,
  X,
  GitBranch,
  Terminal,
  ShieldCheck
} from 'lucide-react';

import { api } from '../services/api';
import { CoBanner } from '../components/CoBanner';
import { Badge } from '../components/Badge';
import { ProcessItem, ProcessDetails, DemoProcessStatus } from '../types';

export const ProcessExplorer: React.FC = () => {
  const [processes, setProcesses] = useState<ProcessItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedPid, setSelectedPid] = useState<number | null>(null);
  const [inspectData, setInspectData] = useState<ProcessDetails | null>(null);
  const [inspectLoading, setInspectLoading] = useState<boolean>(false);

  // Controlled Child Process Lifecycle State
  const [demoStatus, setDemoStatus] = useState<DemoProcessStatus>({
    is_running: false,
    pid: null,
    status: 'none',
    message: 'No demo process running'
  });
  const [demoActionLoading, setDemoActionLoading] = useState<boolean>(false);

  const loadProcesses = () => {
    setLoading(true);
    api.listProcesses(searchTerm, 40)
      .then(res => setProcesses(res))
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  const checkDemoStatus = () => {
    api.getDemoProcessStatus()
      .then(res => setDemoStatus(res))
      .catch(console.error);
  };

  useEffect(() => {
    loadProcesses();
    checkDemoStatus();
    const interval = setInterval(() => {
      checkDemoStatus();
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const handleInspect = async (pid: number) => {
    setSelectedPid(pid);
    setInspectLoading(true);
    try {
      const data = await api.inspectProcess(pid);
      setInspectData(data);
    } catch (err: any) {
      alert(`Inspection error: ${err.message}`);
    } finally {
      setInspectLoading(false);
    }
  };

  const handleStartDemo = async () => {
    setDemoActionLoading(true);
    try {
      const res = await api.startDemoProcess();
      setDemoStatus(res);
      loadProcesses();
    } catch (err: any) {
      alert(`Error starting child process: ${err.message}`);
    } finally {
      setDemoActionLoading(false);
    }
  };

  const handleStopDemo = async () => {
    setDemoActionLoading(true);
    try {
      const res = await api.stopDemoProcess();
      alert(res.message);
      checkDemoStatus();
      loadProcesses();
    } catch (err: any) {
      alert(`Error stopping process: ${err.message}`);
    } finally {
      setDemoActionLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <CoBanner
        outcome="CO-2"
        title="Processes and Process Control"
        concept="Process Control Blocks (PCB), Process Lifecycle States, Parent-Child Hierarchies, and Safe Process Termination"
        implementationFile="backend/app/services/process_monitor.py"
        endpoint="GET /api/processes | POST /api/demo/process/start"
        verificationTip="Start the controlled demo child process below to verify PID creation, state transition, and safe app-bounded termination."
      />

      {/* TOP: CONTROLLED PROCESS LIFECYCLE DEMONSTRATION */}
      <div className="soc-card p-5 border-l-4 border-l-cyan-500 bg-slate-900/80 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Terminal className="w-4 h-4 text-cyan-400" />
              <span>Dedicated Child Process Lifecycle Sandbox</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Demonstrates safe creation, monitoring, and SIGTERM termination of an application-owned OS process.
            </p>
          </div>

          <div className="flex items-center gap-2">
            {!demoStatus.is_running ? (
              <button
                onClick={handleStartDemo}
                disabled={demoActionLoading}
                className="px-3.5 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs flex items-center gap-1.5 shadow-sm transition-colors"
              >
                <Play className="w-3.5 h-3.5 fill-current" />
                <span>Start Child Process</span>
              </button>
            ) : (
              <button
                onClick={handleStopDemo}
                disabled={demoActionLoading}
                className="px-3.5 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 text-white font-medium text-xs flex items-center gap-1.5 shadow-sm transition-colors"
              >
                <Square className="w-3.5 h-3.5 fill-current" />
                <span>Terminate Child (PID: {demoStatus.pid})</span>
              </button>
            )}
          </div>
        </div>

        {/* Live Demo Status Card */}
        <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span
              className={`w-3 h-3 rounded-full ${
                demoStatus.is_running ? 'bg-emerald-400 animate-ping' : 'bg-slate-600'
              }`}
            />
            <div>
              <span className="text-slate-400 block text-[10px]">LIFECYCLE STATUS:</span>
              <span className="font-bold text-white">
                {demoStatus.is_running ? `RUNNING (PID: ${demoStatus.pid})` : demoStatus.status.toUpperCase()}
              </span>
            </div>
          </div>

          {demoStatus.is_running && (
            <>
              <div>
                <span className="text-slate-400 block text-[10px]">UPTIME:</span>
                <span className="text-cyan-300 font-bold">{demoStatus.uptime_seconds || 0}s</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">RESIDENT MEMORY:</span>
                <span className="text-slate-200 font-bold">{demoStatus.memory_mb || 0} MB</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">CPU USAGE:</span>
                <span className="text-slate-200 font-bold">{demoStatus.cpu_percent || 0}%</span>
              </div>
            </>
          )}

          <div className="text-slate-400 text-[11px] max-w-sm italic">
            {demoStatus.message}
          </div>
        </div>
      </div>

      {/* PROCESS TABLE */}
      <div className="soc-card p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-semibold text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-cyan-400" />
              <span>Live Operating System Processes (psutil)</span>
            </h2>
            <span className="text-xs font-mono text-slate-500">({processes.length} shown)</span>
          </div>

          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-500" />
              <input
                type="text"
                placeholder="Search PID or name..."
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && loadProcesses()}
                className="pl-8 pr-3 py-1 bg-slate-900 border border-slate-800 rounded-md text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-500"
              />
            </div>

            <button
              onClick={loadProcesses}
              className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs"
              title="Refresh process list"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="text-slate-400 border-b border-slate-800">
              <tr>
                <th className="pb-2">PID</th>
                <th className="pb-2">PPID</th>
                <th className="pb-2">Process Name</th>
                <th className="pb-2">State</th>
                <th className="pb-2">CPU %</th>
                <th className="pb-2">Memory (RSS)</th>
                <th className="pb-2">Threads</th>
                <th className="pb-2">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {processes.map(p => {
                const isDemoProc = demoStatus.pid === p.pid;
                return (
                  <tr
                    key={p.pid}
                    className={`hover:bg-slate-800/40 transition-colors ${
                      isDemoProc ? 'bg-cyan-950/20 font-bold border-l-2 border-l-cyan-400' : ''
                    }`}
                  >
                    <td className="py-2.5 text-cyan-300">
                      {p.pid} {isDemoProc && <span className="text-[10px] text-emerald-400 ml-1">(DEMO)</span>}
                    </td>
                    <td className="py-2.5 text-slate-400">{p.ppid}</td>
                    <td className="py-2.5 text-white font-sans font-medium">{p.name}</td>
                    <td className="py-2.5">
                      <span className="uppercase text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                        {p.status}
                      </span>
                    </td>
                    <td className="py-2.5 text-slate-300">{p.cpu_percent}%</td>
                    <td className="py-2.5 text-slate-300">{p.memory_rss_mb} MB</td>
                    <td className="py-2.5 text-cyan-400">{p.num_threads}</td>
                    <td className="py-2.5">
                      <button
                        onClick={() => handleInspect(p.pid)}
                        className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-[10px] flex items-center gap-1"
                      >
                        <Info className="w-3 h-3" />
                        <span>Inspect</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* INSPECT MODAL */}
      {selectedPid && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
          <div className="soc-card p-6 max-w-xl w-full bg-[#0b1120] border-slate-700 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <GitBranch className="w-5 h-5 text-cyan-400" />
                <span>Process Inspection: PID {selectedPid}</span>
              </h3>
              <button
                onClick={() => setSelectedPid(null)}
                className="text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {inspectLoading ? (
              <div className="py-8 text-center text-xs text-slate-400">Querying OS Kernel PCB...</div>
            ) : inspectData ? (
              <div className="space-y-3 text-xs font-mono">
                <div className="grid grid-cols-2 gap-3 p-3 rounded-lg bg-slate-900 border border-slate-800">
                  <div>
                    <span className="text-slate-400 block text-[10px]">NAME:</span>
                    <span className="text-white font-bold">{inspectData.name}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">STATUS:</span>
                    <span className="text-cyan-300 uppercase font-bold">{inspectData.status}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">PARENT PROCESS:</span>
                    <span className="text-slate-200">
                      {inspectData.parent ? `${inspectData.parent.name} (PID ${inspectData.parent.pid})` : 'Root / Init'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">THREADS ACTIVE:</span>
                    <span className="text-emerald-400 font-bold">{inspectData.num_threads}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">RESIDENT SET (RSS):</span>
                    <span className="text-slate-200">{inspectData.memory_rss_mb} MB</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px]">VIRTUAL SIZE (VMS):</span>
                    <span className="text-slate-200">{inspectData.memory_vms_mb} MB</span>
                  </div>
                </div>

                <div>
                  <span className="text-slate-400 block text-[10px] mb-1">COMMAND LINE INVOCATION:</span>
                  <div className="p-2.5 rounded bg-slate-950 border border-slate-800 text-slate-300 text-[11px] break-all">
                    {inspectData.cmdline}
                  </div>
                </div>

                {inspectData.children && inspectData.children.length > 0 && (
                  <div>
                    <span className="text-slate-400 block text-[10px] mb-1">CHILD PROCESSES SPAWNED:</span>
                    <div className="space-y-1">
                      {inspectData.children.map(child => (
                        <div key={child.pid} className="p-1.5 rounded bg-slate-900 text-slate-300 flex justify-between">
                          <span>{child.name}</span>
                          <span className="text-cyan-400">PID: {child.pid}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-slate-400 text-xs">Process terminated or access denied.</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
