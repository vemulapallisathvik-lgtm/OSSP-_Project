import os
import sys
import time
import subprocess
import psutil
from typing import List, Dict, Any, Optional
from datetime import datetime

class ProcessMonitor:
    def __init__(self):
        self.demo_process: Optional[subprocess.Popen] = None
        self.demo_start_time: Optional[float] = None

    def list_processes(self, search: str = "", limit: int = 50) -> List[Dict[str, Any]]:
        results = []
        search_lower = search.lower().strip()

        for proc in psutil.process_iter(['pid', 'ppid', 'name', 'status', 'cpu_percent', 'memory_info', 'memory_percent', 'create_time', 'num_threads']):
            try:
                info = proc.info
                name = info['name'] or ""
                if search_lower and (search_lower not in name.lower() and search_lower not in str(info['pid'])):
                    continue

                mem = info['memory_info']
                created = datetime.fromtimestamp(info['create_time']).strftime('%Y-%m-%d %H:%M:%S') if info['create_time'] else "N/A"

                results.append({
                    "pid": info['pid'],
                    "ppid": info['ppid'] or 0,
                    "name": name,
                    "status": info['status'] or "unknown",
                    "cpu_percent": round(info['cpu_percent'] or 0.0, 1),
                    "memory_rss_mb": round((mem.rss / (1024 * 1024)), 2) if mem else 0.0,
                    "memory_vms_mb": round((mem.vms / (1024 * 1024)), 2) if mem else 0.0,
                    "memory_percent": round(info['memory_percent'] or 0.0, 2),
                    "create_time": created,
                    "num_threads": info['num_threads'] or 1
                })

                if len(results) >= limit:
                    break
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue

        return results

    def inspect_process(self, pid: int) -> Optional[Dict[str, Any]]:
        try:
            p = psutil.Process(pid)
            mem = p.memory_info()
            children = []
            for child in p.children(recursive=False):
                try:
                    children.append({"pid": child.pid, "name": child.name(), "status": child.status()})
                except Exception:
                    pass

            parent = None
            try:
                parent_proc = p.parent()
                if parent_proc:
                    parent = {"pid": parent_proc.pid, "name": parent_proc.name()}
            except Exception:
                pass

            return {
                "pid": p.pid,
                "ppid": p.ppid(),
                "name": p.name(),
                "status": p.status(),
                "parent": parent,
                "children": children,
                "cpu_percent": round(p.cpu_percent(), 1),
                "memory_rss_mb": round(mem.rss / (1024 * 1024), 2),
                "memory_vms_mb": round(mem.vms / (1024 * 1024), 2),
                "num_threads": p.num_threads(),
                "create_time": datetime.fromtimestamp(p.create_time()).strftime('%Y-%m-%d %H:%M:%S'),
                "cmdline": " ".join(p.cmdline()[:6]) if p.cmdline() else "N/A"
            }
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            return None

    def start_demo_process(self) -> Dict[str, Any]:
        """Start a dedicated, safe, application-controlled child process for lifecycle demo"""
        if self.demo_process and self.demo_process.poll() is None:
            return {
                "status": "already_running",
                "pid": self.demo_process.pid,
                "message": f"Demo child process PID {self.demo_process.pid} is already running",
                "is_running": True
            }

        # Safe python loop that outputs heartbeats and sleeps
        code = (
            "import sys, time; "
            "print('DEMO_WORKER_INITIALIZED', flush=True); "
            "count = 0\n"
            "while True:\n"
            "    time.sleep(1)\n"
            "    count += 1\n"
            "    if count > 600: break\n"
        )

        try:
            self.demo_process = subprocess.Popen(
                [sys.executable, "-c", code],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            self.demo_start_time = time.time()
            return {
                "status": "started",
                "pid": self.demo_process.pid,
                "message": f"Successfully spawned application child process (PID: {self.demo_process.pid})",
                "is_running": True
            }
        except Exception as e:
            return {
                "status": "error",
                "pid": None,
                "message": f"Failed to start child process: {str(e)}",
                "is_running": False
            }

    def get_demo_process_status(self) -> Dict[str, Any]:
        if not self.demo_process:
            return {"is_running": False, "pid": None, "status": "none", "message": "No demo child process created yet"}

        exit_code = self.demo_process.poll()
        if exit_code is None:
            uptime = round(time.time() - (self.demo_start_time or time.time()), 1)
            try:
                p = psutil.Process(self.demo_process.pid)
                return {
                    "is_running": True,
                    "pid": self.demo_process.pid,
                    "status": "running",
                    "uptime_seconds": uptime,
                    "cpu_percent": p.cpu_percent(),
                    "memory_mb": round(p.memory_info().rss / (1024 * 1024), 2),
                    "message": f"Child process active (PID: {self.demo_process.pid}, uptime: {uptime}s)"
                }
            except Exception:
                return {"is_running": True, "pid": self.demo_process.pid, "status": "running", "message": "Active"}
        else:
            return {
                "is_running": False,
                "pid": self.demo_process.pid,
                "status": "terminated",
                "exit_code": exit_code,
                "message": f"Child process terminated with exit code {exit_code}"
            }

    def stop_demo_process(self) -> Dict[str, Any]:
        """Safely terminate ONLY the application-controlled child process"""
        if not self.demo_process:
            return {"status": "not_running", "message": "No demo process is currently running"}

        if self.demo_process.poll() is not None:
            return {"status": "already_stopped", "message": f"Process {self.demo_process.pid} has already stopped"}

        target_pid = self.demo_process.pid
        try:
            self.demo_process.terminate()
            try:
                self.demo_process.wait(timeout=2.0)
            except subprocess.TimeoutExpired:
                self.demo_process.kill()
                self.demo_process.wait(timeout=1.0)

            return {
                "status": "stopped",
                "pid": target_pid,
                "message": f"Successfully terminated application child process PID {target_pid}"
            }
        except Exception as e:
            return {
                "status": "error",
                "pid": target_pid,
                "message": f"Error terminating process {target_pid}: {str(e)}"
            }

process_service = ProcessMonitor()
