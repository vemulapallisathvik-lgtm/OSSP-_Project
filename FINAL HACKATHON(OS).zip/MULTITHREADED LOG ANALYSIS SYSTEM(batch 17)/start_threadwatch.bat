@echo off
title ThreadWatch Launcher
echo ========================================================
echo    THREADWATCH - Multithreaded Log Analysis Platform
echo ========================================================
echo.
echo Starting Backend (FastAPI on Port 8000)...
start "ThreadWatch Backend" cmd /k "cd /d "%~dp0backend" && call .\venv\Scripts\activate.bat && python -m uvicorn app.main:app --reload --port 8000"

timeout /t 3 /nobreak > nul

echo Starting Frontend (Vite on Port 5173)...
start "ThreadWatch Frontend" cmd /k "cd /d "%~dp0frontend" && npm run dev -- --host 127.0.0.1 --port 5173"

timeout /t 2 /nobreak > nul

echo Opening browser at http://127.0.0.1:5173/ ...
start http://127.0.0.1:5173/

echo.
echo Both servers are launching in separate windows!
echo Backend:  http://127.0.0.1:8000/docs
echo Frontend: http://127.0.0.1:5173/
echo.
pause
