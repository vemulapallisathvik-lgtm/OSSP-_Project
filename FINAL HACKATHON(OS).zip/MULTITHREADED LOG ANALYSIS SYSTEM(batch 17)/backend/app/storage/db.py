import sqlite3
import json
from datetime import datetime
from typing import Dict, List, Any, Optional
from pathlib import Path
from ..core.config import DB_PATH

def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    with conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS analyses (
                id TEXT PRIMARY KEY,
                filename TEXT NOT NULL,
                file_size_bytes INTEGER DEFAULT 0,
                total_lines INTEGER DEFAULT 0,
                parsed_lines INTEGER DEFAULT 0,
                malformed_lines INTEGER DEFAULT 0,
                mode TEXT NOT NULL,
                worker_count INTEGER NOT NULL,
                chunk_size INTEGER NOT NULL,
                duration_seconds REAL DEFAULT 0.0,
                throughput_lps REAL DEFAULT 0.0,
                status TEXT NOT NULL,
                error_message TEXT,
                summary_json TEXT,
                created_at TEXT NOT NULL,
                completed_at TEXT
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS severity_counts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                analysis_id TEXT NOT NULL,
                severity TEXT NOT NULL,
                count INTEGER NOT NULL,
                FOREIGN KEY (analysis_id) REFERENCES analyses (id) ON DELETE CASCADE
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS security_findings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                analysis_id TEXT NOT NULL,
                rule_name TEXT NOT NULL,
                severity TEXT NOT NULL,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                evidence TEXT,
                ip_address TEXT,
                process_id INTEGER,
                is_reviewed INTEGER DEFAULT 0,
                created_at TEXT NOT NULL,
                FOREIGN KEY (analysis_id) REFERENCES analyses (id) ON DELETE CASCADE
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS benchmarks (
                id TEXT PRIMARY KEY,
                dataset_name TEXT NOT NULL,
                total_lines INTEGER NOT NULL,
                single_thread_time REAL NOT NULL,
                multi_thread_time REAL NOT NULL,
                speedup REAL NOT NULL,
                efficiency REAL NOT NULL,
                worker_count INTEGER NOT NULL,
                chunk_size INTEGER NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
    conn.close()

def save_analysis_start(analysis_id: str, filename: str, file_size: int, mode: str, workers: int, chunk_size: int):
    conn = get_connection()
    now = datetime.now().isoformat()
    with conn:
        conn.execute("""
            INSERT OR REPLACE INTO analyses (
                id, filename, file_size_bytes, mode, worker_count, chunk_size, status, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, 'running', ?)
        """, (analysis_id, filename, file_size, mode, workers, chunk_size, now))
    conn.close()

def save_analysis_complete(
    analysis_id: str,
    total_lines: int,
    parsed_lines: int,
    malformed_lines: int,
    duration: float,
    throughput: float,
    severity_counts: Dict[str, int],
    security_findings: List[Dict[str, Any]],
    summary_json: Optional[str] = None
):
    conn = get_connection()
    now = datetime.now().isoformat()
    with conn:
        conn.execute("""
            UPDATE analyses SET
                total_lines = ?,
                parsed_lines = ?,
                malformed_lines = ?,
                duration_seconds = ?,
                throughput_lps = ?,
                status = 'completed',
                summary_json = ?,
                completed_at = ?
            WHERE id = ?
        """, (total_lines, parsed_lines, malformed_lines, duration, throughput, summary_json, now, analysis_id))

        # Insert severity counts
        conn.execute("DELETE FROM severity_counts WHERE analysis_id = ?", (analysis_id,))
        for sev, count in severity_counts.items():
            conn.execute("""
                INSERT INTO severity_counts (analysis_id, severity, count)
                VALUES (?, ?, ?)
            """, (analysis_id, sev, count))

        # Insert security findings
        for finding in security_findings:
            conn.execute("""
                INSERT INTO security_findings (
                    analysis_id, rule_name, severity, title, description, evidence, ip_address, process_id, is_reviewed, created_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 0, ?)
            """, (
                analysis_id,
                finding.get("rule_name", "UNKNOWN"),
                finding.get("severity", "WARNING"),
                finding.get("title", ""),
                finding.get("description", ""),
                finding.get("evidence", ""),
                finding.get("ip_address"),
                finding.get("process_id"),
                now
            ))
    conn.close()

def save_analysis_failure(analysis_id: str, error_message: str):
    conn = get_connection()
    now = datetime.now().isoformat()
    with conn:
        conn.execute("""
            UPDATE analyses SET
                status = 'failed',
                error_message = ?,
                completed_at = ?
            WHERE id = ?
        """, (error_message, now, analysis_id))
    conn.close()

def get_recent_analyses(limit: int = 10) -> List[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT * FROM analyses ORDER BY created_at DESC LIMIT ?
    """, (limit,))
    rows = [dict(r) for r in cursor.fetchall()]
    
    # Enrich with severities
    for row in rows:
        cursor.execute("SELECT severity, count FROM severity_counts WHERE analysis_id = ?", (row["id"],))
        row["severities"] = {r["severity"]: r["count"] for r in cursor.fetchall()}
    conn.close()
    return rows

def get_analysis_by_id(analysis_id: str) -> Optional[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM analyses WHERE id = ?", (analysis_id,))
    row = cursor.fetchone()
    if not row:
        conn.close()
        return None
    res = dict(row)
    cursor.execute("SELECT severity, count FROM severity_counts WHERE analysis_id = ?", (analysis_id,))
    res["severities"] = {r["severity"]: r["count"] for r in cursor.fetchall()}
    cursor.execute("SELECT * FROM security_findings WHERE analysis_id = ? ORDER BY id DESC", (analysis_id,))
    res["findings"] = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return res

def get_all_security_findings(limit: int = 100, unreviewed_only: bool = False) -> List[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    query = "SELECT * FROM security_findings"
    params = []
    if unreviewed_only:
        query += " WHERE is_reviewed = 0"
    query += " ORDER BY id DESC LIMIT ?"
    params.append(limit)
    cursor.execute(query, tuple(params))
    rows = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return rows

def toggle_finding_reviewed(finding_id: int) -> bool:
    conn = get_connection()
    with conn:
        cursor = conn.cursor()
        cursor.execute("SELECT is_reviewed FROM security_findings WHERE id = ?", (finding_id,))
        row = cursor.fetchone()
        if not row:
            conn.close()
            return False
        new_state = 0 if row["is_reviewed"] == 1 else 1
        cursor.execute("UPDATE security_findings SET is_reviewed = ? WHERE id = ?", (new_state, finding_id))
    conn.close()
    return True

def save_benchmark(benchmark_data: Dict[str, Any]):
    conn = get_connection()
    with conn:
        conn.execute("""
            INSERT OR REPLACE INTO benchmarks (
                id, dataset_name, total_lines, single_thread_time, multi_thread_time,
                speedup, efficiency, worker_count, chunk_size, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            benchmark_data["id"],
            benchmark_data["dataset_name"],
            benchmark_data["total_lines"],
            benchmark_data["single_thread_time"],
            benchmark_data["multi_thread_time"],
            benchmark_data["speedup"],
            benchmark_data["efficiency"],
            benchmark_data["worker_count"],
            benchmark_data["chunk_size"],
            benchmark_data["created_at"]
        ))
    conn.close()

def get_recent_benchmarks(limit: int = 10) -> List[Dict[str, Any]]:
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM benchmarks ORDER BY created_at DESC LIMIT ?", (limit,))
    rows = [dict(r) for r in cursor.fetchall()]
    conn.close()
    return rows

# Initialize DB on module import
init_db()
