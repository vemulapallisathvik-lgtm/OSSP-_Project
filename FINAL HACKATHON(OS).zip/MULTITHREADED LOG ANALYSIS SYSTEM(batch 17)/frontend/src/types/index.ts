export interface WorkerTelemetry {
  worker_id: string;
  state: 'IDLE' | 'RUNNING' | 'WAITING' | 'COMPLETED' | 'ERROR';
  assigned_chunk_idx: number;
  entries_processed: number;
  errors_found: number;
  start_time: number | null;
  elapsed_seconds: number;
  last_activity: string;
}

export interface QueueTelemetry {
  queue_size: number;
  total_chunks: number;
  completed_chunks: number;
  pending_chunks: number;
  failed_chunks: number;
  total_processed: number;
  throughput_lps: number;
}

export interface RecentEvent {
  timestamp: string;
  severity: string;
  source: string;
  process_id?: number | null;
  message: string;
  thread_id?: string;
  status?: string;
}

export interface AnalysisProgressUpdate {
  analysis_id: string;
  status: 'queued' | 'running' | 'completed' | 'cancelled' | 'failed';
  percent: number;
  workers: WorkerTelemetry[];
  queue_stats: QueueTelemetry;
  severity_counts: Record<string, number>;
  recent_events: RecentEvent[];
  elapsed_seconds: number;
  total_lines: number;
  parsed_lines: number;
  malformed_lines: number;
}

export interface SecurityFinding {
  id: number;
  analysis_id: string;
  rule_name: string;
  severity: 'CRITICAL' | 'ERROR' | 'WARNING' | 'NOTICE' | 'SECURITY';
  title: string;
  description: string;
  evidence?: string;
  ip_address?: string | null;
  process_id?: number | null;
  is_reviewed: number;
  created_at: string;
}

export interface AnalysisRecord {
  id: string;
  filename: string;
  file_size_bytes: number;
  total_lines: number;
  parsed_lines: number;
  malformed_lines: number;
  mode: 'single' | 'multi';
  worker_count: number;
  chunk_size: number;
  duration_seconds: number;
  throughput_lps: number;
  status: string;
  error_message?: string;
  created_at: string;
  completed_at?: string;
  severities?: Record<string, number>;
  findings?: SecurityFinding[];
}

export interface BenchmarkRecord {
  id: string;
  dataset_name: string;
  total_lines: number;
  single_thread_time: number;
  multi_thread_time: number;
  single_throughput_lps?: number;
  multi_throughput_lps?: number;
  speedup: number;
  efficiency: number;
  worker_count: number;
  chunk_size: number;
  worker_distribution?: { worker_id: string; entries_processed: number; percentage: number }[];
  severities_found?: Record<string, number>;
  created_at: string;
  explanation?: string;
}

export interface ProcessItem {
  pid: number;
  ppid: number;
  name: string;
  status: string;
  cpu_percent: number;
  memory_rss_mb: number;
  memory_vms_mb: number;
  memory_percent: number;
  create_time: string;
  num_threads: number;
}

export interface ProcessDetails extends ProcessItem {
  cmdline?: string;
  parent?: { pid: number; name: string } | null;
  children?: { pid: number; name: string; status: string }[];
}

export interface DemoProcessStatus {
  is_running: boolean;
  pid: number | null;
  status: string;
  uptime_seconds?: number;
  cpu_percent?: number;
  memory_mb?: number;
  message: string;
}

export interface IpcResponse {
  success: boolean;
  sender_pid: number;
  receiver_pid: number;
  message_sent: string;
  response_received: string;
  latency_ms: number;
  timestamp: string;
  mechanism: string;
  details: string;
}

export interface MemoryMetrics {
  total_mb: number;
  available_mb: number;
  used_mb: number;
  percent: number;
  swap_total_mb: number;
  swap_used_mb: number;
  swap_percent: number;
  process_rss_mb: number;
  process_vms_mb: number;
}

export interface MemoryDemoResponse {
  status: string;
  pid?: number;
  requested_mb?: number;
  allocated_bytes?: number;
  process_rss_before_mb?: number;
  process_rss_after_mb?: number;
  delta_mb?: number;
  freed_mb?: number;
  message: string;
}

export interface FileItem {
  name: string;
  category: 'dataset' | 'upload' | 'report';
  size_bytes: number;
  size_formatted: string;
  extension: string;
  modified_at: string;
  inode: number | string;
  relative_path: string;
}

export interface FileBenchmarkResult {
  filename: string;
  file_size_bytes: number;
  file_size_formatted: string;
  timings_ms: {
    unbuffered_64b_ms: number;
    buffered_64kb_ms: number;
    readline_ms: number;
    mmap_ms: number;
  };
  fastest_strategy: string;
  throughput_mbps: number;
  explanation: string;
}

export interface RaceDemoResult {
  thread_count: number;
  iterations_per_thread: number;
  expected_value: number;
  unsafe_value: number;
  safe_value: number;
  unsafe_lost_updates: number;
  unsafe_time_ms: number;
  safe_time_ms: number;
  explanation: string;
}

export interface DeadlockSimResult {
  status: string;
  strategy: string;
  deadlock_occurred: boolean;
  timeline: string[];
  message: string;
  details: string;
}

export interface SystemInfo {
  platform: string;
  release: string;
  version: string;
  architecture: string;
  processor: string;
  hostname: string;
  python_version: string;
  python_compiler: string;
  cpu_physical_cores: number;
  cpu_logical_cores: number;
  cpu_current_freq_mhz: number;
  total_ram_gb: number;
  available_ram_gb: number;
  boot_time: string;
  uptime_seconds: number;
  is_windows: boolean;
  is_linux: boolean;
  is_darwin: boolean;
}

export interface SyscallItem {
  syscall: string;
  number_x86_64: number;
  category: string;
  description: string;
}

export interface SafeCommandResult {
  success: boolean;
  command_name: string;
  executed_command: string;
  stdout: string;
  stderr: string;
  returncode: number;
  execution_time_ms: number;
}
