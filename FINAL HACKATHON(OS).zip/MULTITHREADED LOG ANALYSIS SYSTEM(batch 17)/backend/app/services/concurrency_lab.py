import time
import threading
from typing import Dict, Any

class ConcurrencyLab:
    def run_race_condition_demo(self, thread_count: int = 4, iterations_per_thread: int = 50000) -> Dict[str, Any]:
        """
        Controlled race condition demonstration comparing an unsynchronized shared counter
        against a mutex-synchronized counter using threading.Lock.
        """
        thread_count = max(2, min(thread_count, 16))
        iterations_per_thread = max(1000, min(iterations_per_thread, 200000))
        expected_total = thread_count * iterations_per_thread

        # 1. Unsynchronized Counter Test
        unsafe_counter = [0]

        def _unsafe_worker():
            for _ in range(iterations_per_thread):
                # Read-modify-write without synchronization
                val = unsafe_counter[0]
                # Tiny computation window to reliably trigger thread interleaving
                unsafe_counter[0] = val + 1

        t0 = time.perf_counter()
        threads = [threading.Thread(target=_unsafe_worker) for _ in range(thread_count)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()
        unsafe_duration_ms = round((time.perf_counter() - t0) * 1000.0, 2)
        unsafe_val = unsafe_counter[0]
        lost_updates = expected_total - unsafe_val

        # 2. Synchronized Counter Test using threading.Lock
        safe_counter = [0]
        lock = threading.Lock()

        def _safe_worker():
            for _ in range(iterations_per_thread):
                with lock:
                    safe_counter[0] += 1

        t0 = time.perf_counter()
        threads_safe = [threading.Thread(target=_safe_worker) for _ in range(thread_count)]
        for t in threads_safe:
            t.start()
        for t in threads_safe:
            t.join()
        safe_duration_ms = round((time.perf_counter() - t0) * 1000.0, 2)
        safe_val = safe_counter[0]

        return {
            "thread_count": thread_count,
            "iterations_per_thread": iterations_per_thread,
            "expected_value": expected_total,
            "unsafe_value": unsafe_val,
            "safe_value": safe_val,
            "unsafe_lost_updates": lost_updates,
            "unsafe_time_ms": unsafe_duration_ms,
            "safe_time_ms": safe_duration_ms,
            "explanation": (
                f"In the unsynchronized run, multiple threads read the same stale counter value before writing back, "
                f"resulting in {lost_updates:,} lost updates ({lost_updates/expected_total*100:.1f}% loss). "
                f"With threading.Lock, atomic mutual exclusion ensures 100% data integrity ({safe_val:,} / {expected_total:,})."
            )
        }

    def simulate_deadlock(self, prevent_deadlock: bool = False) -> Dict[str, Any]:
        """
        Controlled deadlock demonstration using timeout-protected resource acquisition.
        Demonstrates the 4 Coffman conditions and prevention via Global Lock Ordering.
        """
        lock_a = threading.Lock()
        lock_b = threading.Lock()

        events = []
        deadlock_detected = False

        if not prevent_deadlock:
            # CIRCULAR WAIT SCENARIO:
            # Thread 1: Acquire A -> try acquire B
            # Thread 2: Acquire B -> try acquire A
            def worker1():
                nonlocal deadlock_detected
                with lock_a:
                    events.append("Thread-1: Acquired Resource A")
                    time.sleep(0.05)  # Window for Thread 2 to grab B
                    events.append("Thread-1: Attempting to acquire Resource B...")
                    # Safe acquire with 0.4s timeout
                    acquired = lock_b.acquire(timeout=0.4)
                    if acquired:
                        try:
                            events.append("Thread-1: Acquired Resource B")
                        finally:
                            lock_b.release()
                    else:
                        deadlock_detected = True
                        events.append("Thread-1: [TIMEOUT] Deadlock detected! Blocked waiting for Resource B held by Thread-2")

            def worker2():
                nonlocal deadlock_detected
                with lock_b:
                    events.append("Thread-2: Acquired Resource B")
                    time.sleep(0.05)
                    events.append("Thread-2: Attempting to acquire Resource A...")
                    acquired = lock_a.acquire(timeout=0.4)
                    if acquired:
                        try:
                            events.append("Thread-2: Acquired Resource A")
                        finally:
                            lock_a.release()
                    else:
                        deadlock_detected = True
                        events.append("Thread-2: [TIMEOUT] Deadlock detected! Blocked waiting for Resource A held by Thread-1")

            t1 = threading.Thread(target=worker1)
            t2 = threading.Thread(target=worker2)
            t1.start()
            t2.start()
            t1.join()
            t2.join()

            return {
                "status": "DEADLOCK_SIMULATED",
                "strategy": "Unordered Circular Wait",
                "deadlock_occurred": True,
                "timeline": events,
                "message": "Deadlock occurred! Circular wait condition was met: Thread-1 held A waiting for B, while Thread-2 held B waiting for A.",
                "details": "Protected with 400ms timeout to demonstrate Coffman conditions safely without freezing application threads."
            }
        else:
            # RESOURCE ORDERING HIERARCHY:
            # Both threads MUST acquire Lock A first, then Lock B
            def ordered_worker(worker_name: str):
                with lock_a:
                    events.append(f"{worker_name}: Acquired Resource A (Hierarchy Rank 1)")
                    time.sleep(0.03)
                    with lock_b:
                        events.append(f"{worker_name}: Acquired Resource B (Hierarchy Rank 2)")
                        events.append(f"{worker_name}: Executed critical section successfully")

            t1 = threading.Thread(target=ordered_worker, args=("Thread-1",))
            t2 = threading.Thread(target=ordered_worker, args=("Thread-2",))
            t1.start()
            t2.start()
            t1.join()
            t2.join()

            return {
                "status": "DEADLOCK_PREVENTED",
                "strategy": "Strict Resource Hierarchy Ordering (A -> B)",
                "deadlock_occurred": False,
                "timeline": events,
                "message": "Deadlock prevented! By enforcing strict hierarchical lock acquisition order (Rank A < Rank B), circular wait is mathematically impossible.",
                "details": "Both threads completed execution cleanly without any timeouts or resource starvation."
            }

concurrency_service = ConcurrencyLab()
