import React, { useState, useEffect } from 'react';
import {
  FileText,
  Download,
  Printer,
  Calendar,
  Clock,
  Cpu,
  Layers,
  CheckCircle,
  Eye,
  RefreshCw,
  X
} from 'lucide-react';

import { api } from '../services/api';
import { Badge } from '../components/Badge';
import { AnalysisRecord } from '../types';

export const Reports: React.FC = () => {
  const [reports, setReports] = useState<AnalysisRecord[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedReport, setSelectedReport] = useState<AnalysisRecord | null>(null);

  const loadReports = () => {
    setLoading(true);
    api.getReports()
      .then(res => setReports(res))
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadReports();
  }, []);

  const handleInspect = async (id: string) => {
    try {
      const full = await api.getAnalysisResults(id);
      setSelectedReport(full);
    } catch (err: any) {
      alert(`Report load error: ${err.message}`);
    }
  };

  return (
    <div className="space-y-6">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            Analysis Audit Reports
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Downloadable CSV/JSON audit trails and printable executive SOC summaries
          </p>
        </div>

        <button
          onClick={loadReports}
          className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs self-start sm:self-auto"
          title="Refresh reports list"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {/* REPORTS TABLE */}
      <div className="soc-card p-5 space-y-4">
        <h2 className="text-sm font-semibold text-white">Stored Analysis Runs ({reports.length})</h2>

        {reports.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="pb-2">Report ID</th>
                  <th className="pb-2">Dataset</th>
                  <th className="pb-2">Mode</th>
                  <th className="pb-2">Workers</th>
                  <th className="pb-2">Total Lines</th>
                  <th className="pb-2">Duration</th>
                  <th className="pb-2">Throughput</th>
                  <th className="pb-2">Created At</th>
                  <th className="pb-2">Exports</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {reports.map(r => (
                  <tr key={r.id} className="hover:bg-slate-800/30">
                    <td className="py-2.5 text-cyan-300 font-bold">{r.id}</td>
                    <td className="py-2.5 font-sans font-medium text-white">{r.filename}</td>
                    <td className="py-2.5">
                      <span className="uppercase text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                        {r.mode}
                      </span>
                    </td>
                    <td className="py-2.5 text-cyan-400">{r.worker_count}T</td>
                    <td className="py-2.5 text-slate-300">{r.total_lines?.toLocaleString() || '-'}</td>
                    <td className="py-2.5 text-slate-300">{r.duration_seconds}s</td>
                    <td className="py-2.5 text-emerald-400">{r.throughput_lps} LPS</td>
                    <td className="py-2.5 text-slate-500">{r.created_at.split('T')[0]}</td>
                    <td className="py-2.5">
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleInspect(r.id)}
                          className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[10px]"
                          title="View Full Report Summary"
                        >
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <a
                          href={api.getReportCsvUrl(r.id)}
                          download
                          className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-cyan-400 text-[10px]"
                          title="Download CSV"
                        >
                          CSV
                        </a>
                        <a
                          href={api.getReportJsonUrl(r.id)}
                          download
                          className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-emerald-400 text-[10px]"
                          title="Download JSON"
                        >
                          JSON
                        </a>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="p-8 text-center text-slate-500 text-xs">
            <FileText className="w-8 h-8 mx-auto mb-2 opacity-50" />
            <p>No reports generated yet. Analyze a log file to generate a persistent report.</p>
          </div>
        )}
      </div>

      {/* REPORT SUMMARY MODAL / PRINT VIEW */}
      {selectedReport && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 overflow-y-auto">
          <div className="soc-card p-6 max-w-2xl w-full bg-[#0b1120] border-slate-700 space-y-4 my-8">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-mono text-cyan-400 uppercase tracking-wider">
                  REPORT AUDIT ID: {selectedReport.id}
                </span>
                <h3 className="text-base font-bold text-white mt-0.5">
                  Executive Analysis Summary: {selectedReport.filename}
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs flex items-center gap-1"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Print</span>
                </button>
                <button
                  onClick={() => setSelectedReport(null)}
                  className="text-slate-400 hover:text-white p-1"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Metrics Breakdown */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
              <div className="p-2.5 rounded bg-slate-900 border border-slate-800">
                <span className="text-slate-400 text-[10px] block">TOTAL ENTRIES</span>
                <span className="text-white font-bold text-sm">{selectedReport.total_lines.toLocaleString()}</span>
              </div>
              <div className="p-2.5 rounded bg-slate-900 border border-slate-800">
                <span className="text-slate-400 text-[10px] block">DURATION</span>
                <span className="text-white font-bold text-sm">{selectedReport.duration_seconds}s</span>
              </div>
              <div className="p-2.5 rounded bg-slate-900 border border-slate-800">
                <span className="text-slate-400 text-[10px] block">THROUGHPUT</span>
                <span className="text-emerald-400 font-bold text-sm">{selectedReport.throughput_lps} LPS</span>
              </div>
              <div className="p-2.5 rounded bg-slate-900 border border-slate-800">
                <span className="text-slate-400 text-[10px] block">WORKER THREADS</span>
                <span className="text-cyan-300 font-bold text-sm">{selectedReport.worker_count} Threads</span>
              </div>
            </div>

            {/* Severities Breakdown */}
            <div>
              <h4 className="text-xs font-bold text-slate-300 font-mono uppercase mb-2">SEVERITY COUNTS:</h4>
              <div className="flex flex-wrap gap-2">
                {Object.entries(selectedReport.severities || {}).map(([sev, count]) => (
                  <div key={sev} className="flex items-center gap-1.5 px-3 py-1 rounded bg-slate-900 border border-slate-800 text-xs font-mono">
                    <Badge label={sev} variant={sev as any} />
                    <span className="text-white font-bold">{count.toLocaleString()}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Security Findings in this run */}
            {selectedReport.findings && selectedReport.findings.length > 0 && (
              <div>
                <h4 className="text-xs font-bold text-rose-400 font-mono uppercase mb-2">
                  SECURITY ANOMALIES IDENTIFIED ({selectedReport.findings.length}):
                </h4>
                <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                  {selectedReport.findings.map(f => (
                    <div key={f.id} className="p-2.5 rounded bg-slate-950 border border-rose-900/40 text-xs">
                      <div className="flex items-center justify-between font-mono text-[11px] mb-1">
                        <Badge label={f.severity} variant={f.severity} />
                        {f.ip_address && <span className="text-slate-400">{f.ip_address}</span>}
                      </div>
                      <div className="font-bold text-slate-200">{f.title}</div>
                      <div className="text-[11px] text-slate-400">{f.description}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Direct Download Actions */}
            <div className="flex justify-end gap-2 pt-3 border-t border-slate-800">
              <a
                href={api.getReportCsvUrl(selectedReport.id)}
                download
                className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs flex items-center gap-1.5 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Report CSV</span>
              </a>
              <a
                href={api.getReportJsonUrl(selectedReport.id)}
                download
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs flex items-center gap-1.5 transition-colors"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Download Report JSON</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
