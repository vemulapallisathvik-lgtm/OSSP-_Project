import React from 'react';
import { BookOpen, CheckCircle, Code, Server } from 'lucide-react';

interface CoBannerProps {
  outcome: 'CO-1' | 'CO-2' | 'CO-3' | 'CO-4' | 'CO-5' | 'CO-6';
  title: string;
  concept: string;
  implementationFile: string;
  endpoint: string;
  verificationTip: string;
}

export const CoBanner: React.FC<CoBannerProps> = ({
  outcome,
  title,
  concept,
  implementationFile,
  endpoint,
  verificationTip
}) => {
  return (
    <div className="soc-card p-5 border-l-4 border-l-cyan-500 bg-slate-900/60 mb-6">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1.5">
            <span className="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-mono text-xs font-bold">
              {outcome}
            </span>
            <h2 className="text-base font-semibold text-white flex items-center gap-2">
              {title}
            </h2>
          </div>
          <p className="text-xs text-slate-300">
            <span className="font-semibold text-slate-200">OS Concept:</span> {concept}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 text-[11px] font-mono text-slate-400">
          <div className="flex items-center gap-1.5 bg-slate-800/80 px-2.5 py-1 rounded border border-slate-700/80">
            <Code className="w-3.5 h-3.5 text-cyan-400" />
            <span>{implementationFile}</span>
          </div>
          <div className="flex items-center gap-1.5 bg-slate-800/80 px-2.5 py-1 rounded border border-slate-700/80">
            <Server className="w-3.5 h-3.5 text-emerald-400" />
            <span>{endpoint}</span>
          </div>
        </div>
      </div>

      <div className="mt-3 pt-3 border-t border-slate-800/80 flex items-start gap-2 text-xs text-slate-400">
        <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
        <span>
          <strong className="text-slate-300 font-medium">Judge Verification:</strong> {verificationTip}
        </span>
      </div>
    </div>
  );
};
