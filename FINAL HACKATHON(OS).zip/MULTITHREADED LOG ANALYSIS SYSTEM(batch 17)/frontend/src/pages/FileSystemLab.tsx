import React, { useState, useEffect } from 'react';
import {
  FolderGit2,
  FileText,
  Play,
  Zap,
  HardDrive,
  Layers,
  Database,
  Clock,
  CheckCircle,
  FileCode,
  ShieldCheck,
  RefreshCw
} from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';

import { api } from '../services/api';
import { CoBanner } from '../components/CoBanner';
import { Badge } from '../components/Badge';
import { FileItem, FileBenchmarkResult } from '../types';

export const FileSystemLab: React.FC = () => {
  const [files, setFiles] = useState<FileItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedFile, setSelectedFile] = useState<string>('sample_system.log');
  const [benchmarkResult, setBenchmarkResult] = useState<FileBenchmarkResult | null>(null);
  const [benchmarking, setBenchmarking] = useState<boolean>(false);

  const loadFiles = () => {
    setLoading(true);
    api.listFiles()
      .then(res => {
        setFiles(res);
        if (res.length > 0 && !selectedFile) {
          setSelectedFile(res[0].name);
        }
      })
      .catch(console.error)
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    loadFiles();
  }, []);

  const handleRunBenchmark = async () => {
    if (!selectedFile) return;
    setBenchmarking(true);
    try {
      const res = await api.runFileBenchmark(selectedFile);
      setBenchmarkResult(res);
    } catch (err: any) {
      alert(`I/O benchmark failed: ${err.message}`);
    } finally {
      setBenchmarking(false);
    }
  };

  // Chart data from timings
  const chartData = benchmarkResult ? [
    { name: 'Unbuffered (64B)', time_ms: benchmarkResult.timings_ms.unbuffered_64b_ms, fill: '#ef4444' },
    { name: 'Buffered (64KB)', time_ms: benchmarkResult.timings_ms.buffered_64kb_ms, fill: '#10b981' },
    { name: 'Line-by-Line', time_ms: benchmarkResult.timings_ms.readline_ms, fill: '#f59e0b' },
    { name: 'Memory-Mapped (mmap)', time_ms: benchmarkResult.timings_ms.mmap_ms, fill: '#06b6d4' }
  ] : [];

  return (
    <div className="space-y-6">
      <CoBanner
        outcome="CO-5"
        title="File Systems and File I/O in Linux"
        concept="Virtual File System (VFS), Inodes, File Descriptors, Buffered vs Unbuffered I/O, and Memory-Mapped Files (mmap)"
        implementationFile="backend/app/services/file_io_benchmark.py"
        endpoint="GET /api/files | POST /api/files/benchmark"
        verificationTip="Select a log file and run the multi-strategy I/O benchmark to measure actual read latency differences between unbuffered sys_read, buffered blocks, and kernel mmap."
      />

      {/* RESTRICTED FILE EXPLORER */}
      <div className="soc-card p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <h2 className="text-sm font-semibold text-white flex items-center gap-2">
              <FolderGit2 className="w-4 h-4 text-cyan-400" />
              <span>Restricted Log & Report File System Explorer</span>
            </h2>
            <span className="text-xs font-mono text-slate-500">({files.length} files)</span>
          </div>

          <button
            onClick={loadFiles}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 text-xs self-start sm:self-auto"
            title="Refresh directory list"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="text-slate-400 border-b border-slate-800">
              <tr>
                <th className="pb-2">Filename</th>
                <th className="pb-2">Category</th>
                <th className="pb-2">Size</th>
                <th className="pb-2">Inode / File ID</th>
                <th className="pb-2">Modified At</th>
                <th className="pb-2">Select Target</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60">
              {files.map(f => (
                <tr
                  key={f.name}
                  onClick={() => setSelectedFile(f.name)}
                  className={`hover:bg-slate-800/40 cursor-pointer transition-colors ${
                    selectedFile === f.name ? 'bg-cyan-950/20 border-l-2 border-l-cyan-400 font-bold' : ''
                  }`}
                >
                  <td className="py-2.5 text-white flex items-center gap-2 font-sans font-medium">
                    <FileText className="w-3.5 h-3.5 text-slate-400" />
                    <span>{f.name}</span>
                  </td>
                  <td className="py-2.5">
                    <span className="uppercase text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                      {f.category}
                    </span>
                  </td>
                  <td className="py-2.5 text-cyan-300">{f.size_formatted}</td>
                  <td className="py-2.5 text-slate-400">{f.inode}</td>
                  <td className="py-2.5 text-slate-400">{f.modified_at}</td>
                  <td className="py-2.5">
                    <span className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                      selectedFile === f.name ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                    }`}>
                      {selectedFile === f.name ? 'TARGET' : 'SELECT'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* MULTI-STRATEGY I/O BENCHMARK SANDBOX */}
      <div className="soc-card p-6 border-l-4 border-l-cyan-500 bg-slate-900/80 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Zap className="w-4 h-4 text-cyan-400" />
              <span>Real Kernel File I/O Benchmark: {selectedFile}</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Executes high-resolution timing comparing unbuffered small reads, 64KB block buffered reads, line iterations, and zero-copy mmap.
            </p>
          </div>

          <button
            onClick={handleRunBenchmark}
            disabled={benchmarking || !selectedFile}
            className="px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs flex items-center gap-2 shadow-lg shadow-cyan-950/40 transition-colors"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{benchmarking ? 'Measuring Latencies...' : 'Run I/O Benchmark'}</span>
          </button>
        </div>

        {/* BENCHMARK RESULTS */}
        {benchmarkResult && (
          <div className="space-y-4 pt-2">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
              <div className="p-3 rounded-lg bg-slate-950 border border-red-900/30">
                <span className="text-[10px] text-red-400 uppercase font-bold block">1. UNBUFFERED (64B)</span>
                <div className="text-lg font-bold text-white mt-1">
                  {benchmarkResult.timings_ms.unbuffered_64b_ms} ms
                </div>
                <span className="text-[10px] text-slate-500">Excessive sys_read() trap overhead</span>
              </div>

              <div className="p-3 rounded-lg bg-slate-950 border border-emerald-900/30">
                <span className="text-[10px] text-emerald-400 uppercase font-bold block">2. BUFFERED (64KB)</span>
                <div className="text-lg font-bold text-emerald-300 mt-1">
                  {benchmarkResult.timings_ms.buffered_64kb_ms} ms
                </div>
                <span className="text-[10px] text-slate-500">Optimized user-space block buffer</span>
              </div>

              <div className="p-3 rounded-lg bg-slate-950 border border-amber-900/30">
                <span className="text-[10px] text-amber-400 uppercase font-bold block">3. LINE-BY-LINE</span>
                <div className="text-lg font-bold text-amber-300 mt-1">
                  {benchmarkResult.timings_ms.readline_ms} ms
                </div>
                <span className="text-[10px] text-slate-500">Standard stream newline parsing</span>
              </div>

              <div className="p-3 rounded-lg bg-slate-950 border border-cyan-900/30">
                <span className="text-[10px] text-cyan-400 uppercase font-bold block">4. MEMORY-MAPPED</span>
                <div className="text-lg font-bold text-cyan-300 mt-1">
                  {benchmarkResult.timings_ms.mmap_ms} ms
                </div>
                <span className="text-[10px] text-slate-500">Direct page table mapping (zero-copy)</span>
              </div>
            </div>

            {/* Timing Comparison Chart */}
            <div className="h-56 p-4 rounded-lg bg-slate-950 border border-slate-800">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} layout="vertical">
                  <XAxis type="number" stroke="#64748b" fontSize={11} unit=" ms" />
                  <YAxis dataKey="name" type="category" stroke="#64748b" fontSize={11} width={140} />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', borderRadius: '8px', color: '#fff' }}
                  />
                  <Bar dataKey="time_ms" radius={[0, 4, 4, 0]} name="Execution Duration (ms)" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="p-3 rounded bg-slate-950 border border-slate-800 text-xs font-mono flex items-center justify-between">
              <div>
                <span className="text-slate-400">FASTEST READING STRATEGY: </span>
                <span className="text-emerald-400 font-bold">{benchmarkResult.fastest_strategy}</span>
              </div>
              <div>
                <span className="text-slate-400">MEASURED THROUGHPUT: </span>
                <span className="text-cyan-400 font-bold">{benchmarkResult.throughput_mbps} MB/s</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* EDUCATIONAL VFS & INODE ARCHITECTURE */}
      <div className="soc-card p-5 space-y-4">
        <h2 className="text-sm font-semibold text-white flex items-center gap-2">
          <Layers className="w-4 h-4 text-cyan-400" />
          <span>Linux Virtual File System (VFS) Layer & Inode Hierarchy</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs font-mono">
          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-cyan-400 font-bold block mb-1">1. File Descriptor (fd)</span>
            <p className="text-slate-400 text-[11px] font-sans">
              Integer index in the per-process file descriptor table pointing to an open file description object in kernel memory.
            </p>
          </div>

          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-emerald-400 font-bold block mb-1">2. Inode Object</span>
            <p className="text-slate-400 text-[11px] font-sans">
              Contains file metadata (size, uid, gid, permissions, timestamps, data block pointers). Completely decoupled from filename.
            </p>
          </div>

          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-amber-400 font-bold block mb-1">3. Directory Entry (dentry)</span>
            <p className="text-slate-400 text-[11px] font-sans">
              Maps human-readable path strings (e.g. <code>sample_system.log</code>) to an inode number. Cached in memory via the dcache.
            </p>
          </div>

          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800">
            <span className="text-violet-400 font-bold block mb-1">4. Page Cache Buffer</span>
            <p className="text-slate-400 text-[11px] font-sans">
              Caches 4KB disk blocks in physical RAM. Buffered reads satisfy requests from the page cache without triggering physical disk I/O.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
