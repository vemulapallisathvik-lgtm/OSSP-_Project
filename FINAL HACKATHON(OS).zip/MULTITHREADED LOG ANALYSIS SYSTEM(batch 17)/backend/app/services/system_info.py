import os
import sys
import time
import platform
import subprocess
import psutil
from datetime import datetime
from typing import Dict, Any, List

from ..core.config import (
    ALLOWED_COMMANDS,
    IS_WINDOWS,
    IS_LINUX,
    IS_DARWIN,
    PLATFORM_NAME,
    PLATFORM_RELEASE
)

def get_system_architecture_info() -> Dict[str, Any]:
    boot_time = datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M:%S")
    uptime_sec = round(time.time() - psutil.boot_time(), 1)
    vm = psutil.virtual_memory()

    return {
        "platform": PLATFORM_NAME,
        "release": PLATFORM_RELEASE,
        "version": platform.version(),
        "architecture": platform.machine(),
        "processor": platform.processor() or "x86_64 Compatible",
        "hostname": platform.node(),
        "python_version": platform.python_version(),
        "python_compiler": platform.python_compiler(),
        "cpu_physical_cores": psutil.cpu_count(logical=False) or 1,
        "cpu_logical_cores": psutil.cpu_count(logical=True) or 1,
        "cpu_current_freq_mhz": round(psutil.cpu_freq().current, 1) if psutil.cpu_freq() else 0,
        "total_ram_gb": round(vm.total / (1024 ** 3), 2),
        "available_ram_gb": round(vm.available / (1024 ** 3), 2),
        "boot_time": boot_time,
        "uptime_seconds": uptime_sec,
        "is_windows": IS_WINDOWS,
        "is_linux": IS_LINUX,
        "is_darwin": IS_DARWIN
    }

def execute_allowlisted_command(cmd_name: str) -> Dict[str, Any]:
    if cmd_name not in ALLOWED_COMMANDS:
        return {
            "success": False,
            "command_name": cmd_name,
            "executed_command": "N/A",
            "stdout": "",
            "stderr": f"Command '{cmd_name}' is not in the security allowlist. Arbitrary shell execution is disabled for safety.",
            "returncode": -1,
            "execution_time_ms": 0.0
        }

    cmd_args = ALLOWED_COMMANDS[cmd_name]
    t0 = time.perf_counter()
    try:
        proc = subprocess.run(
            cmd_args,
            capture_output=True,
            text=True,
            timeout=5.0,
            shell=False
        )
        duration_ms = round((time.perf_counter() - t0) * 1000.0, 2)
        return {
            "success": proc.returncode == 0,
            "command_name": cmd_name,
            "executed_command": " ".join(cmd_args),
            "stdout": proc.stdout.strip(),
            "stderr": proc.stderr.strip(),
            "returncode": proc.returncode,
            "execution_time_ms": duration_ms
        }
    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "command_name": cmd_name,
            "executed_command": " ".join(cmd_args),
            "stdout": "",
            "stderr": "Execution timed out after 5000ms",
            "returncode": -2,
            "execution_time_ms": 5000.0
        }
    except Exception as e:
        return {
            "success": False,
            "command_name": cmd_name,
            "executed_command": " ".join(cmd_args),
            "stdout": "",
            "stderr": str(e),
            "returncode": -3,
            "execution_time_ms": 0.0
        }

def get_syscall_catalog() -> List[Dict[str, Any]]:
    return [
        {
            "syscall": "sys_clone() / fork()",
            "number_x86_64": 56,
            "category": "Process Control",
            "description": "Creates a new execution context. With CLONE_VM and CLONE_THREAD flags, spawns POSIX threads sharing the same virtual address space; without them, creates child processes via Copy-On-Write (COW)."
        },
        {
            "syscall": "sys_read()",
            "number_x86_64": 0,
            "category": "File & Device I/O",
            "description": "Reads data from an open file descriptor into a user-space buffer. Invokes kernel page cache lookups and block device requests."
        },
        {
            "syscall": "sys_write()",
            "number_x86_64": 1,
            "category": "File & Device I/O",
            "description": "Writes data from user space to a file descriptor, dirtying OS page cache pages before committing to persistent storage via writeback."
        },
        {
            "syscall": "sys_mmap()",
            "number_x86_64": 9,
            "category": "Memory Management",
            "description": "Maps files or anonymous device memory directly into the process virtual address space. Enables zero-copy I/O by populating page tables on demand."
        },
        {
            "syscall": "sys_pipe2()",
            "number_x86_64": 293,
            "category": "Inter-Process Comm",
            "description": "Allocates a unidirectional kernel ring buffer with two connected file descriptors for streaming data between processes without filesystem I/O."
        },
        {
            "syscall": "sys_futex()",
            "number_x86_64": 202,
            "category": "Synchronization",
            "description": "Fast User-space Mutex: enables lock acquisition entirely in user space via atomic instructions (CMPXCHG), sleeping in the kernel only on contention."
        }
    ]
