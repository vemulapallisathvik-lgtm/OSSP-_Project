import os
import time
import queue
import threading
import uuid
from typing import Dict, List, Any, Optional, Callable
from collections import defaultdict
from pathlib import Path

from ..models.schemas import (
    WorkerTelemetry,
    QueueTelemetry,
    AnalysisProgressUpdate,
    LogEntry
)
from .log_parser import parse_log_line, evaluate_security_rules
from ..storage import db

class WorkerContext:
    def __init__(self, worker_id: str):
        self.worker_id = worker_id
        self.state = "IDLE"
        self.assigned_chunk_idx = -1
        self.entries_processed = 0
        self.errors_found = 0
        self.start_time: Optional[float] = None
        self.elapsed_seconds = 0.0
        self.last_activity = "Initialized"

    def to_telemetry(self) -> WorkerTelemetry:
        elapsed = (time.perf_counter() - self.start_time) if self.start_time and self.state == "RUNNING" else self.elapsed_seconds
        return WorkerTelemetry(
            worker_id=self.worker_id,
            state=self.state,
            assigned_chunk_idx=self.assigned_chunk_idx,
            entries_processed=self.entries_processed,
            errors_found=self.errors_found,
            start_time=self.start_time,
            elapsed_seconds=round(elapsed, 3),
            last_activity=self.last_activity
        )

class AnalysisSession:
    def __init__(
        self,
        analysis_id: str,
        filepath: Path,
        mode: str = "multi",
        worker_count: int = 4,
        chunk_size: int = 500
    ):
        self.analysis_id = analysis_id
        self.filepath = filepath
        self.mode = mode
        self.worker_count = 1 if mode == "single" else max(1, min(worker_count, 16))
        self.chunk_size = max(50, min(chunk_size, 5000))

        self.status = "queued"
        self.start_time = 0.0
        self.end_time = 0.0

        # Synchronization primitives
        self.lock = threading.Lock()
        self.cancel_event = threading.Event()
        self.task_queue: queue.Queue = queue.Queue(maxsize=50)

        # Telemetry & Aggregation
        self.workers: List[WorkerContext] = [
            WorkerContext(f"Worker-{i+1}") for i in range(self.worker_count)
        ]
        self.total_lines = 0
        self.parsed_lines = 0
        self.malformed_lines = 0
        self.total_chunks = 0
        self.completed_chunks = 0
        self.failed_chunks = 0

        self.severity_counts: Dict[str, int] = defaultdict(int)
        self.all_entries: List[LogEntry] = []
        self.recent_events: List[Dict[str, Any]] = []

        # Event stream subscribers
        self.subscribers: List[Callable[[AnalysisProgressUpdate], None]] = []

    def register_subscriber(self, callback: Callable[[AnalysisProgressUpdate], None]):
        with self.lock:
            self.subscribers.append(callback)

    def unregister_subscriber(self, callback: Callable[[AnalysisProgressUpdate], None]):
        with self.lock:
            if callback in self.subscribers:
                self.subscribers.remove(callback)

    def broadcast_progress(self):
        with self.lock:
            elapsed = (time.perf_counter() - self.start_time) if self.start_time > 0 else 0.0
            throughput = (self.parsed_lines / elapsed) if elapsed > 0.01 else 0.0
            percent = (self.completed_chunks / self.total_chunks * 100.0) if self.total_chunks > 0 else 0.0

            q_stats = QueueTelemetry(
                queue_size=self.task_queue.qsize(),
                total_chunks=self.total_chunks,
                completed_chunks=self.completed_chunks,
                pending_chunks=max(0, self.total_chunks - self.completed_chunks - self.failed_chunks),
                failed_chunks=self.failed_chunks,
                total_processed=self.parsed_lines,
                throughput_lps=round(throughput, 1)
            )

            update = AnalysisProgressUpdate(
                analysis_id=self.analysis_id,
                status=self.status,
                percent=min(100.0, round(percent, 1)),
                workers=[w.to_telemetry() for w in self.workers],
                queue_stats=q_stats,
                severity_counts=dict(self.severity_counts),
                recent_events=list(self.recent_events[-15:]),
                elapsed_seconds=round(elapsed, 3),
                total_lines=self.total_lines,
                parsed_lines=self.parsed_lines,
                malformed_lines=self.malformed_lines
            )
            subs = list(self.subscribers)

        for sub in subs:
            try:
                sub(update)
            except Exception:
                pass

    def run(self):
        self.status = "running"
        self.start_time = time.perf_counter()

        file_size = self.filepath.stat().st_size
        db.save_analysis_start(
            self.analysis_id,
            self.filepath.name,
            file_size,
            self.mode,
            self.worker_count,
            self.chunk_size
        )

        # 1. Count total lines for precise chunk progress
        try:
            with open(self.filepath, "r", encoding="utf-8", errors="replace") as f:
                self.total_lines = sum(1 for _ in f)
        except Exception as e:
            self.status = "failed"
            db.save_analysis_failure(self.analysis_id, str(e))
            self.broadcast_progress()
            return

        self.total_chunks = max(1, (self.total_lines + self.chunk_size - 1) // self.chunk_size)
        self.broadcast_progress()

        # 2. Start worker threads
        threads: List[threading.Thread] = []
        for ctx in self.workers:
            t = threading.Thread(
                target=self._worker_loop,
                args=(ctx,),
                name=f"ThreadWatch-{self.analysis_id}-{ctx.worker_id}",
                daemon=True
            )
            threads.append(t)
            t.start()

        # 3. Producer loop: read chunks and place in bounded queue
        producer_thread = threading.Thread(
            target=self._producer_loop,
            name=f"ThreadWatch-Producer-{self.analysis_id}",
            daemon=True
        )
        producer_thread.start()

        # Wait for producer to finish chunk dispatch
        producer_thread.join()

        # Wait for all chunks in queue to be processed
        self.task_queue.join()

        # Wait for worker threads
        for t in threads:
            t.join(timeout=2.0)

        self.end_time = time.perf_counter()
        duration = self.end_time - self.start_time
        throughput = (self.parsed_lines / duration) if duration > 0 else 0.0

        if self.cancel_event.is_set():
            self.status = "cancelled"
            db.save_analysis_failure(self.analysis_id, "Analysis cancelled by user")
        else:
            self.status = "completed"
            # Rule-based security evaluation
            findings = evaluate_security_rules(self.all_entries, self.analysis_id)
            db.save_analysis_complete(
                self.analysis_id,
                self.total_lines,
                self.parsed_lines,
                self.malformed_lines,
                round(duration, 4),
                round(throughput, 2),
                dict(self.severity_counts),
                findings
            )

        self.broadcast_progress()

    def _producer_loop(self):
        chunk_idx = 0
        try:
            with open(self.filepath, "r", encoding="utf-8", errors="replace") as f:
                current_chunk = []
                for line in f:
                    if self.cancel_event.is_set():
                        break
                    current_chunk.append(line)
                    if len(current_chunk) >= self.chunk_size:
                        self.task_queue.put((chunk_idx, current_chunk))
                        chunk_idx += 1
                        current_chunk = []
                        self.broadcast_progress()

                if current_chunk and not self.cancel_event.is_set():
                    self.task_queue.put((chunk_idx, current_chunk))
                    self.broadcast_progress()
        except Exception as e:
            with self.lock:
                self.status = "failed"
            print(f"Producer error: {e}")
        finally:
            # Signal workers to finish by enqueuing sentinel None for each worker
            for _ in range(self.worker_count):
                self.task_queue.put(None)

    def _worker_loop(self, ctx: WorkerContext):
        ctx.start_time = time.perf_counter()
        ctx.state = "WAITING"
        ctx.last_activity = "Awaiting chunk assignment"

        while not self.cancel_event.is_set():
            try:
                item = self.task_queue.get(timeout=0.2)
            except queue.Empty:
                continue

            if item is None:
                # Sentinel shutdown signal
                self.task_queue.task_done()
                break

            chunk_idx, lines = item
            ctx.state = "RUNNING"
            ctx.assigned_chunk_idx = chunk_idx
            ctx.last_activity = f"Processing chunk #{chunk_idx} ({len(lines)} lines)"

            chunk_entries: List[LogEntry] = []
            chunk_severities: Dict[str, int] = defaultdict(int)
            malformed_count = 0
            errors_count = 0

            # Process chunk lines
            for line in lines:
                if self.cancel_event.is_set():
                    break
                entry = parse_log_line(line)
                entry.thread_id = ctx.worker_id
                chunk_entries.append(entry)

                chunk_severities[entry.severity] += 1
                if entry.severity in ["ERROR", "CRITICAL", "SECURITY"]:
                    errors_count += 1
                if entry.is_fallback:
                    malformed_count += 1

            # Thread-safe aggregate update
            with self.lock:
                self.parsed_lines += len(chunk_entries)
                self.malformed_lines += malformed_count
                for sev, c in chunk_severities.items():
                    self.severity_counts[sev] += c
                self.completed_chunks += 1

                # Retain sample entries
                if len(self.all_entries) < 15000:
                    self.all_entries.extend(chunk_entries)

                for e in chunk_entries:
                    if len(self.recent_events) < 50:
                        self.recent_events.append({
                            "timestamp": e.timestamp or "N/A",
                            "severity": e.severity,
                            "source": e.process_name or "sys",
                            "process_id": e.process_id,
                            "message": e.message[:120],
                            "thread_id": ctx.worker_id,
                            "status": "PROCESSED"
                        })
                    else:
                        break

            ctx.entries_processed += len(chunk_entries)
            ctx.errors_found += errors_count
            ctx.state = "WAITING"
            ctx.last_activity = f"Completed chunk #{chunk_idx}"
            self.task_queue.task_done()
            self.broadcast_progress()

        ctx.state = "COMPLETED"
        ctx.elapsed_seconds = time.perf_counter() - (ctx.start_time or time.perf_counter())
        ctx.last_activity = f"Finished {ctx.entries_processed} entries"

    def cancel(self):
        self.cancel_event.set()
        # Drain queue
        while not self.task_queue.empty():
            try:
                self.task_queue.get_nowait()
                self.task_queue.task_done()
            except Exception:
                break
        self.status = "cancelled"
        self.broadcast_progress()


class WorkerManager:
    """Singleton manager tracking active analysis sessions"""
    def __init__(self):
        self.sessions: Dict[str, AnalysisSession] = {}
        self.lock = threading.Lock()

    def start_analysis(
        self,
        filepath: Path,
        mode: str = "multi",
        worker_count: int = 4,
        chunk_size: int = 500
    ) -> str:
        analysis_id = str(uuid.uuid4())[:8]
        session = AnalysisSession(
            analysis_id=analysis_id,
            filepath=filepath,
            mode=mode,
            worker_count=worker_count,
            chunk_size=chunk_size
        )
        with self.lock:
            self.sessions[analysis_id] = session

        # Launch async execution in dedicated background thread
        runner_thread = threading.Thread(
            target=session.run,
            name=f"ThreadWatch-SessionRunner-{analysis_id}",
            daemon=True
        )
        runner_thread.start()
        return analysis_id

    def get_session(self, analysis_id: str) -> Optional[AnalysisSession]:
        with self.lock:
            return self.sessions.get(analysis_id)

    def cancel_analysis(self, analysis_id: str) -> bool:
        session = self.get_session(analysis_id)
        if session:
            session.cancel()
            return True
        return False

# Global worker manager instance
manager = WorkerManager()
