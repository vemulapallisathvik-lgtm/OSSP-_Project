# ThreadWatch — Course Outcome (CO) & Operating Systems Concept Mapping

This document provides a formal, verifiable mapping of the ThreadWatch platform against all six Course Outcomes (CO-1 through CO-6) for academic and hackathon evaluation.

---

## Comprehensive Course Outcome Verification Matrix

| Course Outcome | Primary OS Concept | ThreadWatch Feature / Page | Backend Implementation File | API Endpoint | Judge Verification Method |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **CO-1** | OS as a Service Layer, System Call Interface (SCI), User vs Kernel Space (Ring 3 vs Ring 0) | **System Information** (`/system`) | `backend/app/services/system_info.py` | `GET /api/system/info`<br>`GET /api/system/syscalls`<br>`POST /api/system/execute-command` | Select an allowlisted command (e.g. `whoami`, `hostname`, `cpu_count`) and click **Run Command**. Observe real non-shell execution duration in ms, returncode 0, stdout, and inspect the Layered Architecture and System Call Explorer cards. |
| **CO-2** | Processes and Process Control, Process Control Blocks (PCB), Process States, Parent-Child Hierarchies | **Process Explorer** (`/processes`) | `backend/app/services/process_monitor.py` | `GET /api/processes`<br>`GET /api/processes/{pid}`<br>`POST /api/demo/process/start`<br>`POST /api/demo/process/stop` | 1. View live processes queried via kernel `psutil`.<br>2. Click **Start Child Process** in the sandbox to spawn a controlled OS process.<br>3. Verify its PID, active state, and uptime.<br>4. Click **Terminate Child** to verify safe application-bounded process termination. |
| **CO-3** | Inter-Process Communication (IPC), Kernel Anonymous Pipes, Half/Full Duplex Streams, Asynchronous Signals | **IPC Laboratory** (`/ipc`) | `backend/app/services/ipc_manager.py` | `POST /api/ipc/send`<br>`POST /api/ipc/signal` | Enter a message (e.g. `SYN_LOG_AUDIT_PROBE`) and click **Transmit via Kernel Pipe**. Observe parent PID sending message across the kernel boundary to child PID, verifying SHA-256 payload checksum and round-trip latency (ms). Click **Dispatch Signal** to test interrupt notifications. |
| **CO-4** | Memory Management, Virtual Address Spaces, Multi-Level Page Tables, Demand Paging, Resident Set Size (RSS) | **Memory Inspector** (`/memory`) | `backend/app/services/memory_monitor.py` | `GET /api/memory/metrics`<br>`POST /api/memory/demo/allocate`<br>`POST /api/memory/demo/release` | 1. View host RAM and application RSS/VMS memory metrics.<br>2. Choose 25 MB and click **Commit & Dirty Pages**. An isolated child process is spawned, allocating a byte buffer and dirtying 4KB pages to force physical page frame allocation.<br>3. Observe measured RSS before/after delta (+25 MB).<br>4. Click **Release Memory** to verify OS frame reclamation. |
| **CO-5** | File Systems and File I/O, Virtual File System (VFS), Inodes, File Descriptors, Buffered vs Unbuffered I/O, mmap | **File System Lab** (`/filesystem`) | `backend/app/services/file_io_benchmark.py` | `GET /api/files`<br>`POST /api/files/benchmark` | 1. Browse restricted log and report directories with inode metadata.<br>2. Select `sample_system.log` and click **Run I/O Benchmark**.<br>3. High-resolution timers compare unbuffered 64B reads, 64KB block buffered reads, readline stream, and zero-copy `mmap` kernel mapping. |
| **CO-6** | Concurrency and Synchronization, Race Conditions, Mutex Locks (`threading.Lock`), Producer-Consumer Queues, Coffman Deadlock Conditions | **Concurrency Lab** (`/concurrency`) & **Thread Monitor** (`/threads`) | `backend/app/services/concurrency_lab.py`<br>`backend/app/services/worker_manager.py` | `POST /api/concurrency/race-demo`<br>`POST /api/concurrency/deadlock-sim`<br>`GET /api/analyze/stream/{id}` | 1. Run the **Race Condition Experiment** with 4 threads and 50,000 iterations: observe non-atomic update loss in the unsynchronized run vs 100% integrity in the mutex-locked run.<br>2. Run the **Deadlock Simulator**: observe circular wait detection with timeout vs prevention via global resource hierarchy (A ➔ B).<br>3. Inspect the live worker grid and task queue pipeline on the Thread Monitor page. |

---

## Detailed OS Architecture Explanations

### 1. CO-1: OS as a Service Layer
- **User Space vs Kernel Space**: x86_64 architecture enforces privilege separation using CPU rings (Ring 3 for user applications, Ring 0 for the OS kernel). User applications cannot access hardware directly; any I/O, process creation, or memory allocation must transition through the System Call Interface (SCI).
- **Command Sandboxing**: In ThreadWatch, diagnostic commands are executed using argument vectors (`subprocess.run(["whoami"], shell=False)`), preventing shell injection attacks while demonstrating real OS interactions.

### 2. CO-2: Processes and Process Control
- **Process Control Block (PCB)**: Maintained by the kernel to record process state, CPU registers, memory limits, and file descriptor tables.
- **Process Lifecycle**: Transitioning from `NEW` ➔ `READY` ➔ `RUNNING` ➔ `TERMINATED`. ThreadWatch manages its own dedicated child process, demonstrating graceful SIGTERM termination without touching arbitrary system processes.

### 3. CO-3: Inter-Process Communication
- **Anonymous Pipes**: Implemented via `multiprocessing.Pipe`, allocating unidirectional/duplex kernel ring buffers.
- **Data Flow**: Parent process transmits audit probes across the boundary; the child process intercepts the stream, computes cryptographic verification, and returns an ACK packet with real-time round-trip latency measurements.

### 4. CO-4: Memory Management
- **Demand Paging**: Modern operating systems do not allocate physical page frames immediately upon `malloc()` or `bytearray()`. Physical frames are assigned only when the CPU experiences a minor page fault upon touching memory addresses.
- **Controlled Allocation**: The ThreadWatch memory demo touches memory at 4096-byte increments (standard x86 page size), demonstrating measurable expansion of the Resident Set Size (RSS).

### 5. CO-5: File Systems and File I/O
- **VFS (Virtual File System)**: Provides an abstraction layer hiding filesystem-specific drivers (ext4, NTFS, XFS).
- **Buffered vs Unbuffered I/O**: Unbuffered reads issue frequent `sys_read()` system calls, trapping into the kernel repeatedly. Buffered reads amortize context-switch overhead across larger page blocks (64 KB). Memory mapping (`mmap`) maps file blocks directly into the process page table, eliminating user-kernel buffer copying.

### 6. CO-6: Concurrency and Synchronization
- **Producer-Consumer Pattern**: Log files are read by a producer thread into manageable chunks of $N$ lines and enqueued in a bounded `queue.Queue(maxsize=50)`. Worker threads retrieve chunks concurrently and update shared telemetry using `threading.Lock`.
- **Deadlock Prevention**: The Deadlock Simulator demonstrates Dijkstra's resource hierarchy solution: by establishing a strict global total ordering over lock acquisition (Rank Lock A < Rank Lock B), circular wait is eliminated.
