import {
  AnalysisRecord,
  AnalysisProgressUpdate,
  BenchmarkRecord,
  ProcessItem,
  ProcessDetails,
  DemoProcessStatus,
  IpcResponse,
  MemoryMetrics,
  MemoryDemoResponse,
  FileItem,
  FileBenchmarkResult,
  RaceDemoResult,
  DeadlockSimResult,
  SystemInfo,
  SyscallItem,
  SafeCommandResult,
  SecurityFinding
} from '../types';

const API_BASE = '/api';

async function handleResponse<T>(res: Response): Promise<T> {
  if (!res.ok) {
    let errorDetail = 'API request failed';
    try {
      const errJson = await res.json();
      errorDetail = errJson.detail || errJson.message || errorDetail;
    } catch {
      errorDetail = await res.text();
    }
    throw new Error(errorDetail || `HTTP error ${res.status}`);
  }
  return res.json() as Promise<T>;
}

export const api = {
  // Health & Overview
  getHealth: () => fetch(`${API_BASE}/health`).then(res => handleResponse<{ status: string; service: string }>(res)),
  getOverview: () => fetch(`${API_BASE}/overview`).then(res => handleResponse<any>(res)),

  // System Info (CO-1)
  getSystemInfo: () => fetch(`${API_BASE}/system/info`).then(res => handleResponse<SystemInfo>(res)),
  getSyscalls: () => fetch(`${API_BASE}/system/syscalls`).then(res => handleResponse<SyscallItem[]>(res)),
  executeCommand: (command_name: string) =>
    fetch(`${API_BASE}/system/execute-command`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ command_name })
    }).then(res => handleResponse<SafeCommandResult>(res)),

  // Process Explorer (CO-2)
  listProcesses: (search: string = '', limit: number = 50) =>
    fetch(`${API_BASE}/processes?search=${encodeURIComponent(search)}&limit=${limit}`).then(res => handleResponse<ProcessItem[]>(res)),
  inspectProcess: (pid: number) => fetch(`${API_BASE}/processes/${pid}`).then(res => handleResponse<ProcessDetails>(res)),
  startDemoProcess: () =>
    fetch(`${API_BASE}/demo/process/start`, { method: 'POST' }).then(res => handleResponse<DemoProcessStatus>(res)),
  stopDemoProcess: () =>
    fetch(`${API_BASE}/demo/process/stop`, { method: 'POST' }).then(res => handleResponse<any>(res)),
  getDemoProcessStatus: () => fetch(`${API_BASE}/demo/process/status`).then(res => handleResponse<DemoProcessStatus>(res)),

  // IPC Laboratory (CO-3)
  sendIpc: (message: string) =>
    fetch(`${API_BASE}/ipc/send`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message })
    }).then(res => handleResponse<IpcResponse>(res)),
  triggerIpcSignal: () => fetch(`${API_BASE}/ipc/signal`, { method: 'POST' }).then(res => handleResponse<any>(res)),

  // Memory Inspector (CO-4)
  getMemoryMetrics: () => fetch(`${API_BASE}/memory/metrics`).then(res => handleResponse<MemoryMetrics>(res)),
  allocateMemory: (size_mb: number) =>
    fetch(`${API_BASE}/memory/demo/allocate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'allocate', size_mb })
    }).then(res => handleResponse<MemoryDemoResponse>(res)),
  releaseMemory: () => fetch(`${API_BASE}/memory/demo/release`, { method: 'POST' }).then(res => handleResponse<any>(res)),
  getMemoryDemoStatus: () => fetch(`${API_BASE}/memory/demo/status`).then(res => handleResponse<any>(res)),

  // File System Lab (CO-5)
  listFiles: () => fetch(`${API_BASE}/files`).then(res => handleResponse<FileItem[]>(res)),
  runFileBenchmark: (filename: string) =>
    fetch(`${API_BASE}/files/benchmark`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ filename })
    }).then(res => handleResponse<FileBenchmarkResult>(res)),

  // Concurrency Lab (CO-6)
  runRaceDemo: (thread_count: number, iterations_per_thread: number) =>
    fetch(`${API_BASE}/concurrency/race-demo`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ thread_count, iterations_per_thread })
    }).then(res => handleResponse<RaceDemoResult>(res)),
  runDeadlockSim: (prevent_deadlock: boolean) =>
    fetch(`${API_BASE}/concurrency/deadlock-sim`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ prevent_deadlock })
    }).then(res => handleResponse<DeadlockSimResult>(res)),

  // Performance Lab
  runBenchmark: (dataset_name: string, worker_count: number, chunk_size: number) =>
    fetch(`${API_BASE}/benchmark/run`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ dataset_name, worker_count, chunk_size })
    }).then(res => handleResponse<BenchmarkRecord>(res)),
  getBenchmarkHistory: () => fetch(`${API_BASE}/benchmark/history`).then(res => handleResponse<BenchmarkRecord[]>(res)),

  // Log Analysis Engine
  uploadLogFile: async (file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    const res = await fetch(`${API_BASE}/analyze/upload`, {
      method: 'POST',
      body: formData
    });
    return handleResponse<{ filename: string; size_bytes: number; message: string }>(res);
  },
  startAnalysis: (filename: string, mode: 'single' | 'multi', worker_count: number, chunk_size: number) =>
    fetch(`${API_BASE}/analyze/start`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ filename, mode, worker_count, chunk_size })
    }).then(res => handleResponse<{ analysis_id: string; status: string }>(res)),
  cancelAnalysis: (analysisId: string) =>
    fetch(`${API_BASE}/analyze/cancel/${analysisId}`, { method: 'POST' }).then(res => handleResponse<any>(res)),
  getAnalysisResults: (analysisId: string) =>
    fetch(`${API_BASE}/analyze/${analysisId}/results`).then(res => handleResponse<AnalysisRecord>(res)),
  getRecentAnalyses: () => fetch(`${API_BASE}/analyze/recent`).then(res => handleResponse<AnalysisRecord[]>(res)),

  // Security Center
  getSecurityFindings: (unreviewedOnly: boolean = false) =>
    fetch(`${API_BASE}/security/findings?unreviewed_only=${unreviewedOnly}`).then(res => handleResponse<SecurityFinding[]>(res)),
  toggleReviewFinding: (findingId: number) =>
    fetch(`${API_BASE}/security/findings/${findingId}/review`, { method: 'POST' }).then(res => handleResponse<any>(res)),

  // Reports
  getReports: () => fetch(`${API_BASE}/reports`).then(res => handleResponse<AnalysisRecord[]>(res)),
  getReportJsonUrl: (analysisId: string) => `${API_BASE}/reports/${analysisId}/json`,
  getReportCsvUrl: (analysisId: string) => `${API_BASE}/reports/${analysisId}/csv`
};
