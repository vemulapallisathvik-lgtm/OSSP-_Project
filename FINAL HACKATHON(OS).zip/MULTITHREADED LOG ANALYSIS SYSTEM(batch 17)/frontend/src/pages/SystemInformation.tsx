import React, { useState, useEffect } from 'react';
import {
  Layers,
  Terminal,
  Cpu,
  HardDrive,
  Activity,
  Play,
  ShieldCheck,
  BookOpen,
  CheckCircle,
  HelpCircle,
  Clock
} from 'lucide-react';

import { api } from '../services/api';
import { CoBanner } from '../components/CoBanner';
import { StatCard } from '../components/StatCard';
import { SystemInfo, SyscallItem, SafeCommandResult } from '../types';

export const SystemInformation: React.FC = () => {
  const [sysInfo, setSysInfo] = useState<SystemInfo | null>(null);
  const [syscalls, setSyscalls] = useState<SyscallItem[]>([]);
  const [selectedCmd, setSelectedCmd] = useState<string>('whoami');
  const [cmdResult, setCmdResult] = useState<SafeCommandResult | null>(null);
  const [executing, setExecuting] = useState<boolean>(false);

  useEffect(() => {
    api.getSystemInfo().then(res => setSysInfo(res)).catch(console.error);
    api.getSyscalls().then(res => setSyscalls(res)).catch(console.error);
  }, []);

  const handleExecuteCommand = async () => {
    setExecuting(true);
    try {
      const res = await api.executeCommand(selectedCmd);
      setCmdResult(res);
    } catch (err: any) {
      alert(`Command execution failed: ${err.message}`);
    } finally {
      setExecuting(false);
    }
  };

  return (
    <div className="space-y-6">
      <CoBanner
        outcome="CO-1"
        title="OS as a Service Layer"
        concept="User Space vs Kernel Space (Ring 3 to Ring 0 Transitions), System Call Interface (SCI), and Safe Command Sandboxing"
        implementationFile="backend/app/services/system_info.py"
        endpoint="GET /api/system/info | POST /api/system/execute-command"
        verificationTip="Select an allowlisted command (e.g. whoami or hostname) and execute it to verify safe non-shell subprocess execution and real OS runtime data."
      />

      {/* SYSTEM ARCHITECTURE OVERVIEW CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Operating System"
          value={sysInfo ? sysInfo.platform : 'Loading...'}
          subtitle={`Release: ${sysInfo ? sysInfo.release : '-'}`}
          icon={Layers}
          color="cyan"
          badge={sysInfo?.architecture}
        />
        <StatCard
          title="Hostname Node"
          value={sysInfo ? sysInfo.hostname : 'Loading...'}
          subtitle={`CPU Cores: ${sysInfo ? sysInfo.cpu_logical_cores : '-'}`}
          icon={Cpu}
          color="emerald"
        />
        <StatCard
          title="Python Runtime"
          value={sysInfo ? `v${sysInfo.python_version}` : 'Loading...'}
          subtitle="CPython with multithreading"
          icon={Terminal}
          color="violet"
          badge="Host"
        />
        <StatCard
          title="System Uptime"
          value={sysInfo ? `${Math.floor(sysInfo.uptime_seconds / 3600)}h ${Math.floor((sysInfo.uptime_seconds % 3600) / 60)}m` : '-'}
          subtitle={`Boot Time: ${sysInfo?.boot_time.split(' ')[0]}`}
          icon={Clock}
          color="amber"
        />
      </div>

      {/* LAYERED OS ARCHITECTURE DIAGRAM */}
      <div className="soc-card p-6 border-l-4 border-l-cyan-500 bg-slate-900/80 space-y-4">
        <h2 className="text-sm font-bold text-white flex items-center gap-2">
          <Layers className="w-4 h-4 text-cyan-400" />
          <span>Layered Operating System Architecture & Privilege Rings</span>
        </h2>

        <div className="space-y-2.5 font-mono text-xs">
          {/* Level 1: User Applications */}
          <div className="p-3 rounded-lg bg-cyan-950/30 border border-cyan-500/40 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 font-bold text-[10px]">RING 3</span>
              <span className="text-white font-bold">1. User Applications</span>
              <span className="text-slate-400 font-sans text-[11px] hidden sm:inline">
                ThreadWatch Dashboard, Python Interpreter, User Processes
              </span>
            </div>
            <span className="text-cyan-400 text-[10px] font-bold">Unprivileged User Mode</span>
          </div>

          {/* Level 2: Standard Libraries */}
          <div className="p-3 rounded-lg bg-slate-900 border border-slate-700 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-bold text-[10px]">LIBS</span>
              <span className="text-white font-bold">2. System Libraries & Wrappers</span>
              <span className="text-slate-400 font-sans text-[11px] hidden sm:inline">
                glibc, POSIX APIs, Win32 API, libpthread
              </span>
            </div>
            <span className="text-slate-400 text-[10px]">User Space Runtime</span>
          </div>

          {/* TRANSITION BOUNDARY: SCI */}
          <div className="py-1 px-4 rounded bg-amber-500/10 border border-dashed border-amber-500/40 flex items-center justify-between text-amber-300 text-[11px]">
            <span className="font-bold">SYSTEM CALL INTERFACE (SCI) ➔ CPU Trap / syscall Instruction</span>
            <span className="text-[10px]">Context Switch & Ring Transition (Ring 3 ➔ Ring 0)</span>
          </div>

          {/* Level 3: Kernel Space */}
          <div className="p-3.5 rounded-lg bg-slate-950 border border-emerald-500/40 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold text-[10px]">RING 0</span>
                <span className="text-white font-bold">3. Monolithic Operating System Kernel</span>
              </div>
              <span className="text-emerald-400 text-[10px] font-bold">Privileged Supervisor Mode</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1 text-[11px]">
              <div className="p-2 rounded bg-slate-900 border border-slate-800 text-center text-slate-300">
                Process Scheduler & Threads
              </div>
              <div className="p-2 rounded bg-slate-900 border border-slate-800 text-center text-slate-300">
                Virtual Memory Manager
              </div>
              <div className="p-2 rounded bg-slate-900 border border-slate-800 text-center text-slate-300">
                Virtual File System (VFS)
              </div>
              <div className="p-2 rounded bg-slate-900 border border-slate-800 text-center text-slate-300">
                IPC & Network Stack
              </div>
            </div>
          </div>

          {/* Level 4: Hardware */}
          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-400 font-bold text-[10px]">HW</span>
              <span className="text-slate-300 font-bold">4. Physical Hardware Devices</span>
              <span className="text-slate-500 font-sans text-[11px] hidden sm:inline">
                x86_64 CPU Cores, Physical RAM, NVMe/SATA SSDs, Network Interface Card (NIC)
              </span>
            </div>
            <span className="text-slate-500 text-[10px]">Physical Layer</span>
          </div>
        </div>
      </div>

      {/* SAFE COMMAND EXECUTION TERMINAL */}
      <div className="soc-card p-6 border-l-4 border-l-emerald-500 bg-slate-900/80 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Terminal className="w-4 h-4 text-emerald-400" />
              <span>Restricted Allowlisted OS Command Sandbox</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Executes permitted read-only operating system diagnostic commands safely via argument vectors (no shell interpolation).
            </p>
          </div>

          <div className="flex items-center gap-2">
            <select
              value={selectedCmd}
              onChange={e => setSelectedCmd(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs font-mono text-cyan-300 focus:outline-none focus:border-cyan-500"
            >
              <option value="whoami">whoami (Process Identity)</option>
              <option value="hostname">hostname (Network Node)</option>
              <option value="python_version">python_version (Interpreter)</option>
              <option value="system_platform">system_platform (Platform Info)</option>
              <option value="cpu_count">cpu_count (CPU Hardware Topology)</option>
              <option value="date">date (System RTC Clock)</option>
              <option value="disk_usage">disk_usage (Storage Statistics)</option>
            </select>

            <button
              onClick={handleExecuteCommand}
              disabled={executing}
              className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-medium text-xs flex items-center gap-1.5 shadow-sm transition-colors"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{executing ? 'Executing...' : 'Run Command'}</span>
            </button>
          </div>
        </div>

        {/* TERMINAL OUTPUT SCREEN */}
        <div className="p-4 rounded-lg bg-slate-950 border border-slate-800 font-mono text-xs space-y-2">
          <div className="flex items-center justify-between text-[11px] text-slate-500 border-b border-slate-900 pb-2">
            <span>TERMINAL EMULATOR / VIRTUAL CONSOLE</span>
            {cmdResult && (
              <span className="text-cyan-400">
                Executed in {cmdResult.execution_time_ms} ms (Exit Code: {cmdResult.returncode})
              </span>
            )}
          </div>

          <div className="text-slate-400">
            <span className="text-emerald-400">threadwatch@soc-node</span>
            <span className="text-slate-600">:</span>
            <span className="text-cyan-400">~</span>
            <span className="text-slate-200">$ {cmdResult ? cmdResult.executed_command : selectedCmd}</span>
          </div>

          {cmdResult ? (
            <div className="pt-1">
              {cmdResult.stdout && (
                <pre className="text-slate-100 whitespace-pre-wrap">{cmdResult.stdout}</pre>
              )}
              {cmdResult.stderr && (
                <pre className="text-red-400 whitespace-pre-wrap">{cmdResult.stderr}</pre>
              )}
            </div>
          ) : (
            <div className="text-slate-600 italic">Click 'Run Command' to invoke safe kernel subprocess.</div>
          )}
        </div>
      </div>

      {/* SYSTEM CALL EXPLORER */}
      <div className="soc-card p-5 space-y-4">
        <h2 className="text-sm font-semibold text-white flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-cyan-400" />
          <span>Core Linux System Call Catalog (SCI)</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 text-xs font-mono">
          {syscalls.map(sc => (
            <div key={sc.syscall} className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-cyan-300 font-bold">{sc.syscall}</span>
                <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                  x86_64: #{sc.number_x86_64}
                </span>
              </div>
              <span className="text-[10px] text-emerald-400 font-semibold block uppercase">
                {sc.category}
              </span>
              <p className="text-slate-400 font-sans text-[11px] leading-relaxed">
                {sc.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
