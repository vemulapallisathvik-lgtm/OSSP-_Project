import os
import csv
import io
import json
import asyncio
from pathlib import Path
from typing import Optional, Dict, Any, List
from fastapi import APIRouter, UploadFile, File, Form, HTTPException, Query, WebSocket, WebSocketDisconnect
from fastapi.responses import StreamingResponse, JSONResponse, Response

from ..core.config import UPLOADS_DIR, DATASETS_DIR, REPORTS_DIR, MAX_FILE_SIZE_BYTES
from ..models.schemas import (
    StartAnalysisRequest,
    BenchmarkRequest,
    RaceDemoRequest,
    DeadlockSimRequest,
    IpcSendRequest,
    MemoryDemoRequest,
    FileBenchmarkRequest,
    SafeCommandRequest
)
from ..storage import db
from ..services.worker_manager import manager
from ..services.process_monitor import process_service
from ..services.ipc_manager import ipc_service
from ..services.memory_monitor import memory_service
from ..services.file_io_benchmark import list_allowed_files, benchmark_file_io
from ..services.concurrency_lab import concurrency_service
from ..services.benchmark import benchmark_service
from ..services.system_info import (
    get_system_architecture_info,
    execute_allowlisted_command,
    get_syscall_catalog
)

router = APIRouter(prefix="/api")

# --- HEALTH & OVERVIEW ---
@router.get("/health")
def get_health():
    return {
        "status": "healthy",
        "service": "ThreadWatch Backend",
        "version": "1.0.0",
        "timestamp": os.path.getmtime(__file__)
    }

@router.get("/overview")
def get_overview_metrics():
    sys_metrics = memory_service.get_system_metrics()
    recent = db.get_recent_analyses(limit=5)
    benchmarks = db.get_recent_benchmarks(limit=5)
    findings = db.get_all_security_findings(limit=10)

    # Aggregates across all analyses
    total_entries = sum(a.get("total_lines", 0) for a in recent)
    total_errors = sum(a.get("severities", {}).get("ERROR", 0) for a in recent)
    total_warnings = sum(a.get("severities", {}).get("WARNING", 0) for a in recent)
    total_critical = sum(a.get("severities", {}).get("CRITICAL", 0) for a in recent)
    
    # Active workers in currently running sessions
    active_workers = 0
    with manager.lock:
        for s in manager.sessions.values():
            if s.status == "running":
                active_workers += sum(1 for w in s.workers if w.state == "RUNNING")

    return {
        "summary": {
            "total_log_entries": total_entries,
            "errors_detected": total_errors,
            "warnings_detected": total_warnings,
            "critical_events": total_critical,
            "active_worker_threads": active_workers,
            "system_cpu_percent": round(sys_metrics["percent"], 1),
            "process_rss_mb": sys_metrics["process_rss_mb"],
            "process_vms_mb": sys_metrics["process_vms_mb"],
            "system_ram_used_mb": sys_metrics["used_mb"],
            "system_ram_total_mb": sys_metrics["total_mb"]
        },
        "recent_analyses": recent,
        "recent_benchmarks": benchmarks,
        "recent_findings": findings[:5]
    }

# --- SYSTEM INFORMATION (CO-1) ---
@router.get("/system/info")
def get_system_info():
    return get_system_architecture_info()

@router.get("/system/syscalls")
def get_syscalls():
    return get_syscall_catalog()

@router.post("/system/execute-command")
def run_command(req: SafeCommandRequest):
    return execute_allowlisted_command(req.command_name)

# --- PROCESS EXPLORER (CO-2) ---
@router.get("/processes")
def list_processes(search: str = Query(default=""), limit: int = Query(default=50, le=100)):
    return process_service.list_processes(search=search, limit=limit)

@router.get("/processes/{pid}")
def inspect_process(pid: int):
    proc = process_service.inspect_process(pid)
    if not proc:
        raise HTTPException(status_code=404, detail=f"Process {pid} not found or access denied")
    return proc

@router.post("/demo/process/start")
def start_demo_process():
    return process_service.start_demo_process()

@router.post("/demo/process/stop")
def stop_demo_process():
    return process_service.stop_demo_process()

@router.get("/demo/process/status")
def get_demo_process_status():
    return process_service.get_demo_process_status()

# --- IPC LABORATORY (CO-3) ---
@router.post("/ipc/send")
def send_ipc_message(req: IpcSendRequest):
    return ipc_service.send_message(req.message)

@router.post("/ipc/signal")
def trigger_ipc_signal():
    return ipc_service.test_signal_event()

# --- MEMORY INSPECTOR (CO-4) ---
@router.get("/memory/metrics")
def get_memory_metrics():
    return memory_service.get_system_metrics()

@router.post("/memory/demo/allocate")
def allocate_memory(req: MemoryDemoRequest):
    return memory_service.allocate_bounded_memory(req.size_mb)

@router.post("/memory/demo/release")
def release_memory():
    return memory_service.release_memory()

@router.get("/memory/demo/status")
def get_memory_allocation_status():
    return memory_service.get_allocation_status()

# --- FILE SYSTEM LAB (CO-5) ---
@router.get("/files")
def list_files():
    return list_allowed_files()

@router.post("/files/benchmark")
def run_file_io_benchmark(req: FileBenchmarkRequest):
    try:
        return benchmark_file_io(req.filename)
    except FileNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# --- CONCURRENCY LAB (CO-6) ---
@router.post("/concurrency/race-demo")
def run_race_demo(req: RaceDemoRequest):
    return concurrency_service.run_race_condition_demo(
        thread_count=req.thread_count,
        iterations_per_thread=req.iterations_per_thread
    )

@router.post("/concurrency/deadlock-sim")
def run_deadlock_sim(req: DeadlockSimRequest):
    return concurrency_service.simulate_deadlock(prevent_deadlock=req.prevent_deadlock)

# --- PERFORMANCE BENCHMARK ---
@router.post("/benchmark/run")
def run_benchmark(req: BenchmarkRequest):
    try:
        return benchmark_service.run_benchmark(
            dataset_name=req.dataset_name,
            worker_count=req.worker_count,
            chunk_size=req.chunk_size
        )
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/benchmark/history")
def get_benchmark_history(limit: int = 10):
    return db.get_recent_benchmarks(limit=limit)

# --- LOG ANALYSIS ENGINE ---
@router.post("/analyze/upload")
async def upload_log_file(file: UploadFile = File(...)):
    # Validate file extension
    ext = Path(file.filename).suffix.lower()
    if ext not in [".log", ".txt", ".csv"]:
        raise HTTPException(status_code=400, detail="Only .log, .txt, and .csv files are supported")

    # Safe sanitize filename
    safe_name = Path(file.filename).name.replace(" ", "_")
    target_path = UPLOADS_DIR / safe_name

    # Check size streamingly
    total_bytes = 0
    with open(target_path, "wb") as out:
        while chunk := await file.read(65536):
            total_bytes += len(chunk)
            if total_bytes > MAX_FILE_SIZE_BYTES:
                out.close()
                target_path.unlink(missing_ok=True)
                raise HTTPException(status_code=413, detail="File exceeds maximum size of 100MB")
            out.write(chunk)

    return {
        "filename": safe_name,
        "size_bytes": total_bytes,
        "message": f"Successfully uploaded {safe_name} ({total_bytes / 1024:.1f} KB)"
    }

@router.post("/analyze/start")
def start_analysis(req: StartAnalysisRequest):
    # Locate file in datasets or uploads
    target = None
    for root in [DATASETS_DIR, UPLOADS_DIR]:
        candidate = root / req.filename
        if candidate.exists() and candidate.is_file():
            target = candidate
            break

    if not target:
        raise HTTPException(status_code=404, detail=f"Log file '{req.filename}' not found")

    analysis_id = manager.start_analysis(
        filepath=target,
        mode=req.mode,
        worker_count=req.worker_count,
        chunk_size=req.chunk_size
    )

    return {
        "analysis_id": analysis_id,
        "filename": req.filename,
        "mode": req.mode,
        "worker_count": 1 if req.mode == "single" else req.worker_count,
        "chunk_size": req.chunk_size,
        "status": "started"
    }

@router.post("/analyze/cancel/{analysis_id}")
def cancel_analysis(analysis_id: str):
    success = manager.cancel_analysis(analysis_id)
    if not success:
        raise HTTPException(status_code=404, detail="Analysis session not found or already finished")
    return {"status": "cancelled", "analysis_id": analysis_id}

@router.get("/analyze/recent")
def get_recent_analyses(limit: int = 15):
    return db.get_recent_analyses(limit=limit)

@router.get("/analyze/{analysis_id}/results")
def get_analysis_results(analysis_id: str):
    res = db.get_analysis_by_id(analysis_id)
    if not res:
        raise HTTPException(status_code=404, detail=f"Analysis '{analysis_id}' not found")
    return res

@router.get("/analyze/{analysis_id}/status")
def get_analysis_status(analysis_id: str):
    session = manager.get_session(analysis_id)
    if session:
        elapsed = (time.perf_counter() - session.start_time) if session.start_time > 0 else 0.0
        return {
            "analysis_id": analysis_id,
            "status": session.status,
            "percent": round((session.completed_chunks / max(1, session.total_chunks) * 100.0), 1),
            "parsed_lines": session.parsed_lines,
            "total_lines": session.total_lines,
            "workers": [w.to_telemetry().model_dump() for w in session.workers],
            "severity_counts": dict(session.severity_counts),
            "elapsed_seconds": round(elapsed, 2)
        }
    
    # Check DB
    db_res = db.get_analysis_by_id(analysis_id)
    if db_res:
        return {
            "analysis_id": analysis_id,
            "status": db_res["status"],
            "percent": 100.0 if db_res["status"] == "completed" else 0.0,
            "parsed_lines": db_res["parsed_lines"],
            "total_lines": db_res["total_lines"],
            "workers": [],
            "severity_counts": db_res["severities"],
            "elapsed_seconds": db_res["duration_seconds"]
        }

    raise HTTPException(status_code=404, detail="Analysis not found")

# --- LIVE STREAMING: SSE ---
@router.get("/analyze/stream/{analysis_id}")
async def stream_analysis_progress(analysis_id: str):
    session = manager.get_session(analysis_id)
    if not session:
        # Check if already completed in DB
        db_res = db.get_analysis_by_id(analysis_id)
        if db_res:
            payload = json.dumps({
                "analysis_id": analysis_id,
                "status": db_res["status"],
                "percent": 100.0,
                "parsed_lines": db_res["parsed_lines"],
                "total_lines": db_res["total_lines"],
                "workers": [],
                "severity_counts": db_res["severities"]
            })
            return StreamingResponse(iter([f"data: {payload}\n\n"]), media_type="text/event-stream")
        raise HTTPException(status_code=404, detail="Analysis session not found")

    async def event_generator():
        q: asyncio.Queue = asyncio.Queue()

        def on_update(update):
            try:
                loop = asyncio.get_event_loop()
                loop.call_soon_threadsafe(q.put_nowait, update.model_dump())
            except Exception:
                pass

        session.register_subscriber(on_update)
        try:
            while True:
                try:
                    update_data = await asyncio.wait_for(q.get(), timeout=1.0)
                    yield f"data: {json.dumps(update_data)}\n\n"
                    if update_data["status"] in ["completed", "failed", "cancelled"]:
                        break
                except asyncio.TimeoutError:
                    # Keep-alive heartbeat ping
                    yield ": ping\n\n"
                    if session.status in ["completed", "failed", "cancelled"]:
                        break
        finally:
            session.unregister_subscriber(on_update)

    return StreamingResponse(event_generator(), media_type="text/event-stream")

# --- LIVE STREAMING: WEBSOCKET ---
@router.websocket("/analyze/ws/{analysis_id}")
async def websocket_analysis_progress(websocket: WebSocket, analysis_id: str):
    await websocket.accept()
    session = manager.get_session(analysis_id)
    if not session:
        db_res = db.get_analysis_by_id(analysis_id)
        if db_res:
            await websocket.send_json({
                "analysis_id": analysis_id,
                "status": db_res["status"],
                "percent": 100.0,
                "parsed_lines": db_res["parsed_lines"],
                "total_lines": db_res["total_lines"],
                "severity_counts": db_res["severities"]
            })
            await websocket.close()
            return
        await websocket.close(code=1008)
        return

    q: asyncio.Queue = asyncio.Queue()

    def on_update(update):
        try:
            loop = asyncio.get_event_loop()
            loop.call_soon_threadsafe(q.put_nowait, update.model_dump())
        except Exception:
            pass

    session.register_subscriber(on_update)
    try:
        while True:
            try:
                update_data = await asyncio.wait_for(q.get(), timeout=1.0)
                await websocket.send_json(update_data)
                if update_data["status"] in ["completed", "failed", "cancelled"]:
                    break
            except asyncio.TimeoutError:
                await websocket.send_text("ping")
                if session.status in ["completed", "failed", "cancelled"]:
                    break
    except WebSocketDisconnect:
        pass
    finally:
        session.unregister_subscriber(on_update)

# --- SECURITY CENTER ---
@router.get("/security/findings")
def get_security_findings(limit: int = 100, unreviewed_only: bool = False):
    return db.get_all_security_findings(limit=limit, unreviewed_only=unreviewed_only)

@router.post("/security/findings/{finding_id}/review")
def toggle_review(finding_id: int):
    success = db.toggle_finding_reviewed(finding_id)
    if not success:
        raise HTTPException(status_code=404, detail="Finding not found")
    return {"success": True, "finding_id": finding_id}

# --- REPORTS & EXPORT ---
@router.get("/reports")
def list_reports(limit: int = 20):
    return db.get_recent_analyses(limit=limit)

@router.get("/reports/{analysis_id}/json")
def export_report_json(analysis_id: str):
    res = db.get_analysis_by_id(analysis_id)
    if not res:
        raise HTTPException(status_code=404, detail="Analysis report not found")
    return JSONResponse(
        content=res,
        headers={"Content-Disposition": f"attachment; filename=threadwatch_report_{analysis_id}.json"}
    )

@router.get("/reports/{analysis_id}/csv")
def export_report_csv(analysis_id: str):
    res = db.get_analysis_by_id(analysis_id)
    if not res:
        raise HTTPException(status_code=404, detail="Analysis report not found")

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ANALYSIS_ID", res["id"]])
    writer.writerow(["FILENAME", res["filename"]])
    writer.writerow(["TOTAL_LINES", res["total_lines"]])
    writer.writerow(["PARSED_LINES", res["parsed_lines"]])
    writer.writerow(["MALFORMED_LINES", res["malformed_lines"]])
    writer.writerow(["MODE", res["mode"]])
    writer.writerow(["WORKER_COUNT", res["worker_count"]])
    writer.writerow(["DURATION_SECONDS", res["duration_seconds"]])
    writer.writerow(["THROUGHPUT_LPS", res["throughput_lps"]])
    writer.writerow(["STATUS", res["status"]])
    writer.writerow([])
    writer.writerow(["--- SEVERITY COUNTS ---"])
    writer.writerow(["SEVERITY", "COUNT"])
    for sev, count in res["severities"].items():
        writer.writerow([sev, count])

    writer.writerow([])
    writer.writerow(["--- SECURITY FINDINGS ---"])
    writer.writerow(["RULE", "SEVERITY", "TITLE", "IP_ADDRESS", "PROCESS_ID", "EVIDENCE"])
    for f in res["findings"]:
        writer.writerow([f["rule_name"], f["severity"], f["title"], f.get("ip_address", ""), f.get("process_id", ""), f.get("evidence", "")])

    return Response(
        content=output.getvalue(),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename=threadwatch_report_{analysis_id}.csv"}
    )
