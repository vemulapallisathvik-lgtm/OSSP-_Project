import React, { useState, useEffect, useRef } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import {
  UploadCloud,
  FileText,
  Play,
  Square,
  RefreshCw,
  Download,
  AlertTriangle,
  Flame,
  CheckCircle,
  Cpu,
  Layers,
  Search,
  Filter,
  ExternalLink
} from 'lucide-react';

import { api } from '../services/api';
import { Badge } from '../components/Badge';
import { StatCard } from '../components/StatCard';
import { AnalysisProgressUpdate, AnalysisRecord } from '../types';

const SAMPLE_FILES = [
  { name: 'sample_system.log', desc: 'Systemd, kernel panics, OOM-killer & memory warnings' },
  { name: 'sample_auth.log', desc: 'SSH authentication attempts, brute force & sudo escalations' },
  { name: 'sample_application.log', desc: 'API access, DB connection pool timeouts & HTTP 500s' },
  { name: 'sample_benchmark.log', desc: '5,000-line synthetic dataset for multithread load testing' }
];

export const AnalyzeLogs: React.FC = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  // Configuration state
  const [selectedFile, setSelectedFile] = useState<string>('sample_system.log');
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState<boolean>(false);
  const [mode, setMode] = useState<'single' | 'multi'>('multi');
  const [workers, setWorkers] = useState<number>(4);
  const [chunkSize, setChunkSize] = useState<number>(250);

  // Execution state
  const [activeSessionId, setActiveSessionId] = useState<string | null>(searchParams.get('session'));
  const [progress, setProgress] = useState<AnalysisProgressUpdate | null>(null);
  const [completedRecord, setCompletedRecord] = useState<AnalysisRecord | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedSevFilter, setSelectedSevFilter] = useState<string>('ALL');

  const eventSourceRef = useRef<EventSource | null>(null);

  // If session is present in URL or changed, attach stream
  useEffect(() => {
    const sessionParam = searchParams.get('session');
    if (sessionParam) {
      setActiveSessionId(sessionParam);
      connectStream(sessionParam);
    }
  }, [searchParams]);

  const connectStream = (analysisId: string) => {
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
    }

    setIsAnalyzing(true);
    const es = new EventSource(`/api/analyze/stream/${analysisId}`);
    eventSourceRef.current = es;

    es.onmessage = (event) => {
      try {
        const data: AnalysisProgressUpdate = JSON.parse(event.data);
        setProgress(data);

        if (['completed', 'failed', 'cancelled'].includes(data.status)) {
          setIsAnalyzing(false);
          es.close();
          // Load final full record from DB
          api.getAnalysisResults(analysisId)
            .then(rec => setCompletedRecord(rec))
            .catch(console.error);
        }
      } catch (err) {
        console.error('SSE JSON parse error', err);
      }
    };

    es.onerror = () => {
      // Fallback: poll status once
      api.getAnalysisResults(analysisId)
        .then(rec => {
          setCompletedRecord(rec);
          setIsAnalyzing(false);
        })
        .catch(() => {})
        .finally(() => es.close());
    };
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const res = await api.uploadLogFile(file);
      setSelectedFile(res.filename);
      setUploadedFile(file);
    } catch (err: any) {
      alert(`Upload failed: ${err.message}`);
    } finally {
      setUploading(false);
    }
  };

  const handleStartAnalysis = async () => {
    try {
      setIsAnalyzing(true);
      setCompletedRecord(null);
      setProgress(null);

      const res = await api.startAnalysis(selectedFile, mode, workers, chunkSize);
      setActiveSessionId(res.analysis_id);
      connectStream(res.analysis_id);
    } catch (err: any) {
      setIsAnalyzing(false);
      alert(`Failed to start analysis: ${err.message}`);
    }
  };

  const handleCancel = async () => {
    if (!activeSessionId) return;
    try {
      await api.cancelAnalysis(activeSessionId);
      setIsAnalyzing(false);
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
      }
    } catch (err: any) {
      alert(`Cancel error: ${err.message}`);
    }
  };

  // Filtered recent events table
  const displayedEvents = (progress?.recent_events || []).filter(ev => {
    const matchesSearch = searchTerm === '' ||
      ev.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ev.source.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSev = selectedSevFilter === 'ALL' || ev.severity === selectedSevFilter;
    return matchesSearch && matchesSev;
  });

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-800">
        <div>
          <h1 className="text-xl font-bold text-white flex items-center gap-2">
            Multithreaded Log Analyzer
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Producer-consumer log chunking pipeline with live worker thread monitoring
          </p>
        </div>

        {activeSessionId && (
          <div className="flex items-center gap-2">
            <button
              onClick={() => navigate(`/threads?session=${activeSessionId}`)}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-400 border border-slate-700 text-xs font-medium flex items-center gap-1.5"
            >
              <Cpu className="w-3.5 h-3.5" />
              <span>Inspect Worker Threads</span>
              <ExternalLink className="w-3 h-3 ml-0.5" />
            </button>
          </div>
        )}
      </div>

      {/* TOP CONTROLS: UPLOAD & CONFIGURATION */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Upload & Sample Selector */}
        <div className="soc-card p-5 lg:col-span-2 space-y-4">
          <h2 className="text-sm font-semibold text-white flex items-center gap-2">
            <UploadCloud className="w-4 h-4 text-cyan-400" />
            <span>Select or Upload Log Dataset</span>
          </h2>

          {/* Sample dataset selector pills */}
          <div className="space-y-2">
            <label className="text-xs text-slate-400 font-medium">Bundled Sample Datasets:</label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {SAMPLE_FILES.map(file => (
                <button
                  key={file.name}
                  type="button"
                  onClick={() => setSelectedFile(file.name)}
                  className={`p-3 rounded-lg border text-left transition-all ${
                    selectedFile === file.name
                      ? 'bg-cyan-500/10 border-cyan-500 text-white shadow-sm shadow-cyan-950/40'
                      : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-mono text-xs font-bold text-cyan-300">{file.name}</span>
                    {selectedFile === file.name && (
                      <CheckCircle className="w-3.5 h-3.5 text-cyan-400" />
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 leading-snug">{file.desc}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Drag & drop upload area */}
          <div>
            <label className="text-xs text-slate-400 font-medium block mb-2">Or Upload Custom Log File (.log, .txt, .csv):</label>
            <label className="border-2 border-dashed border-slate-700/80 hover:border-cyan-500/50 rounded-lg p-5 flex flex-col items-center justify-center cursor-pointer bg-slate-900/40 transition-colors">
              <UploadCloud className="w-7 h-7 text-slate-400 mb-2" />
              <span className="text-xs text-slate-300 font-medium">
                {uploading ? 'Uploading to server...' : (uploadedFile ? uploadedFile.name : 'Click to browse or drop file here')}
              </span>
              <span className="text-[10px] text-slate-500 mt-1">Maximum file size: 100 MB</span>
              <input
                type="file"
                accept=".log,.txt,.csv"
                onChange={handleFileUpload}
                disabled={uploading}
                className="hidden"
              />
            </label>
          </div>
        </div>

        {/* Worker Pool Configuration */}
        <div className="soc-card p-5 space-y-4">
          <h2 className="text-sm font-semibold text-white flex items-center gap-2">
            <Cpu className="w-4 h-4 text-cyan-400" />
            <span>Worker Thread Settings</span>
          </h2>

          {/* Mode Switcher */}
          <div>
            <label className="text-xs text-slate-400 block mb-1.5 font-medium">Processing Architecture</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setMode('multi')}
                className={`py-2 px-3 rounded-lg border text-xs font-medium transition-all ${
                  mode === 'multi'
                    ? 'bg-cyan-500/15 border-cyan-500/50 text-cyan-300 font-bold'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                Multithreaded
              </button>
              <button
                type="button"
                onClick={() => setMode('single')}
                className={`py-2 px-3 rounded-lg border text-xs font-medium transition-all ${
                  mode === 'single'
                    ? 'bg-amber-500/15 border-amber-500/50 text-amber-300 font-bold'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                Single-Threaded
              </button>
            </div>
          </div>

          {/* Worker count slider */}
          {mode === 'multi' && (
            <div>
              <div className="flex items-center justify-between text-xs mb-1">
                <span className="text-slate-400">Worker Threads:</span>
                <span className="font-mono font-bold text-cyan-300">{workers} Threads</span>
              </div>
              <input
                type="range"
                min="2"
                max="16"
                step="2"
                value={workers}
                onChange={e => setWorkers(parseInt(e.target.value))}
                className="w-full accent-cyan-400 bg-slate-800"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
                <span>2</span>
                <span>4</span>
                <span>8</span>
                <span>12</span>
                <span>16</span>
              </div>
            </div>
          )}

          {/* Chunk size */}
          <div>
            <div className="flex items-center justify-between text-xs mb-1">
              <span className="text-slate-400">Task Chunk Size:</span>
              <span className="font-mono font-bold text-cyan-300">{chunkSize} Lines</span>
            </div>
            <select
              value={chunkSize}
              onChange={e => setChunkSize(parseInt(e.target.value))}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg p-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              <option value="100">100 lines / chunk</option>
              <option value="250">250 lines / chunk (Recommended)</option>
              <option value="500">500 lines / chunk</option>
              <option value="1000">1,000 lines / chunk</option>
              <option value="2000">2,000 lines / chunk</option>
            </select>
          </div>

          {/* Action button */}
          <div className="pt-2">
            {!isAnalyzing ? (
              <button
                type="button"
                onClick={handleStartAnalysis}
                className="w-full py-2.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs flex items-center justify-center gap-2 shadow-lg shadow-cyan-950/50 transition-colors"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Start Concurrent Analysis</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={handleCancel}
                className="w-full py-2.5 rounded-lg bg-red-600 hover:bg-red-500 text-white font-medium text-xs flex items-center justify-center gap-2 shadow-lg shadow-red-950/50 transition-colors"
              >
                <Square className="w-4 h-4 fill-current" />
                <span>Cancel Analysis</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* LIVE PROGRESS SECTION */}
      {(isAnalyzing || progress || completedRecord) && (
        <div className="soc-card p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <span className="text-xs font-mono text-cyan-400 uppercase tracking-wider">
                Analysis Session: {activeSessionId || 'Active'}
              </span>
              <h3 className="text-base font-bold text-white flex items-center gap-2 mt-0.5">
                <span>{selectedFile}</span>
                <Badge
                  label={progress?.status || completedRecord?.status || 'RUNNING'}
                  variant={(progress?.status || completedRecord?.status || 'RUNNING').toUpperCase() as any}
                />
              </h3>
            </div>

            <div className="flex items-center gap-4 text-xs font-mono">
              <div className="bg-slate-900 px-3 py-1.5 rounded border border-slate-800">
                <span className="text-slate-400">Elapsed: </span>
                <span className="text-white font-bold">
                  {progress?.elapsed_seconds ?? completedRecord?.duration_seconds ?? 0}s
                </span>
              </div>
              <div className="bg-slate-900 px-3 py-1.5 rounded border border-slate-800">
                <span className="text-slate-400">Throughput: </span>
                <span className="text-emerald-400 font-bold">
                  {progress?.queue_stats.throughput_lps ?? completedRecord?.throughput_lps ?? 0} LPS
                </span>
              </div>
            </div>
          </div>

          {/* Progress bar */}
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs font-mono text-slate-400">
              <span>
                Processed: {(progress?.parsed_lines ?? completedRecord?.parsed_lines ?? 0).toLocaleString()} / {(progress?.total_lines ?? completedRecord?.total_lines ?? 0).toLocaleString()} lines
              </span>
              <span className="text-cyan-400 font-bold">
                {progress?.percent ?? (completedRecord?.status === 'completed' ? 100 : 0)}%
              </span>
            </div>
            <div className="h-2.5 w-full bg-slate-900 rounded-full overflow-hidden border border-slate-800">
              <div
                className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 transition-all duration-300 rounded-full"
                style={{ width: `${progress?.percent ?? (completedRecord?.status === 'completed' ? 100 : 0)}%` }}
              />
            </div>
          </div>

          {/* Severity Counters Pills */}
          <div className="flex flex-wrap gap-2 pt-1">
            {Object.entries(progress?.severity_counts || completedRecord?.severities || {}).map(([sev, count]) => (
              <div key={sev} className="flex items-center gap-1.5 px-3 py-1 rounded-md bg-slate-900 border border-slate-800 text-xs font-mono">
                <Badge label={sev} variant={sev as any} />
                <span className="font-bold text-white">{count.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* COMPLETED RECORD FINDINGS & REPORT EXPORT */}
      {completedRecord && (
        <div className="soc-card p-5 space-y-4 border-l-4 border-l-emerald-500">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-emerald-400" />
                <span>Log Analysis Run Completed</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Finished {completedRecord.parsed_lines.toLocaleString()} entries in {completedRecord.duration_seconds}s ({completedRecord.throughput_lps} lines/sec).
              </p>
            </div>

            {/* Export Buttons */}
            <div className="flex items-center gap-2">
              <a
                href={api.getReportCsvUrl(completedRecord.id)}
                download
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium flex items-center gap-1.5 transition-colors"
              >
                <Download className="w-3.5 h-3.5 text-cyan-400" />
                <span>Export CSV</span>
              </a>

              <a
                href={api.getReportJsonUrl(completedRecord.id)}
                download
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium flex items-center gap-1.5 transition-colors"
              >
                <Download className="w-3.5 h-3.5 text-emerald-400" />
                <span>Export JSON</span>
              </a>

              <button
                onClick={() => window.print()}
                className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium flex items-center gap-1.5 transition-colors"
              >
                <span>Print Report</span>
              </button>
            </div>
          </div>

          {/* Security Findings Summary */}
          {completedRecord.findings && completedRecord.findings.length > 0 && (
            <div className="pt-3 border-t border-slate-800/80">
              <h4 className="text-xs font-semibold text-rose-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                <Flame className="w-4 h-4" />
                <span>Detected Security Anomalies ({completedRecord.findings.length})</span>
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {completedRecord.findings.slice(0, 4).map(f => (
                  <div key={f.id} className="p-3 rounded-lg bg-slate-900/90 border border-rose-900/30 text-xs space-y-1">
                    <div className="flex items-center justify-between">
                      <Badge label={f.severity} variant={f.severity} />
                      {f.ip_address && <span className="font-mono text-slate-400 text-[10px]">{f.ip_address}</span>}
                    </div>
                    <p className="font-bold text-slate-200">{f.title}</p>
                    <p className="text-[11px] text-slate-400">{f.description}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* LIVE EVENT FEED TABLE */}
      {progress?.recent_events && progress.recent_events.length > 0 && (
        <div className="soc-card p-5 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <span>Streaming Processed Events</span>
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
            </h3>

            {/* Search & Severity Filter */}
            <div className="flex items-center gap-2">
              <div className="relative">
                <Search className="w-3.5 h-3.5 absolute left-2.5 top-2.5 text-slate-500" />
                <input
                  type="text"
                  placeholder="Filter events..."
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                  className="pl-8 pr-3 py-1 bg-slate-900 border border-slate-800 rounded-md text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-500"
                />
              </div>

              <select
                value={selectedSevFilter}
                onChange={e => setSelectedSevFilter(e.target.value)}
                className="bg-slate-900 border border-slate-800 rounded-md py-1 px-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-500"
              >
                <option value="ALL">ALL SEVERITIES</option>
                <option value="CRITICAL">CRITICAL</option>
                <option value="ERROR">ERROR</option>
                <option value="WARNING">WARNING</option>
                <option value="SECURITY">SECURITY</option>
                <option value="INFO">INFO</option>
              </select>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="pb-2">Timestamp</th>
                  <th className="pb-2">Severity</th>
                  <th className="pb-2">Worker</th>
                  <th className="pb-2">Source / PID</th>
                  <th className="pb-2">Message</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {displayedEvents.map((ev, idx) => (
                  <tr key={idx} className="hover:bg-slate-800/30">
                    <td className="py-2 text-slate-400">{ev.timestamp}</td>
                    <td className="py-2">
                      <Badge label={ev.severity} variant={ev.severity as any} />
                    </td>
                    <td className="py-2 text-cyan-400">{ev.thread_id || '-'}</td>
                    <td className="py-2 text-slate-300">
                      {ev.source} {ev.process_id ? `[${ev.process_id}]` : ''}
                    </td>
                    <td className="py-2 text-slate-200 font-sans max-w-md truncate" title={ev.message}>
                      {ev.message}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
